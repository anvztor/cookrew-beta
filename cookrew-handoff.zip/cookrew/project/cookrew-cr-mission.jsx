// ════════════════════════════════════════════════════════════
// Cookrew · MissionBoard — DAG canvas (draggable, infinite)
// ════════════════════════════════════════════════════════════

const CR_TASKS = [
  { id:'t1',  no:'01', title:'Add heartbeat endpoint',         status:'done',    assignee:'SCOUT',      role:'GPT-5-MINI', adds:86, dels:12, x:  40, y: 60 },
  { id:'t2',  no:'02', title:'Heartbeat retry on flaky DNS',   status:'working', assignee:'SCOUT',      role:'GPT-5-MINI', adds:24, dels:4,  blocked:true, x: 320, y: 30, deps:['t1'] },
  { id:'t3',  no:'03', title:'Sandbox reset script',           status:'working', assignee:'BREWER',     role:'SONNET',     adds:41, dels:18, x: 320, y:200, deps:['t1'] },
  { id:'t4',  no:'04', title:'Write replay smoke test',        status:'queued',  assignee:'GATEKEEPER', role:'OPUS',       adds: 0, dels: 0, x: 600, y: 30, deps:['t2','t3'] },
  { id:'t5',  no:'05', title:'Patch deserialization bug',      status:'queued',  assignee:'PATCHER',    role:'HAIKU',      adds: 0, dels: 0, x: 600, y:200, deps:['t3'] },
  { id:'t6',  no:'06', title:'Add chaos-monkey to CI',         status:'queued',  assignee:'GATEKEEPER', role:'OPUS',       adds: 0, dels: 0, x: 880, y: 30, deps:['t4'] },
  { id:'t7',  no:'07', title:'Telemetry dashboard widget',     status:'queued',  assignee:'BREWER',     role:'SONNET',     adds: 0, dels: 0, x: 880, y:200, deps:['t4','t5'] },
  { id:'t8',  no:'08', title:'Migrate redis cluster mode',     status:'queued',  assignee:'PATCHER',    role:'HAIKU',      adds: 0, dels: 0, x: 880, y:370, deps:['t5'] },
  { id:'t9',  no:'09', title:'Roll out behind feature flag',   status:'queued',  assignee:'SCOUT',      role:'GPT-5-MINI', adds: 0, dels: 0, x:1160, y:115, deps:['t6','t7'] },
  { id:'t10', no:'10', title:'Decommission legacy heartbeat',  status:'queued',  assignee:'GATEKEEPER', role:'OPUS',       adds: 0, dels: 0, x:1160, y:285, deps:['t7','t8'] },
  { id:'t11', no:'11', title:'Postmortem template',            status:'queued',  assignee:'BREWER',     role:'SONNET',     adds: 0, dels: 0, x:1440, y:200, deps:['t9','t10'] },
];

const CR_STATUS = {
  done:    { bg:'#D8F3E6', ink:'#0B4F2E', label:'CLEARED'     },
  working: { bg:'#FFF3AD', ink:'#5C4A1F', label:'IN PROGRESS' },
  queued:  { bg:'#F5F0E8', ink:'#78716C', label:'QUEUED'      },
  blocked: { bg:'#FEF2F2', ink:'#DC2626', label:'BLOCKED'     },
};

function CrBundleTitle({
  bundle='BUN_4A2C', name='Heartbeat reliability sweep',
  total=11, blocked=1, working=2, done=1,
  variant='desktop', onNew,
}) {
  const { CrButton, CrChip, CrLED } = window;
  const isMobile = variant === 'mobile';
  return (
    <div className="cr" style={{
      display:'flex', alignItems:'center', gap: 10,
      padding: isMobile ? '10px 14px' : '14px 18px',
      borderBottom:'2px solid var(--line)', background:'var(--cream-hi)',
    }}>
      <div style={{ display:'flex', flexDirection:'column', gap:3, minWidth:0, flex:1 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <span className="cr-display" style={{ fontSize: isMobile ? 11 : 13 }}>{bundle}</span>
          <CrChip tone="amber" style={{ fontSize: 7 }}>LIVE</CrChip>
        </div>
        <div style={{
          fontFamily:'Inter,sans-serif', fontSize: isMobile ? 13 : 15,
          fontWeight:600, color:'var(--ink)', lineHeight:1.25,
          overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
        }}>{name}</div>
        <div style={{ display:'flex', alignItems:'center', gap: 8, flexWrap:'wrap' }}>
          <span className="cr-mono" style={{ fontSize: 9, color:'var(--muted)' }}>{total} QUESTS</span>
          {done    > 0 && <span style={{ display:'flex', alignItems:'center', gap:3 }}><CrLED state="on" /><span className="cr-mono" style={{ fontSize:9 }}>{done}</span></span>}
          {working > 0 && <span style={{ display:'flex', alignItems:'center', gap:3 }}><CrLED state="busy" /><span className="cr-mono" style={{ fontSize:9 }}>{working}</span></span>}
          {blocked > 0 && <span style={{ display:'flex', alignItems:'center', gap:3 }}><CrLED state="red"  /><span className="cr-mono" style={{ fontSize:9 }}>{blocked}</span></span>}
        </div>
      </div>
      <CrButton variant="primary" size={isMobile ? 'tiny' : 'sm'} onClick={onNew}>＋ NEW</CrButton>
    </div>
  );
}

function CrTaskLiveCard({ t, compact=false, highlight=false, onClick, style, dragging }) {
  const { CrChip, CrLED } = window;
  const st = CR_STATUS[t.blocked ? 'blocked' : t.status];
  return (
    <div onClick={onClick} className="cr-bevel" style={{
      padding: compact ? '8px 10px' : '12px 14px',
      cursor: dragging ? 'grabbing' : (onClick ? 'pointer' : 'default'),
      display:'flex', flexDirection:'column', gap: compact ? 5 : 8,
      background:'var(--cream-hi)', width:'100%',
      outline: highlight ? '2px solid var(--amber-deep)' : 'none',
      outlineOffset: 1,
      boxShadow: dragging ? '6px 6px 0 rgba(0,0,0,0.25)' : undefined,
      ...style,
    }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap: 8 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <span className="cr-mono" style={{ fontSize: 11, fontWeight: 700, color:'var(--muted)' }}>#{t.no}</span>
          <CrLED state={t.status === 'done' ? 'on' : t.status === 'working' ? 'busy' : t.blocked ? 'red' : 'off'} />
        </div>
        <CrChip style={{ background: st.bg, color: st.ink, borderColor:'var(--line)', fontSize: 7 }}>{st.label}</CrChip>
      </div>
      <div style={{
        fontFamily:'Inter,sans-serif', fontSize: compact ? 13 : 14,
        fontWeight:600, color:'var(--ink)', lineHeight: 1.3, textWrap:'pretty',
      }}>{t.title}</div>
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'space-between', gap: 6,
        paddingTop: 6, borderTop:'1.5px dashed var(--line-soft)',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap: 6, minWidth: 0 }}>
          <CrChip tone="slate" style={{ fontSize: 7 }}>{t.assignee}</CrChip>
          <span className="cr-mono" style={{ fontSize: 9, color:'var(--muted)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{t.role}</span>
        </div>
        {(t.adds > 0 || t.dels > 0) && (
          <div className="cr-mono" style={{ fontSize: 10, display:'flex', gap: 5, flexShrink: 0 }}>
            <span style={{ color:'var(--emerald)' }}>+{t.adds}</span>
            <span style={{ color:'var(--rose)'    }}>−{t.dels}</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ── TaskCanvas — INFINITE pannable DAG with draggable cards ──
function CrTaskCanvas({ tasks=CR_TASKS, variant='desktop', onSelect }) {
  const [pos, setPos] = React.useState(() => Object.fromEntries(tasks.map(t => [t.id, { x: t.x, y: t.y }])));
  const [pan, setPan] = React.useState({ x: 0, y: 0 });
  const [draggingId, setDraggingId] = React.useState(null);
  const vpRef = React.useRef(null);
  const dragRef = React.useRef(null);
  const panRef = React.useRef(null);

  const isMobile = variant === 'mobile';
  const CARD_W = isMobile ? 180 : 220;
  const CARD_H = isMobile ? 120 : 132;

  // Pan with background drag
  const onVPDown = (e) => {
    if (e.target.closest('[data-task-card]')) return;
    if (e.button !== 0 && e.button !== 1) return;
    e.preventDefault();
    panRef.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y };
    vpRef.current.setPointerCapture(e.pointerId);
  };
  const onVPMove = (e) => {
    if (!panRef.current) return;
    setPan({ x: panRef.current.px + (e.clientX - panRef.current.x), y: panRef.current.py + (e.clientY - panRef.current.y) });
  };
  const onVPUp = () => { panRef.current = null; };

  // Card drag
  const onCardDown = (id, e) => {
    e.stopPropagation();
    if (e.button !== 0) return;
    dragRef.current = { id, x: e.clientX, y: e.clientY, ox: pos[id].x, oy: pos[id].y };
    setDraggingId(id);
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onCardMove = (e) => {
    if (!dragRef.current) return;
    const d = dragRef.current;
    setPos(p => ({ ...p, [d.id]: { x: d.ox + (e.clientX - d.x), y: d.oy + (e.clientY - d.y) } }));
  };
  const onCardUp = () => { dragRef.current = null; setDraggingId(null); };

  // Bounding box for SVG
  const xs = Object.values(pos).map(p => p.x);
  const ys = Object.values(pos).map(p => p.y);
  const W = Math.max(...xs) + CARD_W + 200;
  const H = Math.max(...ys) + CARD_H + 200;

  return (
    <div ref={vpRef} className="cr"
      onPointerDown={onVPDown} onPointerMove={onVPMove}
      onPointerUp={onVPUp} onPointerCancel={onVPUp}
      style={{
        flex: 1, minHeight: 0, overflow:'hidden', position:'relative',
        background:'var(--cream-md)',
        backgroundImage:'radial-gradient(rgba(0,0,0,0.07) 1px, transparent 1px)',
        backgroundSize:'12px 12px',
        backgroundPosition: `${pan.x}px ${pan.y}px`,
        cursor: panRef.current ? 'grabbing' : 'grab',
      }}>
      <div style={{
        position:'absolute', left: pan.x, top: pan.y,
        width: W, height: H,
      }}>
        {/* dependency strings */}
        <svg width={W} height={H} style={{ position:'absolute', inset:0, pointerEvents:'none' }}>
          {tasks.flatMap(t => (t.deps || []).map(dep => {
            const a = pos[dep]; const b = pos[t.id];
            if (!a || !b) return null;
            const ax = a.x + CARD_W, ay = a.y + CARD_H/2;
            const bx = b.x,         by = b.y + CARD_H/2;
            const cx = (ax + bx) / 2;
            const isBlocked = t.blocked || tasks.find(x => x.id === t.id)?.blocked;
            return (
              <g key={t.id+dep}>
                <path d={`M ${ax} ${ay} C ${cx} ${ay}, ${cx} ${by}, ${bx} ${by}`}
                  stroke={isBlocked ? '#DC2626' : '#D97706'} strokeWidth="2" fill="none"
                  strokeDasharray="4 3" opacity="0.55" />
                <circle cx={ax} cy={ay} r="3" fill={isBlocked ? '#DC2626' : '#D97706'} />
                <circle cx={bx} cy={by} r="3" fill={isBlocked ? '#DC2626' : '#D97706'} />
              </g>
            );
          }))}
        </svg>
        {tasks.map(t => {
          const p = pos[t.id];
          return (
            <div key={t.id}
              data-task-card
              onPointerDown={(e) => onCardDown(t.id, e)}
              onPointerMove={onCardMove}
              onPointerUp={onCardUp}
              onPointerCancel={onCardUp}
              style={{
                position:'absolute', left: p.x, top: p.y, width: CARD_W,
                zIndex: draggingId === t.id ? 10 : 1,
                touchAction:'none',
              }}>
              <CrTaskLiveCard t={t} compact={isMobile} dragging={draggingId === t.id} onClick={() => onSelect?.(t)} />
            </div>
          );
        })}
      </div>
      <div className="cr-mono" style={{
        position:'absolute', bottom: 8, right: 12, fontSize: 9,
        color:'var(--muted)', pointerEvents:'none', userSelect:'none',
      }}>drag bg to pan · drag cards to rearrange</div>
    </div>
  );
}

const CR_HITL = [
  { id:'h1', task:'#02 retry on flaky DNS', from:'SCOUT',  pending:'2m', overdue:false },
  { id:'h2', task:'#04 replay smoke test',  from:'GATEKEEPER', pending:'7m', overdue:true },
  { id:'h3', task:'#05 deserialize patch',  from:'PATCHER', pending:'12s', overdue:false },
];
function CrHITLClickbar({ items = CR_HITL, onRestore, variant='desktop' }) {
  const isMobile = variant === 'mobile';
  return (
    <div className="cr cr-noscrollbar" style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      display:'flex', gap: 6, padding: isMobile ? 8 : 10,
      background:'linear-gradient(to top, var(--cream-md) 60%, transparent)',
      borderTop:'2px solid var(--line)',
      overflowX:'auto', alignItems:'flex-end',
    }}>
      <span className="cr-kicker" style={{ fontSize: 8, color:'var(--ink-soft)', alignSelf:'center', flexShrink: 0, padding: '0 6px 0 2px' }}>HITL</span>
      {items.map(h => (
        <button key={h.id} onClick={() => onRestore?.(h)} className="cr-bevel" style={{
          display:'flex', alignItems:'center', gap: 8, padding: '6px 10px',
          background: h.overdue ? 'var(--rose-soft)' : 'var(--amber-soft)',
          borderColor: h.overdue ? 'var(--rose)' : 'var(--line)',
          cursor:'pointer', flexShrink: 0, minHeight: 36,
        }}>
          <span className={`cr-led ${h.overdue ? 'red' : 'busy'}`} />
          <span className="cr-display" style={{ fontSize: 9, color: h.overdue ? 'var(--rose)' : 'var(--ink)' }}>{h.task}</span>
          <span className="cr-mono" style={{ fontSize: 9, color:'var(--muted)' }}>· {h.from} · {h.pending}</span>
        </button>
      ))}
    </div>
  );
}

function CrMissionBoard({
  variant='desktop', tasks=CR_TASKS, hitl=CR_HITL,
  onNewQuest, onSelectTask,
}) {
  return (
    <div className="cr" style={{
      display:'flex', flexDirection:'column', flex: 1, minHeight: 0,
      background:'var(--cream-md)', position:'relative',
    }}>
      <CrBundleTitle variant={variant} onNew={onNewQuest}
        total={tasks.length}
        done={tasks.filter(t=>t.status==='done').length}
        working={tasks.filter(t=>t.status==='working' && !t.blocked).length}
        blocked={tasks.filter(t=>t.blocked).length}
      />
      <div style={{ flex: 1, minHeight: 0, position:'relative', display:'flex', flexDirection:'column' }}>
        <CrTaskCanvas tasks={tasks} variant={variant} onSelect={onSelectTask} />
        {hitl && hitl.length > 0 && <CrHITLClickbar items={hitl} variant={variant} onRestore={onSelectTask} />}
      </div>
    </div>
  );
}

Object.assign(window, {
  CrBundleTitle, CrTaskLiveCard, CrTaskCanvas, CrHITLClickbar, CrMissionBoard,
  CR_TASKS, CR_HITL, CR_STATUS,
});
