// Cookrew Workspace — full-app responsive screens
//   • Desktop: sidebar + mission board + corner pip-boy feed + composer dock
//   • Tablet:  collapsed sidebar + mission grid + composer (feed in drawer)
//   • Mobile:  topbar + tab content + composer condensed + bottom tab bar

function CkAppDesktop() {
  const { CkSidebar, CkMissionBoard, CkEventFeed, CkComposerDock } = window;
  const [active, setActive] = React.useState('scout');
  return (
    <div className="ck" style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--cream)' }}>
      <div style={{ flex: 1, display: 'flex', minHeight: 0, position: 'relative' }}>
        <CkSidebar active={active} onSelect={setActive} />
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <CkMissionBoard />
        </main>
        {/* Pip-Boy corner feed */}
        <div style={{ position: 'absolute', right: 16, top: 16, width: 320, height: 380, boxShadow: '4px 4px 0 var(--line)' }}>
          <CkEventFeed variant="panel" />
        </div>
      </div>
      <CkComposerDock variant="desktop" />
    </div>
  );
}

function CkAppTablet() {
  const { CkSidebar, CkMissionBoard, CkComposerDock } = window;
  const [active, setActive] = React.useState('scout');
  return (
    <div className="ck" style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--cream)' }}>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <CkSidebar collapsed active={active} onSelect={setActive} />
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <CkMissionBoard />
        </main>
      </div>
      <CkComposerDock variant="tablet" />
    </div>
  );
}

function CkAppMobile({ tab = 'missions' }) {
  const { CkTopBar, CkTabBar, CkMissionList, CkMissionCarousel, CkEventFeed, CkComposerDock, CkSidebar, CkAtomsCard } = window;
  const [t, setT] = React.useState(tab);

  let content;
  if (t === 'home') {
    content = <CkAppMobileHome />;
  } else if (t === 'missions') {
    content = (
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
        <CkMissionCarousel />
        <div style={{ padding: '0 14px 14px' }}>
          <div className="ck-kicker" style={{ fontSize: 9, marginBottom: 8 }}>RECENT</div>
        </div>
        <div style={{ padding: '0 14px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <window.CkTaskCard t={window.CK_TASKS[0]} compact />
          <window.CkTaskCard t={window.CK_TASKS[1]} compact />
        </div>
      </div>
    );
  } else if (t === 'feed') {
    content = <div style={{ flex: 1, minHeight: 0 }}><CkEventFeed variant="mobile" /></div>;
  } else if (t === 'party') {
    content = <div style={{ flex: 1, minHeight: 0, overflow: 'auto' }}><CkSidebar active="scout" /></div>;
  } else {
    content = <div style={{ flex: 1, padding: 14, overflow: 'auto' }}><CkAtomsCard /></div>;
  }

  return (
    <div className="ck" style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--cream-md)' }}>
      <CkTopBar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        {content}
      </div>
      {(t === 'missions' || t === 'home') && <CkComposerDock variant="mobile" />}
      <CkTabBar active={t} onChange={setT} />
    </div>
  );
}

function CkAppMobileHome() {
  const { CkSprite, CK_PORTRAITS, CkChip, CkLED, CkBtn, CkBar, CkTokBar } = window;
  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div className="ck-bevel" style={{ background: 'var(--amber)', padding: 14 }}>
        <div className="ck-kicker" style={{ fontSize: 8, color: '#5C4A1F', marginBottom: 4 }}>ACTIVE BUNDLE</div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: 16, fontWeight: 700, color: '#1A1408', marginBottom: 6 }}>
          Heartbeat hardening · 5 quests
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <CkChip style={{ background: '#1A1408', color: 'var(--amber)', borderColor: '#1A1408' }}>1 BLOCKED</CkChip>
          <CkChip style={{ background: 'rgba(255,255,255,0.5)', borderColor: '#1A1408' }}>2 IN PROGRESS</CkChip>
          <CkChip style={{ background: 'rgba(255,255,255,0.5)', borderColor: '#1A1408' }}>1 DONE</CkChip>
        </div>
      </div>

      <div className="ck-bevel" style={{ background: 'var(--cream-hi)', padding: 14 }}>
        <div className="ck-kicker" style={{ fontSize: 9, marginBottom: 10 }}>YOUR PARTY · 4/5 ONLINE</div>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto' }} className="ck-noscrollbar">
          {['scout', 'gatekeeper', 'brewer', 'patcher'].map(p => (
            <div key={p} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, flexShrink: 0 }}>
              <div style={{ position: 'relative' }}>
                <CkSprite art={CK_PORTRAITS[p]} size={48} bg="var(--cream-md)" />
                <div style={{ position: 'absolute', bottom: -2, right: -2 }}><CkLED state={p === 'patcher' ? 'off' : p === 'gatekeeper' ? 'on' : 'busy'} /></div>
              </div>
              <span className="ck-display" style={{ fontSize: 8 }}>{p.toUpperCase().slice(0, 6)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="ck-bevel" style={{ background: 'var(--cream-hi)', padding: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div className="ck-kicker" style={{ fontSize: 9 }}>YOUR STATS</div>
          <CkChip tone="phos" style={{ fontSize: 7 }}>P1 · ALEX</CkChip>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
          <CkBar label="HP" value={92} max={100} kind="hp" />
          <CkTokBar label="5h" used={38000} max={50000} kind="mp" />
          <CkTokBar label="7d" used={840000} max={1000000} kind="hp" />
        </div>
      </div>

      <CkBtn variant="primary" block touch>＋ NEW BUNDLE</CkBtn>
    </div>
  );
}

Object.assign(window, { CkAppDesktop, CkAppTablet, CkAppMobile });
