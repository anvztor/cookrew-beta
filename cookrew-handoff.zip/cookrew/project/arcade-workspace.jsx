// Arcade Workspace — main hi-fi screen assembling sidebar + mission board + pip-boy feed + composer dock.
// Size: 1440 x 900 (fixed artboard)

function TopHUD({ onCollapse, collapsed, variant }) {
  const { PixelBtn } = window;
  return (
    <header style={{
      display: 'grid',
      gridTemplateColumns: 'auto 1fr auto auto auto',
      alignItems: 'center', gap: 14,
      padding: '10px 16px',
      background: 'var(--ink)',
      borderBottom: '3px solid var(--line)',
      color: '#FFEDB0',
      boxShadow: 'inset 0 -6px 0 rgba(0,0,0,0.4)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 34, height: 34,
          background: 'var(--amber)',
          border: '2px solid #FFEDB0',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Press Start 2P', fontSize: 11, color: 'var(--ink)',
        }}>CK</div>
        <div>
          <div className="pc-display" style={{ fontSize: 14, letterSpacing: 1, color: 'var(--amber)' }}>COOKREW</div>
          <div className="pc-silk" style={{ fontSize: 8, color: '#D6D3D1', letterSpacing: 1.2 }}>ARCADE MODE · v0.∞</div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div className="pc-chip phos" style={{ fontSize: 9 }}>▶ RECIPE · KREW-DEV/COOKREW</div>
        <div className="pc-chip" style={{ fontSize: 9, background: 'rgba(233,185,73,0.15)', color: '#FFEDB0', borderColor: 'var(--phos-dim)' }}>BUN_4A2C · BLOCKED</div>
        <div className="pc-mono" style={{ color: '#A8A29E', fontSize: 10 }}>main · abc123</div>
      </div>
      <div className="pc-mono" style={{ color: '#D6D3D1', fontSize: 10 }}>
        <span style={{ color: 'var(--hp)' }}>●</span> 4/6 online
        &nbsp;&nbsp;
        <span style={{ color: 'var(--amber)' }}>⚑</span> 1 blocked
        &nbsp;&nbsp;
        <span style={{ color: 'var(--violet)' }}>⏱</span> 00:04:17
      </div>
      <PixelBtn size="sm" variant="ghost" style={{ color: '#FFEDB0', borderColor: '#FFEDB0' }}>⌘K</PixelBtn>
      <PixelBtn size="sm" variant="primary">▣ REPORT-IN</PixelBtn>
    </header>
  );
}

function BlockedBanner() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '8px 16px',
      borderBottom: '2px solid var(--line)',
      background: 'repeating-linear-gradient(135deg, #FEF3C7, #FEF3C7 8px, #FDE68A 8px, #FDE68A 16px)',
      fontSize: 12, color: 'var(--ink)',
    }}>
      <div style={{ width: 24, height: 24, border: '2px solid var(--line)', background: 'var(--amber)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Press Start 2P', fontSize: 10 }}>!</div>
      <div className="pc-silk" style={{ fontSize: 10 }}>
        QUEST #04 BLOCKED · <span style={{ fontFamily: 'JetBrains Mono, monospace', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>cron runner not configured · 1 agent idle</span>
      </div>
      <div style={{ flex: 1 }} />
      <button className="pc-btn tiny">▷ UNBLOCK</button>
      <button className="pc-btn tiny">↻ RERUN</button>
    </div>
  );
}

function ArcadeWorkspace({
  // state
  sidebarCollapsed = false,
  feedExpanded = false,
  showSlash = false,
  highlightedAgent = null,
  highlightedTask = null,
  target = 'seed',
  scanlines = true,
  variant = 'hi',  // 'hi' | 'focus-graph' | 'agent-detail'
  showCard = null, // 'cookbook' | 'history' | 'review' | 'profile' | null
  sandboxRecipe = null, // open this recipe in the cookbook tab
}) {
  const { ArcadeSidebar, MissionBoard, EventFeed, ComposerDock, ROSTER, TASKS, WorkspaceCard } = window;
  const [card, setCard] = React.useState(showCard);
  React.useEffect(() => setCard(showCard), [showCard]);
  const [hAgent, setHAgent] = React.useState(highlightedAgent);
  const [hTask, setHTask] = React.useState(highlightedTask);
  const [sbCollapsed, setSbCollapsed] = React.useState(sidebarCollapsed);
  const [feedOpen, setFeedOpen] = React.useState(feedExpanded);

  React.useEffect(() => setHAgent(highlightedAgent), [highlightedAgent]);
  React.useEffect(() => setHTask(highlightedTask), [highlightedTask]);
  React.useEffect(() => setSbCollapsed(sidebarCollapsed), [sidebarCollapsed]);
  React.useEffect(() => setFeedOpen(feedExpanded), [feedExpanded]);

  // Hover linking — agent claim mapping
  const linkedTaskForAgent = (aid) => ROSTER.find(r => r.id === aid)?.taskId || null;
  const linkedAgentForTask = (tid) => ROSTER.find(r => r.taskId === tid)?.id || null;

  const effHAgent = hAgent || (hTask ? linkedAgentForTask(hTask) : null);
  const effHTask  = hTask  || (hAgent ? linkedTaskForAgent(hAgent) : null);

  return (
    <div className={`pc-root ${scanlines ? 'pc-arcade-scan' : ''}`} style={{
      width: 1440, height: 900,
      display: 'flex', flexDirection: 'column',
      background: 'var(--cream)',
      fontFamily: 'Inter, sans-serif',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <TopHUD collapsed={sbCollapsed} onCollapse={() => setSbCollapsed(!sbCollapsed)} variant={variant} />
      <BlockedBanner />

      {/* Main body: sidebar + stage */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0, position: 'relative' }}>
        <ArcadeSidebar
          collapsed={sbCollapsed}
          onToggleCollapse={() => setSbCollapsed(!sbCollapsed)}
          highlightedAgent={effHAgent}
          onHoverAgent={setHAgent}
          activeAgent={variant === 'agent-detail' ? 'a_gatekeeper' : null}
          onSelectAgent={() => {}}
        />

        {/* Stage — mission board (scrollable) */}
        <div style={{
          flex: 1, minWidth: 0, position: 'relative',
          background: `
            radial-gradient(circle at 10% 10%, rgba(255,214,0,0.05), transparent 40%),
            radial-gradient(circle at 90% 80%, rgba(155,138,203,0.08), transparent 40%),
            var(--cream)
          `,
          backgroundImage: `
            linear-gradient(var(--cream-md) 1px, transparent 1px),
            linear-gradient(90deg, var(--cream-md) 1px, transparent 1px)
          `,
          backgroundSize: '24px 24px',
          display: 'flex', flexDirection: 'column',
          overflow: 'hidden',
        }}>
          {/* Stage header */}
          <div style={{
            padding: '10px 20px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            borderBottom: '1px dashed var(--line)',
            background: 'rgba(250,248,244,0.8)',
            backdropFilter: 'blur(4px)',
          }}>
            <div>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ MISSION BOARD · BUNDLE</div>
              <div className="pc-display" style={{ fontSize: 14, marginTop: 4, color: 'var(--ink)' }}>
                "ADD KREWCLI PRESENCE & TASK CLAIMING"
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <div className="pc-chip emerald">1/5 CLEARED</div>
              <div className="pc-chip amber">2 WORKING</div>
              <div className="pc-chip rose">1 BLOCKED</div>
              <div style={{ width: 1, height: 20, background: 'var(--line-soft)' }} />
              <button className="pc-btn tiny">GRAPH</button>
              <button className="pc-btn tiny">LIST</button>
              <button className="pc-btn tiny primary">FOCUS</button>
            </div>
          </div>

          {/* Board scroll */}
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: 16 }}>
            <MissionBoard
              tasks={TASKS}
              highlightedTask={effHTask}
              onHoverTask={setHTask}
              onSelectTask={() => {}}
            />
          </div>
        </div>

        {/* Pip-Boy Feed popout */}
        <EventFeed
          expanded={feedOpen}
          onToggle={setFeedOpen}
          highlightedAgent={hAgent}
          onHoverAgent={setHAgent}
        />

        {/* Agent detail overlay (focus mode) */}
        {variant === 'agent-detail' && <AgentDetailOverlay agent={ROSTER[1]} />}

        {/* Workspace Card pop-up */}
        {card && WorkspaceCard && (
          <WorkspaceCard initialTab={card} initialOpenedRecipe={sandboxRecipe} onClose={() => setCard(null)} />
        )}
      </div>

      {/* Composer dock — always on */}
      <ComposerDock
        target={target}
        onTarget={() => {}}
        showSlash={showSlash}
      />

      {/* Global CRT scanlines */}
      {scanlines && (
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 100,
          background: 'repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0, rgba(0,0,0,0) 3px, rgba(0,0,0,0.035) 3px, rgba(0,0,0,0.035) 4px)',
          mixBlendMode: 'multiply',
        }}/>
      )}
    </div>
  );
}

function AgentDetailOverlay({ agent }) {
  const { HPBar, Sprite16, PORTRAITS, PixelBtn } = window;
  return (
    <div style={{
      position: 'absolute', top: 12, left: 280,
      width: 360,
      zIndex: 15,
    }}>
      <div className="pc-bevel" style={{ padding: 0, background: 'var(--cream-hi)' }}>
        <div style={{ display: 'flex', gap: 12, padding: 14, borderBottom: '2px solid var(--line)', background: 'var(--amber)' }}>
          <Sprite16 art={PORTRAITS[agent.sprite]} size={64} bg="#FFFEF5" />
          <div style={{ flex: 1 }}>
            <div className="pc-display" style={{ fontSize: 14, color: 'var(--ink)' }}>{agent.name}</div>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--ink-soft)', marginTop: 4 }}>{agent.class}</div>
            <div className="pc-mono" style={{ fontSize: 10, marginTop: 4, color: 'var(--ink-soft)' }}>{agent.role}</div>
          </div>
        </div>
        <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <HPBar label="HP" value={agent.hp} max={agent.hpMax} kind="hp" />
          <HPBar label="MP" value={agent.mp} max={agent.mpMax} kind="mp" />
          <HPBar label="XP" value={620} max={1200} kind="xp" />
          <div style={{ borderTop: '1px dashed var(--line-soft)', paddingTop: 10 }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ TOOLS EQUIPPED</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              {agent.tools.map(t => <span key={t} className="pc-chip violet" style={{ fontSize: 9 }}>{t}</span>)}
            </div>
          </div>
          <div style={{ borderTop: '1px dashed var(--line-soft)', paddingTop: 10 }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 4 }}>▸ CURRENT QUEST</div>
            <div className="pc-mono" style={{ fontSize: 11, color: 'var(--ink)' }}>#02 · Route CLI task.claim</div>
            <div style={{ width: '100%', height: 4, background: 'var(--cream-md)', border: '1px solid var(--line)', marginTop: 6 }}>
              <div style={{ height: '100%', width: '58%', background: 'var(--amber-deep)' }}/>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            <PixelBtn variant="primary" size="sm">@MENTION</PixelBtn>
            <PixelBtn size="sm">DISPATCH</PixelBtn>
            <PixelBtn size="sm" variant="danger">KICK</PixelBtn>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ArcadeWorkspace });
