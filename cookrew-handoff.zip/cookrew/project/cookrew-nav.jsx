// Cookrew Sidebar / Nav — three responsive forms:
//   • Desktop:  full party rail (220px) with portraits + HP/MP bars
//   • Tablet:   icon rail (64px) with portraits only, badge for HP
//   • Mobile:   bottom tab bar (5 tabs) — primary nav, party lives in dedicated tab

const CK_ROSTER = [
  { id: 'alex',    kind: 'human', name: 'ALEX',       sub: 'OPERATOR',  portrait: 'human',      hp: 92, max: 100, used: 0, status: 'on' },
  { id: 'scout',   kind: 'agent', name: 'SCOUT',      sub: 'GPT-5-MINI · 3 tools', portrait: 'scout', hp: 78, max: 100, used: 38000, ctxMax: 50000, status: 'busy' },
  { id: 'gate',    kind: 'agent', name: 'GATEKEEPER', sub: 'OPUS · 4 tools',       portrait: 'gatekeeper', hp: 100, max: 100, used: 12000, ctxMax: 50000, status: 'on' },
  { id: 'brewer',  kind: 'agent', name: 'BREWER',     sub: 'SONNET · 6 tools',     portrait: 'brewer',  hp: 64, max: 100, used: 47000, ctxMax: 50000, status: 'busy' },
  { id: 'patcher', kind: 'agent', name: 'PATCHER',    sub: 'HAIKU · 2 tools',      portrait: 'patcher', hp: 22, max: 100, used: 0, ctxMax: 50000, status: 'off' },
];

// ── Desktop / Tablet party rail ──────────────────────────────────
function CkSidebar({ collapsed = false, active = 'scout', onSelect }) {
  const { CkChip, CkLED, CkBar, CkTokBar, CkSprite, CK_PORTRAITS, CkBtn } = window;
  const online = CK_ROSTER.filter(r => r.status !== 'off').length;
  const w = collapsed ? 64 : 220;
  return (
    <aside className="ck" style={{
      width: w, height: '100%', background: 'var(--cream-md)',
      borderRight: '2px solid var(--line)',
      display: 'flex', flexDirection: 'column',
      transition: 'width 180ms ease',
    }}>
      {/* Header */}
      <div style={{ padding: collapsed ? '12px 8px' : '14px 14px', borderBottom: '2px solid var(--line)', background: 'var(--cream-hi)' }}>
        {collapsed ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <div className="ck-display" style={{ fontSize: 10 }}>CK</div>
            <CkLED state="on" />
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
              <div className="ck-display" style={{ fontSize: 12 }}>COOKREW</div>
              <CkChip tone="phos">P1</CkChip>
            </div>
            <div className="ck-kicker" style={{ fontSize: 8 }}>PARTY · {online}/{CK_ROSTER.length} ONLINE</div>
          </>
        )}
      </div>

      {/* Roster */}
      <div className="ck-scroll" style={{ flex: 1, overflowY: 'auto', padding: collapsed ? '8px 6px' : '10px 10px' }}>
        {CK_ROSTER.map(m => (
          <button key={m.id} onClick={() => onSelect && onSelect(m.id)} style={{
            width: '100%', padding: collapsed ? '6px 4px' : '8px',
            border: 'none', cursor: 'pointer',
            background: active === m.id ? 'var(--amber-soft)' : 'transparent',
            display: 'flex', alignItems: collapsed ? 'center' : 'flex-start',
            justifyContent: collapsed ? 'center' : 'flex-start',
            flexDirection: collapsed ? 'column' : 'row', gap: collapsed ? 4 : 10,
            marginBottom: 2, borderLeft: collapsed ? 'none' : `3px solid ${active === m.id ? 'var(--ink)' : 'transparent'}`,
            textAlign: 'left', opacity: m.status === 'off' ? 0.5 : 1,
          }}>
            <div style={{ position: 'relative' }}>
              <CkSprite art={CK_PORTRAITS[m.portrait]} size={collapsed ? 36 : 40} bg="var(--cream-hi)" />
              <div style={{ position: 'absolute', bottom: -2, right: -2 }}>
                <CkLED state={m.status === 'busy' ? 'busy' : m.status === 'off' ? 'off' : 'on'} />
              </div>
            </div>
            {!collapsed && (
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 4 }}>
                  <div className="ck-display" style={{ fontSize: 10 }}>{m.name}</div>
                  <CkChip tone={m.kind === 'human' ? 'amber' : 'slate'} style={{ fontSize: 7, padding: '1px 4px' }}>{m.kind === 'human' ? 'P1' : 'NPC'}</CkChip>
                </div>
                <div className="ck-mono" style={{ fontSize: 9, color: 'var(--muted)', marginTop: 2, marginBottom: 6, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.sub}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                  <CkBar label="HP" value={m.hp} max={m.max} kind="hp" />
                  {m.kind === 'agent' && <CkTokBar label="CTX" used={m.used} max={m.ctxMax} kind="mp" segments={10} />}
                </div>
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Footer */}
      {!collapsed && (
        <div style={{ borderTop: '2px solid var(--line)', padding: 10, background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', gap: 6 }}>
          <CkBtn variant="primary" size="sm" block>＋ Hire Agent</CkBtn>
          <CkBtn variant="ghost" size="sm" block>⚙ Config</CkBtn>
        </div>
      )}
    </aside>
  );
}

// ── Mobile bottom tab bar ────────────────────────────────────────
const CK_TABS = [
  { id: 'home',     label: 'HOME',     icon: '◆' },
  { id: 'missions', label: 'MISSIONS', icon: '▤' },
  { id: 'feed',     label: 'FEED',     icon: '▦' },
  { id: 'party',    label: 'PARTY',    icon: '♣' },
  { id: 'me',       label: 'ME',       icon: '☺' },
];
function CkTabBar({ active = 'missions', onChange, badges = { feed: 12, party: 4 } }) {
  return (
    <nav className="ck" style={{
      display: 'flex',
      borderTop: '2px solid var(--line)',
      background: 'var(--cream-hi)',
      paddingBottom: 'env(safe-area-inset-bottom, 0)',
    }}>
      {CK_TABS.map(t => {
        const isActive = active === t.id;
        const badge = badges[t.id];
        return (
          <button key={t.id} onClick={() => onChange && onChange(t.id)} style={{
            flex: 1, position: 'relative',
            padding: '10px 4px 8px',
            border: 'none', background: 'transparent',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            cursor: 'pointer', minHeight: 56,
            color: isActive ? 'var(--ink)' : 'var(--muted)',
            borderTop: isActive ? '3px solid var(--amber)' : '3px solid transparent',
            marginTop: -2,
          }}>
            <div style={{ position: 'relative' }}>
              <span style={{ fontSize: 18, lineHeight: 1 }}>{t.icon}</span>
              {badge && (
                <span style={{
                  position: 'absolute', top: -6, right: -10,
                  background: 'var(--rose)', color: '#fff',
                  fontSize: 9, fontFamily: 'JetBrains Mono, monospace', fontWeight: 700,
                  padding: '1px 4px', borderRadius: 8, border: '1.5px solid var(--line)',
                  minWidth: 16, textAlign: 'center',
                }}>{badge}</span>
              )}
            </div>
            <span className="ck-display" style={{ fontSize: 8 }}>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

// ── Mobile top bar (logo + bell + collapsed party LED) ───────────
function CkTopBar({ title = 'COOKREW', subtitle = 'BUNDLE 4A2C', online = 4, onMenu }) {
  const { CkChip, CkLED } = window;
  return (
    <header className="ck" style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '12px 14px',
      background: 'var(--cream-hi)',
      borderBottom: '2px solid var(--line)',
      paddingTop: 'calc(12px + env(safe-area-inset-top, 0px))',
    }}>
      <button onClick={onMenu} style={{ border: '2px solid var(--line)', background: 'var(--cream-hi)', width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '2px 2px 0 var(--line)', cursor: 'pointer' }}>
        <span style={{ display: 'inline-block', width: 14 }}>
          <span style={{ display: 'block', height: 2, background: 'var(--line)', marginBottom: 3 }} />
          <span style={{ display: 'block', height: 2, background: 'var(--line)', marginBottom: 3 }} />
          <span style={{ display: 'block', height: 2, background: 'var(--line)' }} />
        </span>
      </button>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div className="ck-display" style={{ fontSize: 13 }}>{title}</div>
          <CkChip tone="phos" style={{ fontSize: 7 }}>P1</CkChip>
        </div>
        <div className="ck-mono" style={{ fontSize: 10, color: 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{subtitle}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <CkLED state="on" />
        <span className="ck-mono" style={{ fontSize: 10, color: 'var(--muted)' }}>{online}/5</span>
      </div>
    </header>
  );
}

Object.assign(window, { CkSidebar, CkTabBar, CkTopBar, CK_ROSTER, CK_TABS });
