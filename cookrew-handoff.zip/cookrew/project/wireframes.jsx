// Wireframes — 4 low-fi sketchy IA studies for Cookrew Arcade layout
// Hand-drawn vibe: dashed lines, labels, no commitment to styling.

const wireStyle = {
  root: {
    fontFamily: 'Caveat, "Comic Sans MS", cursive',
    color: '#222',
    background: '#FAFAF5',
    position: 'relative',
  },
  box: {
    border: '2px dashed #333',
    background: '#fff',
    padding: 8,
    position: 'relative',
  },
  boxSolid: {
    border: '2px solid #333',
    background: '#fff',
    padding: 8,
    position: 'relative',
  },
  label: {
    fontFamily: 'Caveat, cursive',
    fontSize: 16,
    fontWeight: 700,
    color: '#333',
  },
  note: { fontSize: 13, color: '#555', fontStyle: 'italic' },
  stroke: '2px solid #333',
  dash:   '2px dashed #555',
};

// load caveat once
if (typeof document !== 'undefined' && !document.getElementById('wf-font')) {
  const l = document.createElement('link');
  l.id = 'wf-font';
  l.rel = 'stylesheet';
  l.href = 'https://fonts.googleapis.com/css2?family=Caveat:wght@400;700&family=Kalam:wght@400;700&display=swap';
  document.head.appendChild(l);
}

function Scribble({ text, size = 16, bold, style }) {
  return <div style={{ fontFamily: 'Kalam, Caveat, cursive', fontSize: size, fontWeight: bold ? 700 : 400, color: '#222', ...style }}>{text}</div>;
}

function WireBox({ label, note, style, children, fill = '#fff', dashed = true }) {
  return (
    <div style={{
      border: dashed ? '2px dashed #333' : '2px solid #333',
      background: fill,
      position: 'relative',
      ...style,
    }}>
      {label && (
        <div style={{
          position: 'absolute', top: -10, left: 8,
          background: '#FAFAF5', padding: '0 6px',
          fontFamily: 'Kalam, cursive', fontSize: 12, fontWeight: 700, color: '#333',
        }}>{label}</div>
      )}
      <div style={{ padding: 10, paddingTop: label ? 14 : 10, height: '100%' }}>{children}</div>
      {note && <div style={{ position: 'absolute', bottom: 4, right: 6, fontFamily: 'Kalam, cursive', fontSize: 10, color: '#888', fontStyle: 'italic' }}>{note}</div>}
    </div>
  );
}

function ScribbleBar({ label, fill = 0.7, color = '#6BBE58' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontFamily: 'Kalam, cursive', fontSize: 11 }}>
      <span style={{ width: 14 }}>{label}</span>
      <div style={{ flex: 1, height: 8, border: '1.5px solid #333', background: '#eee' }}>
        <div style={{ height: '100%', width: `${fill*100}%`, background: color }} />
      </div>
    </div>
  );
}

function Portrait({ label, bars = true }) {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', fontFamily: 'Kalam, cursive' }}>
      <div style={{ width: 28, height: 28, border: '2px solid #333', background: '#FFE58A', fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>◉</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700 }}>{label}</div>
        {bars && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginTop: 2 }}>
            <ScribbleBar label="HP" fill={0.8} color="#6BBE58" />
            <ScribbleBar label="MP" fill={0.55} color="#4AA3E6" />
          </div>
        )}
      </div>
    </div>
  );
}

// ── VARIANT A — Dock + Pip-Boy corner ────────────────
function WireA() {
  return (
    <div style={{ width: 480, height: 340, position: 'relative', ...wireStyle.root, padding: 12 }}>
      <Scribble text="A · Dock + Pip-Boy Corner" bold size={18} style={{ marginBottom: 6 }} />
      <Scribble text="composer locked to bottom · event feed hovers in corner · sidebar flush left" size={11} style={{ color: '#666', marginBottom: 8 }} />

      <div style={{ position: 'relative', height: 260 }}>
        {/* top bar */}
        <WireBox label="TOP HUD" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 28 }} />
        {/* sidebar */}
        <WireBox label="PARTY" note="HP/MP" style={{ position: 'absolute', top: 34, left: 0, width: 90, bottom: 80, fontSize: 11 }}>
          <Portrait label="alex" bars={false} />
          <div style={{ height: 4 }}/>
          <Portrait label="scout" />
          <div style={{ height: 4 }}/>
          <Portrait label="smith" />
          <div style={{ height: 4 }}/>
          <Portrait label="reflex" />
        </WireBox>
        {/* mission board */}
        <WireBox label="MISSION BOARD" note="tasks + strings" style={{ position: 'absolute', top: 34, left: 96, right: 172, bottom: 80 }}>
          <svg width="100%" height="100%" viewBox="0 0 200 140">
            <rect x="8" y="20" width="40" height="28" fill="#D8F3E6" stroke="#333" strokeWidth="1.5"/>
            <rect x="70" y="20" width="40" height="28" fill="#FFF3AD" stroke="#333" strokeWidth="1.5"/>
            <rect x="70" y="66" width="40" height="28" fill="#DBEAFE" stroke="#333" strokeWidth="1.5"/>
            <rect x="132" y="40" width="40" height="28" fill="#FEE2E2" stroke="#333" strokeWidth="1.5"/>
            <path d="M48 34 Q60 34 70 34" stroke="#7A6AAB" strokeDasharray="3 2" fill="none" strokeWidth="1.5"/>
            <path d="M48 34 Q60 80 70 80" stroke="#7A6AAB" strokeDasharray="3 2" fill="none" strokeWidth="1.5"/>
            <path d="M110 34 Q125 40 132 54" stroke="#7A6AAB" strokeDasharray="3 2" fill="none" strokeWidth="1.5"/>
            <path d="M110 80 Q125 70 132 54" stroke="#7A6AAB" strokeDasharray="3 2" fill="none" strokeWidth="1.5"/>
          </svg>
        </WireBox>
        {/* pip-boy corner */}
        <WireBox label="PIP-BOY FEED" note="float ▦" fill="#2A2412" style={{ position: 'absolute', top: 34, right: 0, width: 168, bottom: 80, color: '#E9B949' }}>
          <div style={{ fontFamily: 'VT323, monospace', fontSize: 11, color: '#E9B949' }}>
            &gt; bundle created<br/>
            &gt; scout claim #01<br/>
            &gt; milestone ✓<br/>
            &gt; fact: ttl 30s<br/>
            &gt; reflex blocked<br/>
            &gt; _
          </div>
        </WireBox>
        {/* composer dock */}
        <WireBox label="COMPOSER · ALWAYS ON" fill="#FFD600" dashed={false} style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 70 }}>
          <div style={{ border: '1.5px solid #333', padding: '6px 10px', background: '#FFFEF5', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
            type prompt · "/" for commands · "@" for agents<span style={{ animation: 'pc-blink 0.7s step-end infinite' }}>▮</span>
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 4, fontFamily: 'Kalam, cursive', fontSize: 10, color: '#333' }}>
            <span>[SEED]</span><span>[ASK]</span><span>[@agent]</span>
            <span style={{ marginLeft: 'auto' }}>⎆ SHIP ▶</span>
          </div>
        </WireBox>
      </div>
    </div>
  );
}

// ── VARIANT B — Overlay feed · full sidebar collapse ─
function WireB() {
  return (
    <div style={{ width: 480, height: 340, position: 'relative', ...wireStyle.root, padding: 12 }}>
      <Scribble text="B · Full-Screen Cabinet" bold size={18} style={{ marginBottom: 6 }} />
      <Scribble text="party collapses to icon-strip · mission board fills · feed summoned as overlay" size={11} style={{ color: '#666', marginBottom: 8 }} />
      <div style={{ position: 'relative', height: 260 }}>
        <WireBox label="TOP HUD" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 28 }} />
        <WireBox label="PARTY-STRIP" note="icons only" style={{ position: 'absolute', top: 34, left: 0, width: 40, bottom: 80, padding: 4 }}>
          {[1,2,3,4].map(i => <div key={i} style={{ width: 24, height: 24, border: '2px solid #333', background: '#FFE58A', marginBottom: 4, fontSize: 10, textAlign: 'center', lineHeight: '20px', fontFamily: 'Kalam, cursive' }}>◉</div>)}
        </WireBox>
        <WireBox label="MISSION BOARD · BIG" style={{ position: 'absolute', top: 34, left: 46, right: 0, bottom: 80 }}>
          <Scribble text="3x3 board + zoom" size={12} style={{ opacity: 0.7 }}/>
        </WireBox>
        <WireBox label="PIP-BOY (summoned by F)" fill="#2A2412" style={{ position: 'absolute', top: 60, right: 30, width: 240, height: 120, color: '#E9B949' }}>
          <div style={{ fontFamily: 'VT323, monospace', fontSize: 11, color: '#E9B949' }}>
            modal drawer that<br/>slides in from right_
          </div>
        </WireBox>
        <WireBox label="COMPOSER" fill="#FFD600" dashed={false} style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 70 }}>
          <div style={{ fontFamily: 'Kalam, cursive', fontSize: 11 }}>big hero input · centered</div>
        </WireBox>
      </div>
    </div>
  );
}

// ── VARIANT C — Pip-boy as WINDOW not corner ─────
function WireC() {
  return (
    <div style={{ width: 480, height: 340, position: 'relative', ...wireStyle.root, padding: 12 }}>
      <Scribble text="C · Three-Screen Cabinet" bold size={18} style={{ marginBottom: 6 }} />
      <Scribble text="sidebar | board | pip-boy as equal columns · composer spans bottom" size={11} style={{ color: '#666', marginBottom: 8 }} />
      <div style={{ position: 'relative', height: 260 }}>
        <WireBox label="TOP HUD" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 28 }} />
        <WireBox label="PARTY · HP/MP" style={{ position: 'absolute', top: 34, left: 0, width: 110, bottom: 80 }}>
          <Portrait label="alex" bars={false}/>
          <div style={{ height: 6 }}/>
          <Portrait label="scout" />
          <div style={{ height: 6 }}/>
          <Portrait label="smith" />
        </WireBox>
        <WireBox label="MISSION BOARD" style={{ position: 'absolute', top: 34, left: 116, right: 176, bottom: 80 }} />
        <WireBox label="PIP-BOY" fill="#2A2412" style={{ position: 'absolute', top: 34, right: 0, width: 170, bottom: 80, color: '#E9B949' }}>
          <div style={{ fontFamily: 'VT323, monospace', fontSize: 11, color: '#E9B949' }}>fixed panel<br/>filter tabs<br/>_</div>
        </WireBox>
        <WireBox label="COMPOSER · FULL WIDTH" fill="#FFD600" dashed={false} style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 70 }}>
          <div style={{ fontFamily: 'Kalam, cursive', fontSize: 11 }}>dock spans the full width · feed stays fixed</div>
        </WireBox>
      </div>
    </div>
  );
}

// ── VARIANT D — Split board + queue ──────────────
function WireD() {
  return (
    <div style={{ width: 480, height: 340, position: 'relative', ...wireStyle.root, padding: 12 }}>
      <Scribble text="D · Stacked — Board Top / Feed Bottom" bold size={18} style={{ marginBottom: 6 }} />
      <Scribble text="board above · ticker below · composer docks feed+input together" size={11} style={{ color: '#666', marginBottom: 8 }} />
      <div style={{ position: 'relative', height: 260 }}>
        <WireBox label="TOP HUD" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 28 }} />
        <WireBox label="PARTY" style={{ position: 'absolute', top: 34, left: 0, width: 110, bottom: 0 }}>
          <Portrait label="alex" bars={false} />
          <div style={{ height: 6 }}/>
          <Portrait label="scout" />
        </WireBox>
        <WireBox label="BOARD (upper)" style={{ position: 'absolute', top: 34, left: 116, right: 0, height: 120 }} />
        <WireBox label="PIP-BOY TICKER (horizontal)" fill="#2A2412" style={{ position: 'absolute', top: 160, left: 116, right: 0, height: 50, color: '#E9B949' }}>
          <div style={{ fontFamily: 'VT323, monospace', fontSize: 11, color: '#E9B949' }}>&gt; scout milestone · &gt; reflex BLOCKED · &gt; digest submitted_</div>
        </WireBox>
        <WireBox label="COMPOSER" fill="#FFD600" dashed={false} style={{ position: 'absolute', left: 116, right: 0, bottom: 0, height: 70 }}>
          <div style={{ fontFamily: 'Kalam, cursive', fontSize: 11 }}>input below scrolling ticker</div>
        </WireBox>
      </div>
    </div>
  );
}

Object.assign(window, { WireA, WireB, WireC, WireD });
