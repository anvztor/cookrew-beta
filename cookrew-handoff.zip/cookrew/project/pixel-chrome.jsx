// Pixel-Chrome — Pip-Boy/Tamagotchi vocabulary for Cookrew Arcade
// Reusable pixelated UI atoms: screens, bars, buttons, badges, scanlines.

// ── Pixel font + global CRT styles ─────────────────────────
if (typeof document !== 'undefined' && !document.getElementById('pc-styles')) {
  // Google fonts: pixel display + retro mono + UI
  const l1 = document.createElement('link');
  l1.rel = 'stylesheet';
  l1.href = 'https://fonts.googleapis.com/css2?family=VT323&family=Press+Start+2P&family=Silkscreen:wght@400;700&family=JetBrains+Mono:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap';
  document.head.appendChild(l1);

  const s = document.createElement('style');
  s.id = 'pc-styles';
  s.textContent = `
    /* Cookrew tokens — cream + yellow + amber phosphor */
    .pc-root {
      --cream: #FAF8F4;
      --cream-hi: #FFFEF5;
      --cream-md: #F5F0E8;
      --ink: #2D2A20;
      --ink-soft: #5C4A1F;
      --muted: #78716C;
      --dim: #A8A29E;
      --line: #2D2A20;
      --line-soft: #E7E5E4;
      --amber: #FFD600;
      --amber-soft: #FFF3AD;
      --amber-cream: #FFFBEB;
      --amber-deep: #D97706;
      --phos: #E9B949;       /* phosphor-amber (pip-boy) */
      --phos-dim: #8A6D1C;
      --phos-glow: #FFD77A;
      --scan-ink: #1C1B16;
      --violet: #9B8ACB;
      --violet-ink: #7A6AAB;
      --violet-soft: #F3E8FF;
      --emerald: #059669;
      --emerald-soft: #D8F3E6;
      --rose: #DC2626;
      --rose-soft: #FEF2F2;
      --blue: #3B82F6;
      --blue-soft: #DBEAFE;
      --hp: #6BBE58;         /* nintendo-green */
      --hp-dim: #2B5A22;
      --mp: #4AA3E6;
      --mp-dim: #1D4A7A;
      --xp: #E6A94A;
    }

    .pc-root, .pc-root * { box-sizing: border-box; }
    .pc-root {
      color: var(--ink);
      font-family: 'Inter', ui-sans-serif, sans-serif;
      background: var(--cream);
      image-rendering: pixelated;
    }

    /* ── typography ─────────────────────────────── */
    .pc-display   { font-family: 'Press Start 2P', monospace; letter-spacing: 0; line-height: 1.3; }
    .pc-screen    { font-family: 'VT323', monospace; letter-spacing: 0.5px; }
    .pc-silk      { font-family: 'Silkscreen', monospace; letter-spacing: 0.5px; text-transform: uppercase; }
    .pc-mono      { font-family: 'JetBrains Mono', ui-monospace, monospace; }

    /* ── CRT scanlines overlay — attach to phosphor screens ─ */
    .pc-crt { position: relative; isolation: isolate; overflow: hidden; }
    .pc-crt::before {
      content: ''; position: absolute; inset: 0; pointer-events: none; z-index: 2;
      background: repeating-linear-gradient(
        to bottom,
        rgba(0,0,0,0) 0px,
        rgba(0,0,0,0) 2px,
        rgba(0,0,0,0.12) 2px,
        rgba(0,0,0,0.12) 3px
      );
      mix-blend-mode: multiply;
    }
    .pc-crt::after {
      content: ''; position: absolute; inset: 0; pointer-events: none; z-index: 3;
      background: radial-gradient(ellipse at center, rgba(0,0,0,0) 60%, rgba(0,0,0,0.35) 100%);
      mix-blend-mode: multiply;
    }

    /* ── chunky pixel border (8-bit double-edge) ─────────── */
    .pc-bevel {
      background: var(--cream-hi);
      border: 2px solid var(--line);
      box-shadow:
        inset 2px 2px 0 var(--cream-hi),
        inset -2px -2px 0 rgba(0,0,0,0.08),
        3px 3px 0 var(--line);
    }
    .pc-bevel-sunken {
      background: var(--cream-md);
      border: 2px solid var(--line);
      box-shadow:
        inset 2px 2px 0 rgba(0,0,0,0.15),
        inset -2px -2px 0 var(--cream-hi);
    }

    /* ── phosphor screen (pip-boy amber) ─────────────────── */
    .pc-phos-screen {
      background: radial-gradient(ellipse at center, #2A2412 0%, #14110A 100%);
      color: var(--phos);
      text-shadow: 0 0 3px rgba(233,185,73,0.7), 0 0 8px rgba(233,185,73,0.3);
      border: 2px solid var(--line);
      box-shadow:
        inset 0 0 16px rgba(233,185,73,0.18),
        inset 2px 2px 0 rgba(233,185,73,0.08),
        3px 3px 0 var(--line);
    }
    .pc-phos-screen .pc-phos-hi { color: var(--phos-glow); text-shadow: 0 0 6px rgba(255,215,122,0.9); }
    .pc-phos-screen .pc-phos-dim { color: var(--phos-dim); text-shadow: none; }

    /* ── green LCD screen (tamagotchi) ───────────────────── */
    .pc-lcd-screen {
      background: #A9C47C;
      color: #2B3E1A;
      font-family: 'VT323', monospace;
      border: 2px solid var(--line);
      box-shadow:
        inset 2px 2px 0 #8BAD5E,
        inset -2px -2px 0 #C3D89C,
        3px 3px 0 var(--line);
      position: relative;
    }
    .pc-lcd-screen::before {
      content: ''; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0px, rgba(0,0,0,0) 3px, rgba(0,0,0,0.06) 3px, rgba(0,0,0,0.06) 4px);
    }

    /* ── pixel button ─────────────────────────────────────── */
    .pc-btn {
      display: inline-flex; align-items: center; justify-content: center; gap: 6px;
      padding: 8px 14px;
      border: 2px solid var(--line);
      background: var(--cream-hi);
      color: var(--ink);
      font-family: 'Silkscreen', monospace;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      line-height: 1;
      cursor: pointer;
      box-shadow:
        inset 1px 1px 0 #FFF,
        inset -2px -2px 0 rgba(0,0,0,0.12),
        3px 3px 0 var(--line);
      transition: transform 80ms linear, box-shadow 80ms linear;
    }
    .pc-btn:hover { transform: translate(1px,1px); box-shadow: inset 1px 1px 0 #FFF, inset -2px -2px 0 rgba(0,0,0,0.12), 2px 2px 0 var(--line); }
    .pc-btn:active { transform: translate(3px,3px); box-shadow: inset 2px 2px 0 rgba(0,0,0,0.18), 0 0 0 var(--line); }
    .pc-btn.primary { background: var(--amber); }
    .pc-btn.danger  { background: var(--rose-soft); color: var(--rose); }
    .pc-btn.ghost   { background: transparent; box-shadow: inset 1px 1px 0 transparent, 0 0 0 var(--line); }
    .pc-btn.sm      { padding: 5px 9px; font-size: 9px; }
    .pc-btn.tiny    { padding: 3px 6px; font-size: 8px; box-shadow: 2px 2px 0 var(--line); }

    /* ── HP / MP bar ──────────────────────────────────────── */
    .pc-bar {
      position: relative;
      display: grid; grid-template-columns: 18px 1fr 38px;
      align-items: center;
      gap: 6px;
      font-family: 'Silkscreen', monospace;
      font-size: 9px;
      font-weight: 700;
      color: var(--ink);
    }
    .pc-bar-label { letter-spacing: 0.5px; }
    .pc-bar-track {
      position: relative;
      height: 10px;
      background: var(--cream-md);
      border: 1.5px solid var(--line);
      box-shadow: inset 1px 1px 0 rgba(0,0,0,0.12);
      overflow: hidden;
    }
    .pc-bar-fill {
      height: 100%;
      background: var(--hp);
      box-shadow: inset 0 -3px 0 var(--hp-dim), inset 0 1px 0 rgba(255,255,255,0.45);
      image-rendering: pixelated;
      transition: width 300ms linear;
    }
    .pc-bar.mp .pc-bar-fill { background: var(--mp); box-shadow: inset 0 -3px 0 var(--mp-dim), inset 0 1px 0 rgba(255,255,255,0.45); }
    .pc-bar.xp .pc-bar-fill { background: var(--xp); box-shadow: inset 0 -3px 0 #8A5A1C, inset 0 1px 0 rgba(255,255,255,0.45); }
    .pc-bar.low .pc-bar-fill { background: var(--rose); box-shadow: inset 0 -3px 0 #7A1515, inset 0 1px 0 rgba(255,255,255,0.3); animation: pc-flash 1s step-end infinite; }
    .pc-bar-val { text-align: right; font-size: 9px; color: var(--muted); font-family: 'JetBrains Mono', monospace; letter-spacing: 0; }

    @keyframes pc-flash { 50% { opacity: .55; } }

    /* segmented tick overlay for bars */
    .pc-bar-track.ticks::after {
      content: ''; position: absolute; inset: 0;
      background-image: repeating-linear-gradient(to right, rgba(0,0,0,0.25) 0 1px, transparent 1px 8px);
      pointer-events: none;
    }

    /* ── badge (pixel chip) ──────────────────────────────── */
    .pc-chip {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 2px 6px;
      border: 1.5px solid var(--line);
      background: var(--cream-hi);
      color: var(--ink);
      font-family: 'Silkscreen', monospace;
      font-size: 8px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      line-height: 1.4;
    }
    .pc-chip.amber { background: var(--amber); }
    .pc-chip.violet { background: var(--violet-soft); color: #5B21B6; }
    .pc-chip.emerald { background: #A9E4C2; color: #0B4F2E; }
    .pc-chip.rose { background: var(--rose-soft); color: var(--rose); }
    .pc-chip.blue { background: var(--blue-soft); color: #1E40AF; }
    .pc-chip.slate { background: var(--cream-md); color: var(--muted); }
    .pc-chip.phos { background: #14110A; color: var(--phos); border-color: var(--phos-dim); text-shadow: 0 0 3px rgba(233,185,73,0.7); }

    /* dot (LED) */
    .pc-led {
      display: inline-block; width: 8px; height: 8px; border-radius: 50%;
      background: var(--muted);
      box-shadow: inset -1px -1px 0 rgba(0,0,0,0.25), 0 0 0 1.5px var(--line), 0 0 4px currentColor;
    }
    .pc-led.on { background: var(--hp); color: var(--hp); }
    .pc-led.busy { background: var(--amber-deep); color: var(--amber-deep); animation: pc-blink 0.8s step-end infinite; }
    .pc-led.off { background: var(--dim); color: transparent; box-shadow: inset -1px -1px 0 rgba(0,0,0,0.25), 0 0 0 1.5px var(--line); }
    .pc-led.red { background: var(--rose); color: var(--rose); }
    @keyframes pc-blink { 50% { opacity: .4; } }

    /* blinking terminal cursor */
    .pc-cursor::after { content: '▮'; margin-left: 2px; animation: pc-blink 0.7s step-end infinite; }

    /* arrow marquee dashes — dep strings */
    .pc-dash { background-image: linear-gradient(to right, var(--line) 50%, transparent 50%); background-size: 6px 2px; background-repeat: repeat-x; height: 2px; }

    /* ── kicker / legend ─────────────────────────────────── */
    .pc-kicker {
      font-family: 'Silkscreen', monospace;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.2px;
      color: var(--muted);
    }

    /* scroll */
    .pc-scroll::-webkit-scrollbar { width: 8px; height: 8px; }
    .pc-scroll::-webkit-scrollbar-track { background: var(--cream-md); }
    .pc-scroll::-webkit-scrollbar-thumb { background: var(--line); border: 1px solid var(--cream-md); }
  `;
  document.head.appendChild(s);
}

// ── HP/MP Bar ──────────────────────────────────────────────
function HPBar({ label, value, max = 100, kind = 'hp' }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const low = kind === 'hp' && pct < 25;
  return (
    <div className={`pc-bar ${kind}${low ? ' low' : ''}`}>
      <div className="pc-bar-label">{label}</div>
      <div className="pc-bar-track ticks">
        <div className="pc-bar-fill" style={{ width: `${pct}%` }} />
      </div>
      <div className="pc-bar-val">{value}/{max}</div>
    </div>
  );
}

// ── LED indicator ──────────────────────────────────────────
function LED({ state = 'on' }) {
  return <span className={`pc-led ${state}`} />;
}

// ── Pixel Button ───────────────────────────────────────────
function PixelBtn({ variant = '', size = '', children, onClick, style, title }) {
  const cls = ['pc-btn', variant, size].filter(Boolean).join(' ');
  return <button className={cls} onClick={onClick} style={style} title={title}>{children}</button>;
}

// ── Phosphor Screen wrapper (with scanlines) ──────────────
function PhosScreen({ children, style, className = '' }) {
  return (
    <div className={`pc-phos-screen pc-crt ${className}`} style={style}>
      {children}
    </div>
  );
}

// ── Pixel sprite portrait (16x16 rendered via CSS grid) ───
const SPRITE_PALETTE = {
  '.': 'transparent',
  '#': '#2D2A20',  // ink
  '+': '#FFD600',  // amber
  'y': '#FFEDB0',  // pale
  'o': '#D97706',  // amber deep
  'p': '#9B8ACB',  // violet
  'P': '#7A6AAB',
  'g': '#6BBE58',  // hp
  'G': '#2B5A22',
  'b': '#4AA3E6',  // mp
  'B': '#1D4A7A',
  'r': '#DC2626',
  'w': '#FFFEF5',
  's': '#A8A29E',
  'e': '#059669',
  'c': '#14110A',  // crt bg
};

function Sprite16({ art, size = 48, bg = '#FFFEF5' }) {
  // art: array of 16 strings of 16 chars
  const rows = art;
  const cell = size / 16;
  return (
    <div style={{
      width: size, height: size,
      display: 'grid',
      gridTemplateColumns: `repeat(16, ${cell}px)`,
      gridTemplateRows: `repeat(16, ${cell}px)`,
      background: bg,
      border: '1.5px solid #2D2A20',
      imageRendering: 'pixelated',
      flexShrink: 0,
    }}>
      {rows.flatMap((row, y) => [...row].map((ch, x) => (
        <div key={`${y}-${x}`} style={{ background: SPRITE_PALETTE[ch] || 'transparent' }} />
      )))}
    </div>
  );
}

// Pre-baked 16x16 portraits
const PORTRAITS = {
  human: [
    '................',
    '................',
    '......####......',
    '.....#yyyy#.....',
    '....#yy##yy#....',
    '....#y####y#....',
    '....#yyyyyy#....',
    '.....#yyyy#.....',
    '......####......',
    '.....#++++#.....',
    '....#+#++#+#....',
    '...#++++++++#...',
    '..#++#++++#++#..',
    '..#+#++++++#+#..',
    '...#+#....#+#...',
    '...####..####...',
  ],
  agent_a: [
    '................',
    '....########....',
    '...#ssssssss#...',
    '..#ss######ss#..',
    '.#ss#gg##gg#ss#.',
    '.#ss#gg##gg#ss#.',
    '.#ss########ss#.',
    '.#ssss#ss#ssss#.',
    '.#sssssssssss#.',
    '..#sss####sss#..',
    '...#########....',
    '....#+++++#.....',
    '...#+++++++#....',
    '..#++#+++#++#...',
    '..#+#++++++#....',
    '..##.......##...',
  ],
  agent_b: [
    '................',
    '......####......',
    '.....#pppp#.....',
    '....#pp##pp#....',
    '...#p#pppp#p#...',
    '...#pppppppp#...',
    '...#p#pppp#p#...',
    '....#pp##pp#....',
    '.....#pppp#.....',
    '......####......',
    '.....#ppPp#.....',
    '....#p#PP#p#....',
    '...#pp####pp#...',
    '...#p#####p#....',
    '....#p####p#....',
    '....##....##....',
  ],
  agent_c: [
    '................',
    '....########....',
    '...#eeeeeeee#...',
    '..#ee######ee#..',
    '.#ee#bb##bb#ee#.',
    '.#ee########ee#.',
    '.#ee#wwwwww#ee#.',
    '.#ee########ee#.',
    '..#ee######ee#..',
    '...#eeeeeeee#...',
    '....#+#++#+#....',
    '...#+++##+++#...',
    '...#+++##+++#...',
    '...#+#++++#+#...',
    '...##......##...',
    '................',
  ],
  agent_d: [
    '................',
    '......####......',
    '.....#rrrr#.....',
    '....#rr##rr#....',
    '...#r#o##o#r#...',
    '...#rr####rr#...',
    '...#rr#oo#rr#...',
    '....#r####r#....',
    '.....#####......',
    '....#+++++#.....',
    '...#+++++++#....',
    '..#+#+++++#+#...',
    '..#+#+++++#+#...',
    '...#+#+++#+#....',
    '....##...##.....',
    '................',
  ],
  agent_e: [
    '................',
    '....########....',
    '...#cccccccc#...',
    '..#cc######cc#..',
    '.#cc#++##++#cc#.',
    '.#cc#+####+#cc#.',
    '.#cc########cc#.',
    '.#cc#ssssss#cc#.',
    '.#cc########cc#.',
    '..#cccccccccc#..',
    '...##########...',
    '....#++++++#....',
    '...#++#++#++#...',
    '...#+#####+#....',
    '...##.....##....',
    '................',
  ],
  system: [
    '................',
    '....########....',
    '...#++++++++#...',
    '..#++########++.',
    '.#++#cccccc#++#.',
    '.#++#c####c#++#.',
    '.#++#c#ee#c#++#.',
    '.#++#c#ee#c#++#.',
    '.#++#c####c#++#.',
    '.#++#cccccc#++#.',
    '.#++########++#.',
    '..#++########+..',
    '...#++++++++#...',
    '....########....',
    '................',
    '................',
  ],
};

// Export to global
Object.assign(window, {
  HPBar, LED, PixelBtn, PhosScreen, Sprite16, PORTRAITS,
});
