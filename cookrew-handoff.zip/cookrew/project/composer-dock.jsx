// Composer Dock — always-on bottom arcade cabinet input w/ slash menu

const SLASH_COMMANDS = [
  { cmd: '/bundle',  desc: 'Start a new bundle from a prompt',    icon: '▷' },
  { cmd: '/claim',   desc: 'Force-claim an open quest',            icon: '◆' },
  { cmd: '/dispatch', desc: 'Send task to specific agent',         icon: '▸' },
  { cmd: '/rerun',   desc: 'Re-run blocked quests',                icon: '↻' },
  { cmd: '/digest',  desc: 'Submit bundle for review',             icon: '▣' },
  { cmd: '/cancel',  desc: 'Cancel active bundle',                 icon: '✕' },
  { cmd: '/status',  desc: 'Print recipe + agent status snapshot', icon: '▦' },
  { cmd: '/fact',    desc: 'Attach a fact to the last milestone',  icon: '§' },
];

const MENTIONS = [
  { tag: '@scout',      kind: 'agent', desc: 'gpt-5-mini · 3 tools' },
  { tag: '@gatekeeper', kind: 'agent', desc: 'claude-opus · 4 tools' },
  { tag: '@smith',      kind: 'agent', desc: 'claude-haiku · 2 tools' },
  { tag: '@reflex',     kind: 'agent', desc: 'codex-tiny · 1 tool' },
  { tag: '@party',      kind: 'broadcast', desc: 'all online agents' },
  { tag: '@alex',       kind: 'human',  desc: 'operator' },
];

function ComposerDock({ target, onTarget, showSlash, onToggleSlash }) {
  const { PixelBtn, LED } = window;
  const [text, setText] = React.useState('');
  const [showMenu, setShowMenu] = React.useState(false);
  const [showMentions, setShowMentions] = React.useState(false);
  const textRef = React.useRef(null);

  // Respond to external "open slash" trigger (from tweaks)
  React.useEffect(() => {
    if (showSlash) setShowMenu(true);
  }, [showSlash]);

  const onChange = (e) => {
    const v = e.target.value;
    setText(v);
    // naive detection
    const last = v.split(/\s/).pop() || '';
    setShowMenu(last.startsWith('/'));
    setShowMentions(last.startsWith('@'));
  };

  const insertCmd = (cmd) => {
    const parts = text.split(/\s/);
    parts[parts.length - 1] = cmd + ' ';
    setText(parts.join(' '));
    setShowMenu(false);
    onToggleSlash?.(false);
    textRef.current?.focus();
  };

  return (
    <div className="pc-composer-dock" style={{
      position: 'relative',
      borderTop: '3px solid var(--line)',
      background: 'var(--cream-hi)',
      padding: '10px 16px 12px',
      flexShrink: 0,
      boxShadow: 'inset 0 2px 0 var(--cream-hi), inset 0 4px 0 rgba(0,0,0,0.05)',
      zIndex: 30,
    }}>
      {/* Slash menu popover */}
      {showMenu && (
        <div className="pc-bevel pc-slash-menu" style={{
          position: 'absolute', left: 16, right: 16, bottom: '100%',
          marginBottom: 6,
          maxHeight: 280, overflowY: 'auto',
          zIndex: 40,
        }}>
          <div style={{ padding: '8px 12px', borderBottom: '2px solid var(--line)', background: 'var(--amber-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9 }}>▸ SLASH COMMANDS</div>
          </div>
          {SLASH_COMMANDS.filter(c => c.cmd.startsWith(text.split(/\s/).pop() || '/')).map(c => (
            <button
              key={c.cmd}
              onClick={() => insertCmd(c.cmd)}
              style={{
                display: 'grid', gridTemplateColumns: '28px 110px 1fr',
                alignItems: 'center', gap: 10,
                width: '100%', padding: '8px 12px',
                background: 'transparent', border: 0,
                borderBottom: '1px dashed var(--line-soft)',
                cursor: 'pointer', textAlign: 'left',
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--amber-cream)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              <span className="pc-silk" style={{ color: 'var(--amber-deep)', fontSize: 14 }}>{c.icon}</span>
              <span className="pc-mono" style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink)' }}>{c.cmd}</span>
              <span style={{ fontSize: 11, color: 'var(--muted)' }}>{c.desc}</span>
            </button>
          ))}
        </div>
      )}

      {/* Mention menu */}
      {showMentions && (
        <div className="pc-bevel" style={{
          position: 'absolute', left: 16, right: 16, bottom: '100%',
          marginBottom: 6, zIndex: 40,
        }}>
          <div style={{ padding: '8px 12px', borderBottom: '2px solid var(--line)', background: 'var(--violet-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9 }}>▸ MENTIONS · @</div>
          </div>
          {MENTIONS.map(m => (
            <div key={m.tag} style={{
              display: 'grid', gridTemplateColumns: '110px 1fr 70px',
              alignItems: 'center', gap: 10, padding: '6px 12px',
              borderBottom: '1px dashed var(--line-soft)',
              fontSize: 12,
            }}>
              <span className="pc-mono" style={{ fontWeight: 700, color: 'var(--violet-ink)' }}>{m.tag}</span>
              <span style={{ color: 'var(--muted)', fontSize: 11 }}>{m.desc}</span>
              <span className="pc-chip slate" style={{ fontSize: 7, justifySelf: 'end' }}>{m.kind}</span>
            </div>
          ))}
        </div>
      )}

      {/* Top row — target pills + level/xp */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ PROMPT →</div>
        <div style={{ display: 'flex', gap: 3, border: '2px solid var(--line)', padding: 2, background: 'var(--cream-md)' }}>
          {[
            { v: 'seed', l: 'SEED BUNDLE' },
            { v: 'ask',  l: 'ASK ORACLE' },
            { v: 'agent', l: '@AGENT' },
          ].map(t => (
            <button key={t.v}
              onClick={() => onTarget?.(t.v)}
              style={{
                padding: '4px 10px',
                background: target === t.v ? 'var(--amber)' : 'transparent',
                border: 0, cursor: 'pointer',
                fontFamily: 'Silkscreen, monospace', fontSize: 9, letterSpacing: 1,
                fontWeight: 700,
                color: target === t.v ? 'var(--ink)' : 'var(--muted)',
              }}>{t.l}</button>
          ))}
        </div>
        <div className="pc-chip phos" style={{ fontSize: 8 }}>◉ 3 AGENTS READY</div>
        <div style={{ flex: 1 }} />
        <div className="pc-mono" style={{ fontSize: 10, color: 'var(--muted)' }}>
          LVL 07 · <span style={{ color: 'var(--amber-deep)', fontWeight: 700 }}>XP 840/1200</span>
        </div>
        <div style={{ width: 80, height: 6, background: 'var(--cream-md)', border: '1.5px solid var(--line)' }}>
          <div style={{ height: '100%', width: '70%', background: 'var(--xp)' }} />
        </div>
      </div>

      {/* Cabinet input — giant ⌘K-style search, arcade-styled */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'auto 1fr auto auto',
        alignItems: 'stretch',
        gap: 0,
        border: '2px solid var(--line)',
        boxShadow: 'inset 2px 2px 0 rgba(0,0,0,0.1), 4px 4px 0 var(--line)',
        background: 'var(--cream-hi)',
      }}>
        {/* Avatar stamp */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '0 12px', borderRight: '2px solid var(--line)',
          background: 'var(--amber)', width: 56,
        }}>
          <div style={{ width: 28, height: 28, background: 'var(--ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--amber)', fontFamily: 'Press Start 2P', fontSize: 9 }}>P1</div>
        </div>

        {/* Input */}
        <textarea
          ref={textRef}
          value={text}
          onChange={onChange}
          rows={1}
          placeholder='type to prompt · "/" for commands · "@" to mention · ⏎ to ship'
          style={{
            resize: 'none', border: 0, outline: 0,
            padding: '14px 14px',
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 14, fontWeight: 500, color: 'var(--ink)',
            background: 'transparent',
            minHeight: 44,
          }}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); setText(''); } }}
        />

        {/* Attachments */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '0 10px', borderLeft: '2px solid var(--line)' }}>
          <PixelBtn variant="ghost" size="tiny" title="attach code ref">📎</PixelBtn>
          <PixelBtn variant="ghost" size="tiny" title="attach fact">§</PixelBtn>
          <PixelBtn variant="ghost" size="tiny" title="record voice">🎙</PixelBtn>
        </div>

        {/* Send */}
        <button
          onClick={() => setText('')}
          style={{
            border: 0, borderLeft: '2px solid var(--line)',
            background: 'var(--amber-deep)',
            color: '#fff',
            padding: '0 20px',
            fontFamily: 'Press Start 2P', fontSize: 11, letterSpacing: 1,
            cursor: 'pointer',
            boxShadow: 'inset 1px 1px 0 rgba(255,255,255,0.35), inset -2px -2px 0 rgba(0,0,0,0.2)',
          }}
        >SHIP ▶</button>
      </div>

      {/* Hints row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 8, fontSize: 10, color: 'var(--muted)', fontFamily: 'JetBrains Mono, monospace' }}>
        <span><kbd style={kbdS}>⌘K</kbd> palette</span>
        <span><kbd style={kbdS}>/</kbd> commands</span>
        <span><kbd style={kbdS}>@</kbd> mentions</span>
        <span><kbd style={kbdS}>⇧⏎</kbd> newline</span>
        <span><kbd style={kbdS}>⏎</kbd> ship</span>
        <div style={{ flex: 1 }} />
        <span>context · <b style={{ color: 'var(--ink)' }}>8,412</b> / 200,000 tok</span>
      </div>
    </div>
  );
}
const kbdS = {
  fontFamily: 'JetBrains Mono, monospace', fontSize: 10,
  border: '1px solid var(--line-soft)', padding: '1px 5px',
  background: 'var(--cream-md)', color: 'var(--ink)',
};

Object.assign(window, { ComposerDock });
