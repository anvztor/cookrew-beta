// Arcade Popouts — 3 modal cards that open inside the workspace:
//  • Cookbook — project's recipe shelf
//  • Recipe History — git commits + facts for one recipe
//  • Bundle Review — human-in-the-loop approval for a bundle
//
// All share the same modal chrome: dimmed CRT backdrop, cream pixel card,
// title bar with close, corner screws.

if (typeof document !== 'undefined' && !document.getElementById('po-styles')) {
  const s = document.createElement('style');
  s.id = 'po-styles';
  s.textContent = `
    .po-backdrop {
      position: absolute; inset: 0; z-index: 80;
      background: rgba(20,17,10,0.55);
      backdrop-filter: blur(2px);
      display: flex; align-items: center; justify-content: center;
      padding: 40px 36px 110px; /* leave composer dock visible */
    }
    .po-backdrop::before {
      content:''; position:absolute; inset:0; pointer-events:none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,.06) 3px 4px);
    }
    .po-card {
      background: var(--cream-hi, #FFFEF5);
      border: 2px solid var(--line, #2D2A20);
      box-shadow: 6px 6px 0 var(--line, #2D2A20);
      position: relative;
      display: flex; flex-direction: column;
      overflow: hidden;
      max-height: 100%;
    }
    .po-titlebar {
      display: flex; align-items: center; justify-content: space-between;
      background: var(--amber, #FFD600);
      border-bottom: 2px solid var(--line, #2D2A20);
      padding: 10px 14px 10px 16px;
      position: relative;
    }
    .po-titlebar::before,
    .po-titlebar::after {
      content:''; position: absolute; top: 50%; transform: translateY(-50%);
      width: 8px; height: 8px; background: var(--line, #2D2A20);
      border-radius: 50%;
    }
    .po-titlebar::before { left: 6px; }
    .po-titlebar::after { right: 34px; }
    .po-close {
      width: 24px; height: 24px;
      border: 2px solid var(--line); background: var(--cream-hi);
      font-family: 'Press Start 2P', monospace; font-size: 10px; line-height: 1;
      display: inline-flex; align-items: center; justify-content: center;
      cursor: pointer;
      box-shadow: 2px 2px 0 var(--line);
    }
    .po-close:hover { transform: translate(1px,1px); box-shadow: 1px 1px 0 var(--line); }
    .po-toolbar {
      display: flex; align-items: center; gap: 8px;
      padding: 8px 14px;
      background: var(--cream-md, #F5F0E8);
      border-bottom: 2px solid var(--line);
    }
  `;
  document.head.appendChild(s);
}

// Shared modal card shell
function PoModal({ width, height, title, subtitle, onClose, toolbar, children }) {
  return (
    <div className="po-backdrop">
      <div className="po-card" style={{ width, height, maxWidth: '100%' }}>
        <div className="po-titlebar">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingLeft: 10 }}>
            <div className="pc-display" style={{ fontSize: 11, color: 'var(--ink)' }}>{title}</div>
            {subtitle && <div className="pc-silk" style={{ fontSize: 9, color: 'var(--ink-soft)' }}>▸ {subtitle}</div>}
          </div>
          <button className="po-close" onClick={onClose}>×</button>
        </div>
        {toolbar && <div className="po-toolbar">{toolbar}</div>}
        <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────
// COOKBOOK — project's shelf of recipe cartridges
// ──────────────────────────────────────────────────────────
function CookbookPopout({ onClose }) {
  const recipes = [
    { id: 'r1', title: 'KREWHUB·API', swatch: 'a', icon: '⎔', v: 'v1.12.4', agents: 5, cook: 2, digests: 38, blurb: 'Control plane HTTP API · bundles, tasks, digests', facts: 142, commits: 847, stale: false },
    { id: 'r2', title: 'KREWHUB·DB',  swatch: 'b', icon: '§', v: 'v0.8.0',  agents: 3, cook: 1, digests: 21, blurb: 'Postgres schema + migrations', facts: 56, commits: 204, stale: false },
    { id: 'r3', title: 'HEARTBEAT',   swatch: 'c', icon: '◉', v: 'v0.3.2',  agents: 2, cook: 1, digests: 12, blurb: 'SSE watchtower · presence stream', facts: 28, commits: 98, stale: false },
    { id: 'r4', title: 'AUTH·8004',   swatch: 'd', icon: '⌘', v: 'v0.1.0',  agents: 1, cook: 0, digests: 3,  blurb: 'Agent identity (ERC-8004)', facts: 9, commits: 31, stale: true },
    { id: 'r5', title: 'WORKER·LITE', swatch: 'e', icon: '▸', v: 'v0.2.1',  agents: 2, cook: 0, digests: 7,  blurb: 'Background queue · task dispatch', facts: 14, commits: 62, stale: false },
    { id: 'r6', title: 'KREWSCHEMAS', swatch: 'f', icon: '≋', v: 'v1.0.0',  agents: 0, cook: 0, digests: 5,  blurb: 'Shared types · fact envelopes', facts: 5, commits: 41, stale: false },
    { id: 'r7', title: 'WATCHTOWER·CLI', swatch: 'b', icon: '◈', v: 'v0.4.0', agents: 1, cook: 0, digests: 4, blurb: 'Operator CLI · tail events', facts: 7, commits: 28, stale: false },
    { id: 'r8', title: 'ONCHAIN·REG', swatch: 'f', icon: '§', v: 'v0.0.3',  agents: 0, cook: 0, digests: 0,  blurb: 'Registry contract (foundry)', facts: 0, commits: 12, stale: true },
  ];
  const { ApCartridge } = window;

  return (
    <PoModal
      width={1200} height={720}
      title="COOKBOOK · KREWHUB"
      subtitle="recipes · artifacts · git"
      onClose={onClose}
      toolbar={<>
        <button className="pc-btn tiny primary">＋ NEW RECIPE</button>
        <button className="pc-btn tiny">⎘ IMPORT REPO</button>
        <div style={{ width: 1, height: 18, background: 'var(--line-soft)' }} />
        <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>SORT:</div>
        <button className="pc-btn tiny primary">RECENT</button>
        <button className="pc-btn tiny">NAME</button>
        <button className="pc-btn tiny">HEAT</button>
        <div style={{ flex: 1 }} />
        <div className="pc-sunken" style={{ padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 6, background: 'var(--cream-hi)', border: '2px solid var(--line)', fontSize: 11 }}>
          <span style={{ color: 'var(--muted)' }}>⌕</span>
          <span className="pc-mono" style={{ fontSize: 10, color: 'var(--muted)' }}>search recipe…</span>
        </div>
        <button className="pc-btn tiny">◱ GRID</button>
        <button className="pc-btn tiny">☰ LIST</button>
      </>}
    >
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* Main shelf */}
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: 20, background: 'var(--cream)' }}>
          {/* Intro strip */}
          <div style={{
            border: '2px solid var(--line)', background: 'var(--amber-cream)',
            padding: '10px 14px', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{ fontSize: 22 }}>📖</div>
            <div style={{ flex: 1 }}>
              <div className="pc-silk" style={{ fontSize: 10, color: 'var(--ink)' }}>▸ THIS IS YOUR COOKBOOK</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 3 }}>
                Each <b style={{ color: 'var(--ink)' }}>recipe</b> is a git repo with facts attached. Agents cook in sandboxes, then submit digests to land on a recipe's main.
              </div>
            </div>
            <button className="pc-btn tiny">? DOCS</button>
          </div>

          <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 10 }}>▸ SHELF · 8 RECIPES</div>
          <div className="ap-shelf" style={{ padding: '28px 18px 20px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18 }}>
            {recipes.map(r => (
              <div key={r.id} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <ApCartridge title={r.title} subtitle={r.v} swatch={r.swatch} icon={r.icon} w="100%" h={164} />
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                  <span className={`ap-led ${r.cook > 0 ? 'busy' : (r.stale ? 'off' : 'on')}`} />
                  <span className="pc-mono" style={{ fontSize: 10, color: 'var(--ink)' }}>
                    {r.cook > 0 ? `${r.cook} cooking` : (r.stale ? 'stale' : 'idle')}
                  </span>
                  <span style={{ marginLeft: 'auto', fontFamily: '"Silkscreen", monospace', fontSize: 9, color: 'var(--muted)' }}>
                    {r.digests}✓ · {r.commits} commits
                  </span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.3 }}>{r.blurb}</div>
                <div style={{ display: 'flex', gap: 4, marginTop: 2 }}>
                  <button className="pc-btn tiny primary" style={{ flex: 1 }}>▶ OPEN</button>
                  <button className="pc-btn tiny" title="history">⌘H</button>
                  <button className="pc-btn tiny" title="facts">≋</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Side panel — artifact relationships */}
        <aside style={{ width: 280, borderLeft: '2px solid var(--line)', background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '10px 14px', borderBottom: '2px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ ARTIFACT ANATOMY</div>
            <div style={{ fontSize: 12, color: 'var(--ink-soft)', marginTop: 6, lineHeight: 1.4 }}>
              Three shapes agents can modify at runtime.
            </div>
          </div>

          {[
            { k:'SANDBOX', c:'violet', d:'Agent scratch. One per claimed task. Ephemeral branch.', stat:'4 live' },
            { k:'RECIPE',  c:'amber',  d:'Git repo + facts ledger. The thing agents cook on.', stat:'8 in book' },
            { k:'COOKBOOK',c:'emerald',d:'Shelf of recipes for this project. One per cookbook.', stat:'this view' },
          ].map(x => (
            <div key={x.k} style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 5 }}>
                <span className={`pc-chip ${x.c}`}>{x.k}</span>
                <span style={{ marginLeft: 'auto', fontFamily: '"Silkscreen", monospace', fontSize: 9, color: 'var(--muted)' }}>{x.stat}</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.4 }}>{x.d}</div>
            </div>
          ))}

          <div style={{ padding: '12px 14px', background: 'var(--cream-md)', borderTop: '2px solid var(--line)', marginTop: 'auto' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ COOKBOOK FACTS · 261 TOTAL</div>
            <div className="pc-phos-screen" style={{ padding: '8px 10px', fontSize: 12, minHeight: 68 }}>
              <div>&gt; fact/schema_v2 <span className="pc-phos-hi">pinned</span></div>
              <div>&gt; fact/rfc_digests</div>
              <div>&gt; fact/heartbeat_7s <span className="pc-phos-dim">TTL 22h</span></div>
              <div>&gt; _<span style={{ animation: 'pc-blink .7s step-end infinite' }}>▮</span></div>
            </div>
          </div>
        </aside>
      </div>
    </PoModal>
  );
}

// ──────────────────────────────────────────────────────────
// RECIPE HISTORY — commits + facts timeline
// ──────────────────────────────────────────────────────────
function RecipeHistoryPopout({ onClose }) {
  const commits = [
    { sha: '4a7c9e1', msg: 'fix: heartbeat retry under flaky DNS', who: 'SCOUT',      kind: 'agent', t: '14m ago', digest: 'bun_482', tag: null, active: true },
    { sha: '3b91c4a', msg: 'feat(cli): task.claim + task.complete', who: 'GATEKEEPER',kind: 'agent', t: '1h ago',  digest: 'bun_471', tag: 'v0.3.1', active: false },
    { sha: '2fe0a13', msg: 'chore: bump fact-envelope schema to v2', who: 'ALEX',     kind: 'human', t: '3h ago',  digest: 'manual', tag: null, active: false },
    { sha: '1d48b2e', msg: 'fix: presence TTL rounded wrong', who: 'SMITH',           kind: 'agent', t: '5h ago',  digest: 'bun_465', tag: null, active: false },
    { sha: '0c7a22f', msg: 'feat: SSE watchtower endpoint', who: 'GATEKEEPER',        kind: 'agent', t: 'yday',    digest: 'bun_458', tag: 'v0.3.0', active: false },
    { sha: 'f2d01e9', msg: 'refactor: split route handlers', who: 'MARINA',           kind: 'human', t: '2d',      digest: 'manual', tag: null, active: false },
    { sha: 'e814c0a', msg: 'feat: bundle → task → digest loop', who: 'GATEKEEPER',    kind: 'agent', t: '3d',      digest: 'bun_441', tag: 'v0.2.0', active: false },
    { sha: 'd5519b4', msg: 'init: krewhub skeleton', who: 'ALEX',                     kind: 'human', t: '7d',      digest: '—',       tag: 'v0.1.0', active: false },
  ];

  const facts = [
    { k: 'fact/schema_v2',      ttl: 'pinned',    who: 'ALEX',   t: '3h',  kind: 'pinned' },
    { k: 'fact/rfc_digests',    ttl: 'pinned',    who: 'ALEX',   t: '2d',  kind: 'pinned' },
    { k: 'fact/heartbeat_7s',   ttl: 'TTL 22h',   who: 'SCOUT',  t: '30m', kind: 'live' },
    { k: 'fact/claim_timeout',  ttl: 'TTL 4h',    who: 'GATEKEEPER', t:'1h', kind: 'live' },
    { k: 'fact/cli_v0_3',       ttl: 'TTL 6h',    who: 'GATEKEEPER', t:'2h', kind: 'live' },
    { k: 'fact/flaky_dns',      ttl: 'TTL 52m',   who: 'SCOUT',  t: '10m', kind: 'event' },
  ];

  return (
    <PoModal
      width={1280} height={740}
      title="RECIPE · KREWHUB·API"
      subtitle="history · v1.12.4 · main"
      onClose={onClose}
      toolbar={<>
        <button className="pc-btn tiny">◀ BACK</button>
        <div style={{ width: 1, height: 18, background: 'var(--line-soft)' }} />
        <button className="pc-btn tiny primary">HISTORY</button>
        <button className="pc-btn tiny">FACTS</button>
        <button className="pc-btn tiny">TREE</button>
        <button className="pc-btn tiny">README</button>
        <div style={{ width: 1, height: 18, background: 'var(--line-soft)' }} />
        <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>BRANCH:</div>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11, padding: '3px 8px', border: '1.5px solid var(--line)', background: 'var(--cream-hi)' }}>main ▾</div>
        <div style={{ flex: 1 }} />
        <span className="pc-chip amber">⟳ 847 COMMITS</span>
        <span className="pc-chip violet">≋ 142 FACTS</span>
        <button className="pc-btn tiny">⎘ CLONE</button>
      </>}
    >
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* Commit timeline */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, borderRight: '2px solid var(--line)' }}>
          <div style={{ padding: '10px 16px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ COMMIT TIMELINE · DESC</div>
            <div style={{ flex: 1 }} />
            <span className="pc-chip slate">AGENT</span>
            <span className="pc-chip slate">HUMAN</span>
            <span className="pc-chip slate">TAGGED</span>
          </div>
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '12px 16px', background: 'var(--cream-hi)' }}>
            <div style={{ position: 'relative', paddingLeft: 28 }}>
              {/* vertical rail */}
              <div style={{ position: 'absolute', left: 8, top: 0, bottom: 0, width: 2, background: 'var(--line)' }} />
              {commits.map((c, i) => (
                <div key={c.sha} style={{ position: 'relative', paddingBottom: 14 }}>
                  {/* node */}
                  <div style={{
                    position: 'absolute', left: -23, top: 4, width: 14, height: 14,
                    background: c.active ? 'var(--amber)' : (c.kind === 'human' ? 'var(--violet-soft)' : 'var(--cream-hi)'),
                    border: '2px solid var(--line)',
                    boxShadow: c.active ? '0 0 0 2px var(--amber-soft)' : 'none',
                  }} />
                  <div style={{
                    border: c.active ? '2px solid var(--amber-deep)' : '2px solid var(--line)',
                    background: c.active ? 'var(--amber-cream)' : 'var(--cream-hi)',
                    padding: '8px 12px',
                    boxShadow: '2px 2px 0 var(--line)',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span className="pc-mono" style={{ fontSize: 11, color: 'var(--ink)', fontWeight: 600 }}>{c.sha}</span>
                      {c.tag && <span className="pc-chip amber" style={{ fontSize: 8 }}>{c.tag}</span>}
                      <span className={`pc-chip ${c.kind === 'human' ? 'violet' : 'blue'}`} style={{ fontSize: 8 }}>{c.who}</span>
                      {c.digest !== '—' && c.digest !== 'manual' && (
                        <span className="pc-chip emerald" style={{ fontSize: 8 }}>↑ {c.digest}</span>
                      )}
                      {c.digest === 'manual' && (
                        <span className="pc-chip slate" style={{ fontSize: 8 }}>DIRECT PUSH</span>
                      )}
                      <span style={{ marginLeft: 'auto', fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: 'var(--muted)' }}>{c.t}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--ink)', fontFamily: '"JetBrains Mono", monospace' }}>{c.msg}</div>
                    {c.active && (
                      <div style={{ marginTop: 6, paddingTop: 6, borderTop: '1px dashed var(--line-soft)', display: 'flex', gap: 4 }}>
                        <button className="pc-btn tiny primary">▸ VIEW DIFF</button>
                        <button className="pc-btn tiny">▸ FACT REFS (3)</button>
                        <button className="pc-btn tiny">▸ BUNDLE</button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Facts ledger */}
        <aside style={{ width: 380, display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)' }}>
          <div style={{ padding: '10px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ FACTS LEDGER</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 4 }}>
              Context appended to this recipe. Agents read on claim, write on digest.
            </div>
          </div>
          <div style={{ display: 'flex', padding: '8px 14px', gap: 4, background: 'var(--cream-md)', borderBottom: '1px dashed var(--line-soft)' }}>
            <button className="pc-btn tiny primary">ALL (6)</button>
            <button className="pc-btn tiny">PINNED (2)</button>
            <button className="pc-btn tiny">LIVE (3)</button>
            <button className="pc-btn tiny">EVENT (1)</button>
          </div>
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '10px 14px' }}>
            {facts.map((f, i) => (
              <div key={f.k} style={{
                border: '1.5px solid var(--line)',
                background: f.kind === 'pinned' ? 'var(--amber-cream)' : 'var(--cream-hi)',
                padding: '8px 10px', marginBottom: 8,
                boxShadow: '2px 2px 0 var(--line)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                  <span className="pc-mono" style={{ fontSize: 11, color: 'var(--ink)' }}>{f.k}</span>
                  {f.kind === 'pinned' && <span className="pc-chip amber" style={{ fontSize: 8 }}>📌 PIN</span>}
                  {f.kind === 'event'  && <span className="pc-chip rose"  style={{ fontSize: 8 }}>⚡ EVENT</span>}
                  {f.kind === 'live'   && <span className="pc-chip blue"  style={{ fontSize: 8 }}>◉ LIVE</span>}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: '"Silkscreen", monospace', fontSize: 9, color: 'var(--muted)' }}>
                  <span>by {f.who}</span>
                  <span>·</span>
                  <span>{f.t}</span>
                  <span style={{ marginLeft: 'auto' }}>{f.ttl}</span>
                </div>
              </div>
            ))}
            <button className="pc-btn sm" style={{ width: '100%', marginTop: 4 }}>＋ APPEND FACT</button>
          </div>

          {/* Relationship glossary */}
          <div style={{ padding: '10px 14px', borderTop: '2px solid var(--line)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ DATA FLOW</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: 'var(--ink-soft)', lineHeight: 1.55 }}>
              sandbox<span style={{ color: 'var(--muted)' }}> ─▶ </span>recipe<span style={{ color: 'var(--muted)' }}> ─▶ </span>cookbook<br/>
              <span style={{ color: 'var(--muted)' }}>claim</span> <span style={{ color: 'var(--muted)' }}>cook</span> <span style={{ color: 'var(--muted)' }}>digest ✓ </span>
            </div>
          </div>
        </aside>
      </div>
    </PoModal>
  );
}

// ──────────────────────────────────────────────────────────
// BUNDLE REVIEW — human-in-the-loop approval
// ──────────────────────────────────────────────────────────
function BundleReviewPopout({ onClose, state = 'ready' }) {
  // state: 'ready' = all checks passed, ready to merge
  //        'blocked' = something needs attention

  const blocked = state === 'blocked';
  const tasks = [
    { id: 't1', t: '#01 heartbeat loop in krewcli',        by: 'SCOUT',      status: 'ok',      files: 4, adds: 86,  dels: 12, checks: 'PASS' },
    { id: 't2', t: '#02 task.claim + task.complete routes',by: 'GATEKEEPER', status: 'ok',      files: 7, adds: 142, dels: 23, checks: 'PASS' },
    { id: 't3', t: '#03 SSE watchtower presence stream',   by: 'GATEKEEPER', status: 'ok',      files: 3, adds: 58,  dels: 4,  checks: 'PASS' },
    { id: 't4', t: '#04 retry under flaky DNS',            by: 'SCOUT',      status: blocked ? 'blocked' : 'ok',  files: 2, adds: 24,  dels: 11, checks: blocked ? 'BLOCKED' : 'PASS' },
    { id: 't5', t: '#05 fact-envelope v2 schema',          by: 'SMITH',      status: 'ok',      files: 1, adds: 38,  dels: 5,  checks: 'PASS' },
  ];
  const factRefs = [
    { k: 'fact/schema_v2 → bumped', kind: 'mutated' },
    { k: 'fact/heartbeat_7s → +retry_ms', kind: 'mutated' },
    { k: 'fact/claim_timeout (new)', kind: 'added' },
    { k: 'fact/cli_v0_3 (new)', kind: 'added' },
    { k: 'fact/flaky_dns (event)', kind: 'observed' },
  ];

  const diffLines = [
    { t: 'ctx', s: 'apps/krewcli/src/heartbeat.ts', n: '@@ -14,6 +14,12 @@' },
    { t: 'ctx', s: '',   n: 'export async function tick() {' },
    { t: 'del', s: '- ', n: '  const res = await fetch(hub + "/presence");' },
    { t: 'add', s: '+ ', n: '  const res = await retry(() => fetch(hub + "/presence"), {' },
    { t: 'add', s: '+ ', n: '    tries: 3, backoff_ms: 250,' },
    { t: 'add', s: '+ ', n: '  });' },
    { t: 'ctx', s: '  ', n: '  if (!res.ok) throw new Error("heartbeat_failed");' },
    { t: 'ctx', s: '  ', n: '  return res.json();' },
    { t: 'ctx', s: '  ', n: '}' },
    { t: 'ctx', s: '', n: '' },
    { t: 'ctx', s: '', n: 'apps/krewhub/src/routes/claim.ts' },
    { t: 'ctx', s: '  ', n: '  // resolve agent from ERC-8004 header' },
    { t: 'add', s: '+ ', n: '  const agent = await auth.resolve(req.headers.get("x-agent-sig"));' },
    { t: 'add', s: '+ ', n: '  if (!agent) return new Response("401", { status: 401 });' },
    { t: 'ctx', s: '  ', n: '  const task = await tasks.claim(agent.id, body.task_id);' },
  ];

  return (
    <PoModal
      width={1340} height={780}
      title="BUNDLE REVIEW"
      subtitle={`bun_482 · ${blocked ? 'BLOCKED' : 'READY TO MERGE'}`}
      onClose={onClose}
      toolbar={<>
        <button className="pc-btn tiny">◀ BACK TO BOARD</button>
        <div style={{ width: 1, height: 18, background: 'var(--line-soft)' }} />
        <span className="pc-chip amber">＋ 348</span>
        <span className="pc-chip rose">− 55</span>
        <span className="pc-chip slate">17 FILES</span>
        <span className="pc-chip violet">5 TASKS</span>
        <span className={`pc-chip ${blocked ? 'rose' : 'emerald'}`}>{blocked ? '⚠ 1 BLOCKED' : '✓ ALL PASS'}</span>
        <div style={{ flex: 1 }} />
        <button className="pc-btn tiny">◎ RECHECK</button>
        <button className="pc-btn tiny" style={{ background: '#FEE2E2', color: '#DC2626' }}>✗ REJECT</button>
        <button className={`pc-btn tiny ${blocked ? '' : 'primary'}`} style={blocked ? { opacity: 0.4, cursor: 'not-allowed' } : {}}>
          ✓ APPROVE & MERGE
        </button>
      </>}
    >
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        {/* Left: task checklist + overall status */}
        <div style={{ width: 360, borderRight: '2px solid var(--line)', display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)' }}>
          {/* Hero summary */}
          <div style={{
            padding: '14px 16px',
            background: blocked ? 'linear-gradient(180deg, #FEE2E2 0%, #FCD5D5 100%)' : 'linear-gradient(180deg, #D8F3E6 0%, #BFE8D2 100%)',
            borderBottom: '2px solid var(--line)',
          }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--ink-soft)' }}>▸ HUMAN-IN-THE-LOOP · STAGE 3/3</div>
            <div className="pc-display" style={{ fontSize: 13, marginTop: 6, color: 'var(--ink)', lineHeight: 1.35 }}>
              "ADD KREWCLI PRESENCE<br/>& TASK CLAIMING"
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 10 }}>
              {blocked ? <>
                <span className="pc-led red" />
                <span className="pc-mono" style={{ fontSize: 11, color: 'var(--rose)', fontWeight: 600 }}>BLOCKED · 1 check failed</span>
              </> : <>
                <span className="pc-led on" />
                <span className="pc-mono" style={{ fontSize: 11, color: 'var(--emerald)', fontWeight: 600 }}>READY · all checks pass</span>
              </>}
            </div>
          </div>

          {/* Checklist */}
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '12px 14px' }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 10 }}>▸ TASKS · 5</div>
            {tasks.map(t => {
              const ok = t.status === 'ok';
              return (
                <div key={t.id} style={{
                  border: '1.5px solid var(--line)',
                  background: ok ? 'var(--cream-hi)' : '#FEE2E2',
                  padding: '8px 10px',
                  marginBottom: 6,
                  boxShadow: '2px 2px 0 var(--line)',
                  position: 'relative',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{
                      width: 16, height: 16, border: '2px solid var(--line)',
                      background: ok ? 'var(--emerald)' : 'var(--rose)',
                      color: '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: '"Press Start 2P", monospace', fontSize: 8, flexShrink: 0,
                    }}>{ok ? '✓' : '!'}</div>
                    <div style={{ flex: 1, fontSize: 12, color: 'var(--ink)', fontWeight: 500 }}>{t.t}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 10, marginTop: 5, paddingLeft: 24, fontFamily: '"Silkscreen", monospace', fontSize: 9, color: 'var(--muted)' }}>
                    <span>{t.by}</span>
                    <span>·</span>
                    <span>{t.files}f</span>
                    <span style={{ color: 'var(--emerald)' }}>+{t.adds}</span>
                    <span style={{ color: 'var(--rose)' }}>−{t.dels}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 4, marginTop: 6, paddingLeft: 24 }}>
                    <span className="pc-chip slate" style={{ fontSize: 8 }}>TYPECHECK ✓</span>
                    <span className="pc-chip slate" style={{ fontSize: 8 }}>TESTS ✓</span>
                    <span className={`pc-chip ${ok ? 'slate' : 'rose'}`} style={{ fontSize: 8 }}>E2E {ok ? '✓' : '✗'}</span>
                  </div>
                  {!ok && (
                    <div style={{ marginTop: 6, padding: '6px 8px', background: '#FFFEF5', border: '1.5px dashed var(--rose)', fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: 'var(--rose)' }}>
                      e2e: retry count &lt; expected (got 1, want 3). reopen? reclaim?
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Blocked banner at bottom if blocked */}
          {blocked ? (
            <div style={{ padding: '12px 14px', borderTop: '2px solid var(--line)', background: '#FEE2E2' }}>
              <div className="pc-silk" style={{ fontSize: 10, color: 'var(--rose)', marginBottom: 6 }}>▸ BLOCKED · REQUIRES HUMAN</div>
              <div style={{ fontSize: 11, color: 'var(--ink)', lineHeight: 1.4, marginBottom: 6 }}>
                Task #04 failed e2e. Merge disabled until resolved.
              </div>
              <div style={{ display: 'flex', gap: 4 }}>
                <button className="pc-btn tiny">⇅ REOPEN</button>
                <button className="pc-btn tiny">@ REASSIGN</button>
                <button className="pc-btn tiny primary">✎ OVERRIDE</button>
              </div>
            </div>
          ) : (
            <div style={{ padding: '12px 14px', borderTop: '2px solid var(--line)', background: 'var(--amber-cream)' }}>
              <div className="pc-silk" style={{ fontSize: 10, color: 'var(--ink-soft)', marginBottom: 6 }}>▸ MERGE PLAN</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: 'var(--ink)', lineHeight: 1.6 }}>
                squash 5 tasks ─▶ <b>main</b><br/>
                tag: <b>v1.12.4</b> · digest: <b>bun_482</b><br/>
                <span style={{ color: 'var(--muted)' }}># facts persist, events expire 7d</span>
              </div>
              <button className="pc-btn sm primary" style={{ width: '100%', marginTop: 8 }}>✓ APPROVE & MERGE</button>
            </div>
          )}
        </div>

        {/* Center: code diff */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--cream-hi)' }}>
          <div style={{ padding: '10px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ CODE REF · DIFF</div>
            <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11, color: 'var(--ink)' }}>task #04 · 2 files</div>
            <div style={{ flex: 1 }} />
            <button className="pc-btn tiny">◁</button>
            <button className="pc-btn tiny primary">UNIFIED</button>
            <button className="pc-btn tiny">SPLIT</button>
            <button className="pc-btn tiny">▷</button>
          </div>
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', fontFamily: '"JetBrains Mono", monospace', fontSize: 12, lineHeight: 1.55 }}>
            {diffLines.map((l, i) => {
              const bg = l.t === 'add' ? '#E8F7E0' : l.t === 'del' ? '#FEE2E2' : (l.n.startsWith('@@') ? '#FFF3AD' : (l.n.endsWith('.ts') ? 'var(--cream-md)' : 'transparent'));
              const col = l.t === 'add' ? '#1A6B2E' : l.t === 'del' ? '#9B1717' : (l.n.startsWith('@@') ? 'var(--ink-soft)' : 'var(--ink)');
              const bold = l.n.endsWith('.ts');
              return (
                <div key={i} style={{
                  display: 'flex', alignItems: 'baseline',
                  background: bg, color: col,
                  padding: '1px 12px',
                  borderLeft: l.t === 'add' ? '3px solid #6BBE58' : l.t === 'del' ? '3px solid #DC2626' : '3px solid transparent',
                  fontWeight: bold ? 600 : 400,
                  minHeight: 18,
                }}>
                  <span style={{ width: 22, opacity: .5, textAlign: 'right', fontSize: 10 }}>{i+1}</span>
                  <span style={{ width: 18, opacity: .7 }}>{l.s}</span>
                  <span style={{ whiteSpace: 'pre' }}>{l.n}</span>
                </div>
              );
            })}
          </div>
          {/* Inline comment */}
          <div style={{ borderTop: '2px solid var(--line)', background: 'var(--cream-md)', padding: '10px 14px' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ REVIEW NOTES · 1</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ width: 22, height: 22, background: 'var(--amber)', border: '1.5px solid var(--line)', fontFamily: '"Press Start 2P", monospace', fontSize: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>A</div>
              <div style={{ flex: 1, border: '1.5px solid var(--line)', background: 'var(--cream-hi)', padding: '6px 10px', fontSize: 11, color: 'var(--ink)' }}>
                <b>ALEX</b> <span style={{ color: 'var(--muted)', fontFamily: '"Silkscreen", monospace', fontSize: 9 }}>2m · line 8</span>
                <div style={{ marginTop: 2 }}>{blocked ? "why only 3 retries? the fact says 5 — double-check against fact/heartbeat_7s" : "lgtm — retry envelope matches the ADR. ship it"}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: facts refs + approvers */}
        <aside style={{ width: 300, borderLeft: '2px solid var(--line)', background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '10px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ FACT REFS</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 4 }}>Context this bundle reads/writes.</div>
          </div>
          <div className="pc-scroll" style={{ overflow: 'auto', padding: '10px 14px', maxHeight: 280 }}>
            {factRefs.map((f, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: i < factRefs.length - 1 ? '1px dashed var(--line-soft)' : 'none' }}>
                <span style={{
                  width: 18, height: 18, border: '1.5px solid var(--line)',
                  background: f.kind === 'added' ? '#A9E4C2' : f.kind === 'mutated' ? 'var(--amber)' : 'var(--violet-soft)',
                  fontFamily: '"Press Start 2P", monospace', fontSize: 8,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                }}>{f.kind === 'added' ? '+' : f.kind === 'mutated' ? '~' : '◉'}</span>
                <span className="pc-mono" style={{ fontSize: 10, flex: 1, color: 'var(--ink)' }}>{f.k}</span>
              </div>
            ))}
          </div>

          <div style={{ padding: '10px 14px', borderTop: '2px solid var(--line)', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ APPROVERS · 2/2</div>
          </div>
          <div style={{ padding: '10px 14px' }}>
            {[
              { n: 'ALEX',   r: 'operator · required', ok: !blocked, c: '#FFD600' },
              { n: 'MARINA', r: 'owner · required',    ok: !blocked, c: '#4AA3E6' },
            ].map((a, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0' }}>
                <div style={{ width: 26, height: 26, background: a.c, border: '1.5px solid var(--line)', fontFamily: '"Press Start 2P", monospace', fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{a.n[0]}</div>
                <div style={{ flex: 1 }}>
                  <div className="pc-silk" style={{ fontSize: 10 }}>{a.n}</div>
                  <div style={{ fontFamily: '"Silkscreen", monospace', fontSize: 9, color: 'var(--muted)' }}>{a.r}</div>
                </div>
                {a.ok ? <span className="pc-chip emerald" style={{ fontSize: 8 }}>✓ OK</span> : <span className="pc-chip slate" style={{ fontSize: 8 }}>⏳ WAIT</span>}
              </div>
            ))}
          </div>

          {/* Phosphor post-merge preview */}
          <div style={{ padding: '10px 14px', marginTop: 'auto', borderTop: '2px solid var(--line)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ POST-MERGE PREVIEW</div>
            <div className="pc-phos-screen" style={{ padding: '8px 10px', fontSize: 12, minHeight: 96 }}>
              <div>&gt; squash 5 ─▶ main</div>
              <div>&gt; tag <span className="pc-phos-hi">v1.12.4</span></div>
              <div>&gt; digest <span className="pc-phos-hi">bun_482</span> ✓</div>
              <div className="pc-phos-dim">&gt; anchor onchain... queued</div>
              <div>&gt; facts: +2 ~2 observed 1</div>
              <div>&gt; _<span style={{ animation: 'pc-blink .7s step-end infinite' }}>▮</span></div>
            </div>
          </div>
        </aside>
      </div>
    </PoModal>
  );
}

Object.assign(window, { CookbookPopout, RecipeHistoryPopout, BundleReviewPopout });
