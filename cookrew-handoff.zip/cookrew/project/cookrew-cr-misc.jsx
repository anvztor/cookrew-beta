// ════════════════════════════════════════════════════════════
// Cookrew · Misc — atoms (Button, Chip, LED, Bar, Sprite, Input)
// Cream + amber + phosphor pixel-chrome aesthetic.
// All atoms are CSS-namespaced under .cr to avoid host bleed.
// ════════════════════════════════════════════════════════════

if (typeof document !== 'undefined' && !document.getElementById('cr-misc-styles')) {
  const f = document.createElement('link');
  f.rel = 'stylesheet';
  f.href = 'https://fonts.googleapis.com/css2?family=VT323&family=Silkscreen:wght@400;700&family=JetBrains+Mono:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap';
  document.head.appendChild(f);

  const s = document.createElement('style');
  s.id = 'cr-misc-styles';
  s.textContent = `
    .cr {
      --cream:#FAF8F4; --cream-hi:#FFFEF5; --cream-md:#F5F0E8; --cream-lo:#ECE6DA;
      --ink:#2D2A20; --ink-soft:#5C4A1F; --muted:#78716C; --dim:#A8A29E;
      --line:#2D2A20; --line-soft:#D9D3C5;
      --amber:#FFD600; --amber-soft:#FFF3AD; --amber-deep:#D97706;
      --phos:#E9B949; --phos-dim:#8A6D1C; --phos-glow:#FFD77A; --phos-bg:#14110A;
      --hp:#6BBE58; --hp-dim:#2B5A22; --mp:#4AA3E6; --mp-dim:#1D4A7A;
      --rose:#DC2626; --rose-soft:#FEF2F2; --emerald:#059669;
      --violet:#9B8ACB; --violet-soft:#F3E8FF;
      color:var(--ink); font-family:'Inter',system-ui,sans-serif; box-sizing:border-box;
    }
    .cr *,.cr *::before,.cr *::after{box-sizing:border-box}
    .cr-display{font-family:'Silkscreen',monospace;text-transform:uppercase;letter-spacing:.5px;font-weight:700}
    .cr-screen {font-family:'VT323',monospace;letter-spacing:.5px}
    .cr-mono   {font-family:'JetBrains Mono',ui-monospace,monospace}
    .cr-kicker {font-family:'Silkscreen',monospace;font-weight:700;text-transform:uppercase;letter-spacing:1.4px;color:var(--muted)}

    .cr-crt{position:relative;isolation:isolate}
    .cr-crt::before{content:'';position:absolute;inset:0;pointer-events:none;z-index:2;
      background:repeating-linear-gradient(to bottom,rgba(0,0,0,0) 0 2px,rgba(0,0,0,.10) 2px 3px);mix-blend-mode:multiply}

    .cr-bevel{background:var(--cream-hi);border:2px solid var(--line);
      box-shadow:inset 1.5px 1.5px 0 rgba(255,255,255,.7),inset -1.5px -1.5px 0 rgba(0,0,0,.06),3px 3px 0 var(--line)}
    .cr-bevel-sunken{background:var(--cream-md);border:2px solid var(--line);
      box-shadow:inset 2px 2px 0 rgba(0,0,0,.12),inset -1.5px -1.5px 0 var(--cream-hi)}
    .cr-phos{background:radial-gradient(ellipse at center,#2A2412 0%,var(--phos-bg) 100%);color:var(--phos);
      text-shadow:0 0 3px rgba(233,185,73,.7),0 0 8px rgba(233,185,73,.25);
      border:2px solid var(--line);box-shadow:inset 0 0 14px rgba(233,185,73,.18),3px 3px 0 var(--line)}
    .cr-phos-hi{color:var(--phos-glow);text-shadow:0 0 6px rgba(255,215,122,.9)}
    .cr-phos-dim{color:var(--phos-dim);text-shadow:none}

    .cr-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;
      padding:10px 14px;min-height:36px;border:2px solid var(--line);background:var(--cream-hi);
      color:var(--ink);font-family:'Silkscreen',monospace;font-size:11px;font-weight:700;
      text-transform:uppercase;letter-spacing:1px;line-height:1;cursor:pointer;user-select:none;
      box-shadow:inset 1px 1px 0 #FFF,inset -2px -2px 0 rgba(0,0,0,.10),3px 3px 0 var(--line);
      transition:transform 80ms,box-shadow 80ms;touch-action:manipulation}
    .cr-btn:hover{transform:translate(1px,1px);box-shadow:inset 1px 1px 0 #FFF,inset -2px -2px 0 rgba(0,0,0,.10),2px 2px 0 var(--line)}
    .cr-btn:active{transform:translate(3px,3px);box-shadow:inset 2px 2px 0 rgba(0,0,0,.18),0 0 0 var(--line)}
    .cr-btn.primary{background:var(--amber)}
    .cr-btn.danger {background:var(--rose-soft);color:var(--rose)}
    .cr-btn.ghost  {background:transparent;box-shadow:0 0 0 var(--line);border-color:var(--line-soft)}
    .cr-btn.sm{padding:6px 10px;font-size:9px;min-height:28px}
    .cr-btn.tiny{padding:4px 7px;font-size:8px;min-height:22px;box-shadow:2px 2px 0 var(--line)}
    .cr-btn.touch{min-height:44px;padding:12px 18px;font-size:12px}
    .cr-btn.block{width:100%}

    .cr-chip{display:inline-flex;align-items:center;gap:4px;padding:3px 7px;
      border:1.5px solid var(--line);background:var(--cream-hi);
      font-family:'Silkscreen',monospace;font-size:8px;font-weight:700;
      text-transform:uppercase;letter-spacing:.6px;line-height:1.4}
    .cr-chip.amber {background:var(--amber)}
    .cr-chip.violet{background:var(--violet-soft);color:#5B21B6}
    .cr-chip.emerald{background:#A9E4C2;color:#0B4F2E}
    .cr-chip.rose  {background:var(--rose-soft);color:var(--rose)}
    .cr-chip.blue  {background:#DBEAFE;color:#1E40AF}
    .cr-chip.slate {background:var(--cream-md);color:var(--muted)}
    .cr-chip.phos  {background:var(--phos-bg);color:var(--phos);border-color:var(--phos-dim);text-shadow:0 0 3px rgba(233,185,73,.7)}

    .cr-led{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--muted);
      box-shadow:inset -1px -1px 0 rgba(0,0,0,.25),0 0 0 1.5px var(--line),0 0 4px currentColor}
    .cr-led.on{background:var(--hp);color:var(--hp)}
    .cr-led.busy{background:var(--amber-deep);color:var(--amber-deep);animation:cr-blink .8s step-end infinite}
    .cr-led.off{background:var(--dim);color:transparent}
    .cr-led.red{background:var(--rose);color:var(--rose)}
    @keyframes cr-blink{50%{opacity:.35}}
    @keyframes cr-flash{50%{opacity:.55}}

    .cr-bar{display:grid;grid-template-columns:18px 1fr 42px;gap:6px;align-items:center;
      font-family:'Silkscreen',monospace;font-size:9px;font-weight:700}
    .cr-bar-track{position:relative;height:10px;background:var(--cream-md);border:1.5px solid var(--line);
      box-shadow:inset 1px 1px 0 rgba(0,0,0,.12);overflow:hidden}
    .cr-bar-track::after{content:'';position:absolute;inset:0;
      background-image:repeating-linear-gradient(to right,rgba(0,0,0,.22) 0 1px,transparent 1px 8px);pointer-events:none}
    .cr-bar-fill{height:100%;background:var(--hp);
      box-shadow:inset 0 -3px 0 var(--hp-dim),inset 0 1px 0 rgba(255,255,255,.4);transition:width 300ms}
    .cr-bar.mp .cr-bar-fill{background:var(--mp);box-shadow:inset 0 -3px 0 var(--mp-dim),inset 0 1px 0 rgba(255,255,255,.4)}
    .cr-bar.xp .cr-bar-fill{background:#E6A94A;box-shadow:inset 0 -3px 0 #8A5A1C,inset 0 1px 0 rgba(255,255,255,.4)}
    .cr-bar.low .cr-bar-fill{background:var(--rose);animation:cr-flash 1s step-end infinite}
    .cr-bar-val{text-align:right;font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace}

    .cr-tok{display:grid;grid-template-columns:18px 1fr auto;gap:6px;align-items:center;
      font-family:'Silkscreen',monospace;font-size:8px;font-weight:700}
    .cr-tok-track{display:flex;gap:1px;padding:1px;height:10px;background:var(--cream-md);border:1.5px solid var(--line);box-shadow:inset 1px 1px 0 rgba(0,0,0,.18)}
    .cr-tok-seg{flex:1;background:transparent;box-shadow:inset 0 0 0 .5px rgba(0,0,0,.05)}
    .cr-tok.hp    .cr-tok-seg.on{background:var(--hp);box-shadow:inset 0 -2px 0 var(--hp-dim)}
    .cr-tok.mp    .cr-tok-seg.on{background:var(--mp);box-shadow:inset 0 -2px 0 var(--mp-dim)}
    .cr-tok.amber .cr-tok-seg.on{background:var(--amber-deep);box-shadow:inset 0 -2px 0 #8A5A1C}
    .cr-tok.rose  .cr-tok-seg.on{background:var(--rose);box-shadow:inset 0 -2px 0 #7A1515;animation:cr-flash .9s step-end infinite}
    .cr-tok-val{text-align:right;font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace;white-space:nowrap}

    .cr-input{width:100%;border:2px solid var(--line);background:var(--cream-hi);padding:11px 12px;
      font-family:'JetBrains Mono',monospace;font-size:13px;color:var(--ink);
      box-shadow:inset 2px 2px 0 rgba(0,0,0,.10);outline:none}
    .cr-input:focus{box-shadow:inset 2px 2px 0 rgba(0,0,0,.10),0 0 0 2px var(--amber)}

    .cr-scroll::-webkit-scrollbar{width:8px;height:8px}
    .cr-scroll::-webkit-scrollbar-track{background:var(--cream-md)}
    .cr-scroll::-webkit-scrollbar-thumb{background:var(--line)}
    .cr-noscrollbar{scrollbar-width:none}
    .cr-noscrollbar::-webkit-scrollbar{display:none}
  `;
  document.head.appendChild(s);
}

// ── Atoms ───────────────────────────────────────────
function CrButton({ variant='', size='', block, touch, children, onClick, style, title, type }) {
  const cls = ['cr-btn', variant, size, block && 'block', touch && 'touch'].filter(Boolean).join(' ');
  return <button type={type} className={cls} onClick={onClick} style={style} title={title}>{children}</button>;
}
function CrChip({ tone='', children, style }) {
  return <span className={['cr-chip', tone].filter(Boolean).join(' ')} style={style}>{children}</span>;
}
function CrLED({ state='on', style }) { return <span className={`cr-led ${state}`} style={style} />; }
function CrBar({ label, value, max=100, kind='hp' }) {
  const pct = Math.max(0, Math.min(100, (value/max)*100));
  const low = kind === 'hp' && pct < 25;
  return (
    <div className={`cr-bar ${kind}${low?' low':''}`}>
      <div>{label}</div>
      <div className="cr-bar-track"><div className="cr-bar-fill" style={{width: pct+'%'}} /></div>
      <div className="cr-bar-val">{value}/{max}</div>
    </div>
  );
}
function fmtTok(n) {
  if (n >= 1_000_000) return (n/1_000_000).toFixed(n>=10_000_000?0:1).replace('.0','')+'M';
  if (n >= 1_000) return (n/1_000).toFixed(n>=10_000?0:1).replace('.0','')+'k';
  return String(n);
}
function CrTokBar({ label='5h', used=0, max=1, kind='mp', segments=12 }) {
  const remaining = Math.max(0, max - used);
  const remPct = remaining / Math.max(1, max);
  const filled = Math.round(remPct * segments);
  const critical = remPct <= 0.1;
  const tone = critical ? 'rose' : kind;
  return (
    <div className={`cr-tok ${tone}`}>
      <div style={{fontSize:8,color:'var(--ink)'}}>{label}</div>
      <div className="cr-tok-track">
        {Array.from({length:segments}).map((_,i)=>(
          <span key={i} className={`cr-tok-seg${i<filled?' on':''}`} />
        ))}
      </div>
      <div className="cr-tok-val">{fmtTok(remaining)}/{fmtTok(max)}</div>
    </div>
  );
}
function CrInput(props){ return <input {...props} className={['cr-input', props.className].filter(Boolean).join(' ')} />; }

// 16x16 sprite renderer
const CR_PAL = {
  '.':'transparent','#':'#2D2A20','+':'#FFD600','y':'#FFEDB0',
  'o':'#D97706','p':'#9B8ACB','P':'#7A6AAB','g':'#6BBE58','G':'#2B5A22',
  'b':'#4AA3E6','B':'#1D4A7A','r':'#DC2626','w':'#FFFEF5','s':'#A8A29E',
  'e':'#059669','c':'#14110A',
};
function CrSprite({ art, size=48, bg='#FFFEF5' }) {
  const cell = size/16;
  return (
    <div style={{
      width:size, height:size, display:'grid',
      gridTemplateColumns:`repeat(16, ${cell}px)`,
      gridTemplateRows:`repeat(16, ${cell}px)`,
      background:bg, border:'1.5px solid #2D2A20',
      imageRendering:'pixelated', flexShrink:0,
    }}>
      {art.flatMap((row,y)=>[...row].map((ch,x)=>(
        <div key={`${y}-${x}`} style={{background:CR_PAL[ch]||'transparent'}}/>
      )))}
    </div>
  );
}

const CR_PORTRAITS = {
  human:      ['................','................','......####......','.....#yyyy#.....','....#yy##yy#....','....#y####y#....','....#yyyyyy#....','.....#yyyy#.....','......####......','.....#++++#.....','....#+#++#+#....','...#++++++++#...','..#++#++++#++#..','..#+#++++++#+#..','...#+#....#+#...','...####..####...'],
  scout:      ['................','....########....','...#ssssssss#...','..#ss######ss#..','.#ss#gg##gg#ss#.','.#ss#gg##gg#ss#.','.#ss########ss#.','.#ssss#ss#ssss#.','.#sssssssssss#.','..#sss####sss#..','...#########....','....#+++++#.....','...#+++++++#....','..#++#+++#++#...','..#+#++++++#....','..##.......##...'],
  gatekeeper: ['................','......####......','.....#pppp#.....','....#pp##pp#....','...#p#pppp#p#...','...#pppppppp#...','...#p#pppp#p#...','....#pp##pp#....','.....#pppp#.....','......####......','.....#ppPp#.....','....#p#PP#p#....','...#pp####pp#...','...#p#####p#....','....#p####p#....','....##....##....'],
  brewer:     ['................','....########....','...#eeeeeeee#...','..#ee######ee#..','.#ee#bb##bb#ee#.','.#ee########ee#.','.#ee#wwwwww#ee#.','.#ee########ee#.','..#ee######ee#..','...#eeeeeeee#...','....#+#++#+#....','...#+++##+++#...','...#+++##+++#...','...#+#++++#+#...','...##......##...','................'],
  patcher:    ['................','......####......','.....#rrrr#.....','....#rr##rr#....','...#r#o##o#r#...','...#rr####rr#...','...#rr#oo#rr#...','....#r####r#....','.....#####......','....#+++++#.....','...#+++++++#....','..#+#+++++#+#...','..#+#+++++#+#...','...#+#+++#+#....','....##...##.....','................'],
};

Object.assign(window, { CrButton, CrChip, CrLED, CrBar, CrTokBar, CrInput, CrSprite, CR_PORTRAITS, fmtTok });
