// ════════════════════════════════════════════════════════════
// Cookrew · Header — Logo + ProfileAvatar
// ════════════════════════════════════════════════════════════

function CrLogo({ size='md', tag='BETA', tagTone='phos' }) {
  const { CrChip } = window;
  const sz = size === 'lg' ? 22 : size === 'sm' ? 11 : 14;
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      <span aria-hidden="true" style={{
        display:'inline-grid', gridTemplateColumns:'repeat(3,1fr)', gridTemplateRows:'repeat(3,1fr)',
        width:sz+8, height:sz+8, gap:1, padding:1,
        background:'var(--ink)', boxShadow:'2px 2px 0 var(--line)',
      }}>
        {[1,1,1, 1,0,1, 1,1,0].map((on,i)=>(
          <span key={i} style={{ background: on ? 'var(--amber)' : 'transparent' }} />
        ))}
      </span>
      <span className="cr-display" style={{ fontSize: sz, color:'var(--ink)' }}>COOKREW</span>
      {tag && <CrChip tone={tagTone} style={{ fontSize: 7 }}>{tag}</CrChip>}
    </div>
  );
}

// ProfileAvatar — circular pixel avatar w/ HP ring + status LED
function CrProfileAvatar({
  name='ALEX', sub='OPERATOR', portrait='human',
  hp=92, max=100, status='on', size=40,
  showMeta=false, onClick,
}) {
  const { CrSprite, CR_PORTRAITS, CrLED } = window;
  return (
    <button onClick={onClick} title={name} style={{
      display:'flex', alignItems:'center', gap: showMeta ? 10 : 0,
      padding: 0, border: 'none', background:'transparent', cursor: onClick ? 'pointer' : 'default',
      textAlign:'left',
    }}>
      <span style={{ position:'relative', display:'inline-block' }}>
        <CrSprite art={CR_PORTRAITS[portrait] || CR_PORTRAITS.human} size={size} bg="var(--cream-hi)" />
        <span style={{ position:'absolute', bottom:-2, right:-2 }}>
          <CrLED state={status === 'busy' ? 'busy' : status === 'off' ? 'off' : 'on'} />
        </span>
      </span>
      {showMeta && (
        <span style={{ display:'flex', flexDirection:'column', minWidth:0, gap:2 }}>
          <span className="cr-display" style={{ fontSize: 11 }}>{name}</span>
          <span className="cr-mono" style={{ fontSize: 9, color:'var(--muted)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{sub} · HP {hp}/{max}</span>
        </span>
      )}
    </button>
  );
}

// Header — full assembled
function CrHeader({
  variant='desktop',
  bundle='BUNDLE 4A2C',
  online=4, total=5,
  onMenu, onAvatar, onParty, onFeed,
  partyOpen=false, feedOpen=false,
}) {
  const { CrButton, CrChip, CrLED } = window;
  const isMobile = variant === 'mobile';
  return (
    <header className="cr" style={{
      display:'flex', alignItems:'center', gap: 10,
      padding: isMobile ? '10px 12px' : '12px 18px',
      paddingTop: isMobile ? 'calc(10px + env(safe-area-inset-top, 0px))' : 12,
      background:'var(--cream-hi)', borderBottom:'2px solid var(--line)',
      position:'relative', zIndex:50,
    }}>
      {isMobile && onMenu && (
        <button onClick={onMenu} title="party" style={{
          border:'2px solid var(--line)', background: partyOpen ? 'var(--amber)' : 'var(--cream-hi)',
          width:36, height:36, display:'flex', alignItems:'center', justifyContent:'center',
          boxShadow:'2px 2px 0 var(--line)', cursor:'pointer', flexShrink:0,
        }}>
          <span style={{ display:'inline-block', width:14 }}>
            <span style={{ display:'block', height:2, background:'var(--line)', marginBottom:3 }} />
            <span style={{ display:'block', height:2, background:'var(--line)', marginBottom:3 }} />
            <span style={{ display:'block', height:2, background:'var(--line)' }} />
          </span>
        </button>
      )}

      <CrLogo size={isMobile ? 'sm' : 'md'} tag="BETA" tagTone="phos" />

      <div style={{ display:'flex', flexDirection:'column', minWidth:0, gap:2, marginLeft: 4 }}>
        <span className="cr-mono" style={{ fontSize: isMobile ? 10 : 11, color:'var(--muted)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{bundle}</span>
      </div>

      <span style={{ flex: 1 }} />

      {!isMobile && (
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <CrChip tone="slate" style={{ fontSize: 8 }}>⌘K SEARCH</CrChip>
          <CrButton size="sm" onClick={onParty}>PARTY {partyOpen ? '▾' : '▸'}</CrButton>
          <CrButton size="sm" onClick={onFeed}>FEED {feedOpen ? '▾' : '▸'}</CrButton>
        </div>
      )}

      <div style={{ display:'flex', alignItems:'center', gap: 6, marginLeft: 6 }}>
        <CrLED state="on" />
        <span className="cr-mono" style={{ fontSize: 10, color:'var(--muted)' }}>{online}/{total}</span>
      </div>

      {isMobile && onFeed && (
        <button onClick={onFeed} title="feed" style={{
          border:'2px solid var(--line)', background: feedOpen ? 'var(--amber)' : 'var(--cream-hi)',
          width:36, height:36, fontFamily:'Silkscreen, monospace', fontSize:10,
          boxShadow:'2px 2px 0 var(--line)', cursor:'pointer', flexShrink:0,
        }}>▦</button>
      )}

      <CrProfileAvatar
        name="ALEX" sub="OPERATOR" portrait="human"
        hp={92} max={100} status="on"
        size={isMobile ? 32 : 40}
        showMeta={!isMobile}
        onClick={onAvatar}
      />
    </header>
  );
}

Object.assign(window, { CrLogo, CrProfileAvatar, CrHeader });
