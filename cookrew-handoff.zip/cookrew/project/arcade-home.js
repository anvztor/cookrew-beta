// Arcade Home — "Arcade Lobby": discovery + report-in to projects.
// No task activity — just browse cookbooks, see who's online, connect.

function ArcadeHome({ loggedIn = true, filter = 'all' }) {
  const { ApTopBar, ApPlayerPill, ApCartridge } = window;
  const projects = [
    { id: 'krewhub', title: 'KREWHUB', subtitle: 'git@krew/hub', swatch: 'a', icon: '⎔', agents: 12, recipes: 8, online: 5, bounty: 420, cat: 'backend', blurb: 'Control plane & system of record' },
    { id: 'krewcli', title: 'KREWCLI', subtitle: 'git@krew/cli', swatch: 'b', icon: '▸_', agents: 7, recipes: 5, online: 3, bounty: 180, cat: 'tooling', blurb: 'Agent-side client · heartbeat + claim' },
    { id: 'cookrew', title: 'COOKREW-WEB', subtitle: 'git@krew/cookrew', swatch: 'c', icon: '◈', agents: 9, recipes: 12, online: 4, bounty: 260, cat: 'frontend', blurb: 'Operator workspace UI' },
    { id: 'krewwatch', title: 'KREWWATCH', subtitle: 'git@krew/watch', swatch: 'd', icon: '◉', agents: 4, recipes: 3, online: 1, bounty: 90, cat: 'ops', blurb: 'Realtime SSE stream broker' },
    { id: 'krewauth', title: 'KREWAUTH', subtitle: 'git@krew/auth', swatch: 'e', icon: '⌘', agents: 3, recipes: 2, online: 0, bounty: 60, cat: 'backend', blurb: 'ERC-8004 agent identity' },
    { id: 'krewcontract', title: 'KREWCONTRACT', subtitle: 'git@krew/contract', swatch: 'f', icon: '§', agents: 2, recipes: 1, online: 0, bounty: 0, cat: 'contract', blurb: 'On-chain registry + digest anchors' },
  ];
  const cats = ['ALL','BACKEND','FRONTEND','TOOLING','OPS','CONTRACT'];
  const activeCat = filter === 'all' ? 'ALL' : filter.toUpperCase();

  return (
    <div className="ap-root" style={{ width: 1440, height: 900, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>
      <ApTopBar
        crumbs={['ARCADE', 'LOBBY']}
        right={<><button className="ap-btn sm ghost">[F1] HELP</button><ApPlayerPill loggedIn={loggedIn} /></>}
      />

      {/* Hero — marquee insert-coin style */}
      <div style={{ borderBottom: '2px solid var(--line)', background: 'var(--cream-hi)', padding: '22px 36px 20px', display: 'flex', gap: 28, alignItems: 'stretch' }}>
        <div style={{ flex: 1 }}>
          <div className="ap-silk" style={{ fontSize: 11, color: 'var(--amber-deep)', marginBottom: 10 }}>▸ PLAYER 1 · READY</div>
          <div className="ap-press" style={{ fontSize: 24, color: 'var(--ink)', marginBottom: 14, lineHeight: 1.3 }}>
            WELCOME TO <span style={{ color: 'var(--amber-deep)' }}>COOKREW</span>
          </div>
          <div style={{ fontSize: 14, color: 'var(--muted)', maxWidth: 520, lineHeight: 1.5 }}>
            Pick a project to <b style={{ color: 'var(--ink)' }}>report-in</b> — load its recipe cartridge, scout its bundles,
            bring your agent online. All task activity happens inside a recipe's <b>workspace</b>.
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <button className="ap-btn primary">▶ START GAME · JOIN A PROJECT</button>
            <button className="ap-btn">＋ UPLOAD CARTRIDGE (NEW RECIPE)</button>
            <button className="ap-btn ghost sm">⎇ REGISTER AGENT (KREWCLI)</button>
          </div>
        </div>
        {/* Phosphor "how it works" readout */}
        <div className="ap-phos" style={{ width: 360, padding: '14px 16px', fontSize: 14 }}>
          <div className="hi" style={{ marginBottom: 6 }}>&gt; cookrew --lobby</div>
          <div className="dim">&gt; loading arcade cabinet...</div>
          <div>&gt; [1] <span className="hi">sandbox</span> · agent scratch</div>
          <div>&gt; [2] <span className="hi">recipe</span> · git repo + facts</div>
          <div>&gt; [3] <span className="hi">cookbook</span> · shelf of recipes</div>
          <div className="dim">&gt; artifacts run inside workspace</div>
          <div className="dim">&gt; digests persist · events expire 7d</div>
          <div style={{ marginTop: 6 }}>&gt; ready player_<span style={{ animation: 'ap-blink .7s step-end infinite' }}>▮</span></div>
        </div>
      </div>

      {/* Stat strip */}
      <div style={{ display: 'flex', borderBottom: '2px solid var(--line)', background: 'var(--cream-md)' }}>
        {[
          ['▸ PROJECTS',  '6',  'cookbooks'],
          ['▸ RECIPES',   '31', 'across all projects'],
          ['▸ AGENTS',    '37', '13 online now'],
          ['▸ BUNDLES',   '4',  'open · awaiting claim'],
          ['▸ DIGESTS',   '128','approved · durable'],
          ['▸ BOUNTY',    '1.0k','coin pool'],
        ].map(([k,v,sub], i) => (
          <div key={i} style={{ flex: 1, padding: '12px 16px', borderRight: i < 5 ? '1px dashed var(--line-soft)' : 'none' }}>
            <div className="ap-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>{k}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
              <div className="ap-press" style={{ fontSize: 16, color: 'var(--ink)' }}>{v}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>{sub}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Body: catalog + side */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <div className="ap-scroll" style={{ flex: 1, overflow: 'auto', padding: 24, background: 'var(--cream)' }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div className="ap-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ CABINET · SELECT CARTRIDGE</div>
              <div className="ap-press" style={{ fontSize: 15, marginTop: 6 }}>EXPLORE PROJECTS</div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              {cats.map(c => (
                <button key={c} className={`ap-btn tiny ${c === activeCat ? 'primary' : ''}`}>{c}</button>
              ))}
            </div>
          </div>

          {/* Shelf */}
          <div className="ap-shelf" style={{ padding: '28px 20px 22px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18 }}>
            {projects.map(p => (
              <div key={p.id} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <ApCartridge title={p.title} subtitle={p.subtitle} swatch={p.swatch} icon={p.icon} w="100%" h={180} />
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                  <span className={`ap-led ${p.online > 0 ? 'on' : 'off'}`} />
                  <span className="ap-mono" style={{ fontSize: 11, color: 'var(--ink)' }}>{p.online}/{p.agents} online</span>
                  <span style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                    <span className="ap-coin" />
                    <span className="ap-mono" style={{ fontSize: 11 }}>{p.bounty}</span>
                  </span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.35 }}>{p.blurb}</div>
                <div style={{ display: 'flex', gap: 4, marginTop: 2 }}>
                  <button className="ap-btn tiny primary" style={{ flex: 1 }}>▶ REPORT-IN</button>
                  <button className="ap-btn tiny">i</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right rail: leaderboard + watchtower */}
        <aside style={{ width: 320, borderLeft: '2px solid var(--line)', background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '12px 14px', borderBottom: '2px solid var(--line)', background: 'var(--amber)' }}>
            <div className="ap-silk" style={{ fontSize: 10, color: 'var(--ink-soft)' }}>▸ HIGH SCORES · THIS WEEK</div>
            <div className="ap-press" style={{ fontSize: 12, marginTop: 5 }}>TOP CONTRIBUTORS</div>
          </div>
          <div style={{ padding: '10px 14px', flex: 1, overflow: 'auto' }} className="ap-scroll">
            {[
              ['1','ALEX','HUMAN',  42,'#FFD600'],
              ['2','GATEKEEPER','AGENT',36,'#9B8ACB'],
              ['3','SCOUT','AGENT', 28,'#6BBE58'],
              ['4','MARINA','HUMAN',19,'#4AA3E6'],
              ['5','SMITH','AGENT', 14,'#DC2626'],
            ].map(([rk,n,k,d,c], i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < 4 ? '1px dashed var(--line-soft)' : 'none' }}>
                <div className="ap-press" style={{ fontSize: 12, color: 'var(--muted)', width: 22 }}>{rk}</div>
                <div style={{ width: 22, height: 22, background: c, border: '1.5px solid var(--line)' }} />
                <div style={{ flex: 1 }}>
                  <div className="ap-silk" style={{ fontSize: 10 }}>{n}</div>
                  <div style={{ fontSize: 9, color: 'var(--muted)', fontFamily: '"Silkscreen", monospace' }}>{k} · {d} digests</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                  <span className="ap-coin" />
                  <span className="ap-mono" style={{ fontSize: 11 }}>{d*8}</span>
                </div>
              </div>
            ))}
          </div>

          <div style={{ borderTop: '2px solid var(--line)', padding: '12px 14px', background: 'var(--cream-md)' }}>
            <div className="ap-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 8 }}>▸ LIVE BROADCAST · WATCHTOWER</div>
            <div className="ap-phos" style={{ padding: '8px 10px', fontSize: 12, lineHeight: 1.4, minHeight: 80 }}>
              <div>&gt; <span className="hi">krewhub</span>/bun_482 digested ✓</div>
              <div>&gt; <span className="hi">scout</span> claimed task_19</div>
              <div>&gt; <span className="hi">reflex</span> heartbeat flaky</div>
              <div className="dim">&gt; 0 blocked · 4 cooking</div>
              <div>&gt; _<span style={{ animation: 'ap-blink .7s step-end infinite' }}>▮</span></div>
            </div>
          </div>
        </aside>
      </div>

      {/* Global scanlines */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,.03) 3px 4px)' }} />
    </div>
  );
}

Object.assign(window, { ArcadeHome });
