// Cookrew Mission Board / Quest Card — responsive
//   • Desktop: pinboard grid w/ dependency strings
//   • Tablet:  2-col card grid, no strings
//   • Mobile:  swipeable horizontal carousel + vertical list view

const CK_TASKS = [
  { id: 't1', no: '01', title: 'Add heartbeat endpoint', status: 'done',    assignee: 'SCOUT',      role: 'GPT-5-MINI', adds: 86, dels: 12 },
  { id: 't2', no: '02', title: 'Heartbeat retry on flaky DNS', status: 'working', assignee: 'SCOUT', role: 'GPT-5-MINI', adds: 24, dels: 4, blocked: true },
  { id: 't3', no: '03', title: 'Sandbox reset script', status: 'working', assignee: 'BREWER',     role: 'SONNET',     adds: 41, dels: 18 },
  { id: 't4', no: '04', title: 'Write replay smoke test', status: 'queued', assignee: 'GATEKEEPER', role: 'OPUS',     adds: 0,  dels: 0 },
  { id: 't5', no: '05', title: 'Patch deserialization bug', status: 'queued', assignee: 'PATCHER', role: 'HAIKU',    adds: 0,  dels: 0 },
];

const CK_STATUS = {
  done:    { bg: '#D8F3E6', ink: '#0B4F2E', label: 'CLEARED' },
  working: { bg: '#FFF3AD', ink: '#5C4A1F', label: 'IN PROGRESS' },
  queued:  { bg: '#F5F0E8', ink: '#78716C', label: 'QUEUED' },
  blocked: { bg: '#FEF2F2', ink: '#DC2626', label: 'BLOCKED' },
};

function CkTaskCard({ t, compact = false, onClick }) {
  const { CkChip, CkLED } = window;
  const st = CK_STATUS[t.blocked ? 'blocked' : t.status];
  return (
    <div onClick={onClick} className="ck-bevel" style={{
      padding: compact ? '10px 12px' : '12px 14px',
      cursor: onClick ? 'pointer' : 'default',
      display: 'flex', flexDirection: 'column', gap: compact ? 6 : 8,
      background: 'var(--cream-hi)',
      width: '100%',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="ck-mono" style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)' }}>#{t.no}</span>
          <CkLED state={t.status === 'done' ? 'on' : t.status === 'working' ? 'busy' : t.blocked ? 'red' : 'off'} />
        </div>
        <CkChip style={{ background: st.bg, color: st.ink, borderColor: 'var(--line)' }}>{st.label}</CkChip>
      </div>
      <div style={{ fontFamily: 'Inter, sans-serif', fontSize: compact ? 14 : 15, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.3, textWrap: 'pretty' }}>
        {t.title}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, paddingTop: 6, borderTop: '1.5px dashed var(--line-soft)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <CkChip tone="slate" style={{ fontSize: 8 }}>{t.assignee}</CkChip>
          <span className="ck-mono" style={{ fontSize: 9, color: 'var(--muted)' }}>{t.role}</span>
        </div>
        {(t.adds > 0 || t.dels > 0) && (
          <div className="ck-mono" style={{ fontSize: 10, display: 'flex', gap: 6 }}>
            <span style={{ color: 'var(--emerald)' }}>+{t.adds}</span>
            <span style={{ color: 'var(--rose)' }}>−{t.dels}</span>
          </div>
        )}
      </div>
    </div>
  );
}

// Desktop board — pinboard layout w/ string overlay
function CkMissionBoard({ tasks = CK_TASKS }) {
  return (
    <div className="ck" style={{ background: 'var(--cream-md)', padding: 18, height: '100%', overflow: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <div className="ck-display" style={{ fontSize: 14 }}>MISSION BOARD</div>
          <div className="ck-kicker" style={{ fontSize: 9, marginTop: 2 }}>BUN_4A2C · 5 QUESTS · 1 BLOCKED</div>
        </div>
        <window.CkBtn variant="primary" size="sm">＋ NEW QUEST</window.CkBtn>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 14 }}>
        {tasks.map(t => <CkTaskCard key={t.id} t={t} />)}
      </div>
    </div>
  );
}

// Mobile — swipeable horizontal carousel
function CkMissionCarousel({ tasks = CK_TASKS }) {
  const [idx, setIdx] = React.useState(0);
  const ref = React.useRef(null);
  const onScroll = (e) => {
    const w = e.currentTarget.clientWidth;
    setIdx(Math.round(e.currentTarget.scrollLeft / w));
  };
  return (
    <div className="ck" style={{ background: 'var(--cream-md)', padding: '14px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px' }}>
        <div>
          <div className="ck-display" style={{ fontSize: 12 }}>MISSIONS</div>
          <div className="ck-kicker" style={{ fontSize: 8, marginTop: 2 }}>{idx + 1}/{tasks.length} · SWIPE ←→</div>
        </div>
        <window.CkBtn size="tiny">＋</window.CkBtn>
      </div>
      <div ref={ref} onScroll={onScroll} className="ck-noscrollbar" style={{
        display: 'flex', overflowX: 'auto', scrollSnapType: 'x mandatory',
        gap: 12, padding: '4px 14px',
      }}>
        {tasks.map(t => (
          <div key={t.id} style={{ flex: '0 0 calc(100% - 28px)', scrollSnapAlign: 'center' }}>
            <CkTaskCard t={t} />
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 6 }}>
        {tasks.map((_, i) => (
          <span key={i} style={{
            width: 6, height: 6, borderRadius: 3,
            background: i === idx ? 'var(--ink)' : 'var(--line-soft)',
          }} />
        ))}
      </div>
    </div>
  );
}

// Mobile list view (alternative to carousel)
function CkMissionList({ tasks = CK_TASKS }) {
  return (
    <div className="ck" style={{ background: 'var(--cream-md)', padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div className="ck-display" style={{ fontSize: 12 }}>MISSIONS</div>
          <div className="ck-kicker" style={{ fontSize: 8, marginTop: 2 }}>BUN_4A2C · 5 QUESTS</div>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <window.CkBtn size="tiny">FILTER</window.CkBtn>
          <window.CkBtn variant="primary" size="tiny">＋ NEW</window.CkBtn>
        </div>
      </div>
      {tasks.map(t => <CkTaskCard key={t.id} t={t} compact />)}
    </div>
  );
}

Object.assign(window, { CkTaskCard, CkMissionBoard, CkMissionCarousel, CkMissionList, CK_TASKS });
