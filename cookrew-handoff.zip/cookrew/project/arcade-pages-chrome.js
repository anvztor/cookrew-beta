// Arcade Pages Chrome — shared pixel tokens for non-workspace screens.
// Uses the same cream/amber/violet palette as pixel-chrome.jsx but tuned
// for "catalog / manual / save-screen" surfaces: less CRT, more paper.

if (typeof document !== 'undefined' && !document.getElementById('ap-styles')) {
  const s = document.createElement('style');
  s.id = 'ap-styles';
  s.textContent = `
    .ap-root {
      --cream: #FAF8F4;
      --cream-hi: #FFFEF5;
      --cream-md: #F5F0E8;
      --cream-dk: #EAE4D6;
      --ink: #2D2A20;
      --ink-soft: #5C4A1F;
      --muted: #78716C;
      --dim: #A8A29E;
      --line: #2D2A20;
      --line-soft: #D6D3CC;
      --amber: #FFD600;
      --amber-soft: #FFF3AD;
      --amber-cream: #FFFBEB;
      --amber-deep: #D97706;
      --phos: #E9B949;
      --phos-dim: #8A6D1C;
      --violet: #9B8ACB;
      --violet-ink: #7A6AAB;
      --violet-soft: #F3E8FF;
      --emerald: #6BBE58;
      --emerald-dim: #2B5A22;
      --emerald-soft: #D8F3E6;
      --rose: #DC2626;
      --rose-soft: #FEF2F2;
      --blue: #4AA3E6;
      --blue-soft: #DBEAFE;
      --paper: #F7F2E6;
      font-family: 'Inter', ui-sans-serif, sans-serif;
      color: var(--ink);
      background: var(--cream);
    }
    .ap-root, .ap-root * { box-sizing: border-box; }
    .ap-silk { font-family: 'Silkscreen', monospace; letter-spacing: 0.6px; text-transform: uppercase; font-weight: 700; }
    .ap-press { font-family: 'Press Start 2P', monospace; letter-spacing: 0; line-height: 1.35; }
    .ap-screen { font-family: 'VT323', monospace; letter-spacing: 0.5px; }
    .ap-mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }

    /* Cartridge/card bevel */
    .ap-card {
      background: var(--cream-hi);
      border: 2px solid var(--line);
      box-shadow: 3px 3px 0 var(--line);
    }
    .ap-card.flat { box-shadow: none; }
    .ap-sunken {
      background: var(--cream-md);
      border: 2px solid var(--line);
      box-shadow: inset 2px 2px 0 rgba(0,0,0,.1);
    }
    .ap-paper {
      background:
        repeating-linear-gradient(to bottom, transparent 0 22px, rgba(45,42,32,.05) 22px 23px),
        var(--paper);
      border: 2px solid var(--line);
      box-shadow: 3px 3px 0 var(--line);
    }
    .ap-btn {
      display: inline-flex; align-items: center; justify-content: center; gap: 6px;
      padding: 9px 14px;
      border: 2px solid var(--line);
      background: var(--cream-hi);
      color: var(--ink);
      font-family: 'Silkscreen', monospace;
      font-size: 11px; font-weight: 700;
      letter-spacing: 1px; text-transform: uppercase; line-height: 1;
      box-shadow: 3px 3px 0 var(--line);
      cursor: pointer;
      transition: transform 80ms, box-shadow 80ms;
    }
    .ap-btn:hover { transform: translate(1px,1px); box-shadow: 2px 2px 0 var(--line); }
    .ap-btn:active { transform: translate(3px,3px); box-shadow: 0 0 0 var(--line); }
    .ap-btn.primary { background: var(--amber); }
    .ap-btn.green { background: var(--emerald); color: #0B3818; }
    .ap-btn.danger { background: var(--rose-soft); color: var(--rose); }
    .ap-btn.sm { padding: 6px 10px; font-size: 10px; }
    .ap-btn.tiny { padding: 4px 7px; font-size: 9px; box-shadow: 2px 2px 0 var(--line); }
    .ap-btn.ghost { box-shadow: none; background: transparent; }

    .ap-chip {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 7px;
      border: 1.5px solid var(--line);
      background: var(--cream-hi);
      font-family: 'Silkscreen', monospace;
      font-size: 9px; font-weight: 700;
      letter-spacing: 0.6px; text-transform: uppercase;
      line-height: 1.4;
    }
    .ap-chip.amber { background: var(--amber); }
    .ap-chip.violet { background: var(--violet-soft); color: #5B21B6; }
    .ap-chip.green { background: #A9E4C2; color: #0B4F2E; }
    .ap-chip.rose { background: var(--rose-soft); color: var(--rose); }
    .ap-chip.blue { background: var(--blue-soft); color: #1E40AF; }
    .ap-chip.slate { background: var(--cream-md); color: var(--muted); }
    .ap-chip.phos { background: #14110A; color: var(--phos); border-color: var(--phos-dim); }

    .ap-kicker {
      font-family: 'Silkscreen', monospace;
      font-size: 9px; font-weight: 700; letter-spacing: 1.3px;
      text-transform: uppercase; color: var(--muted);
    }
    .ap-led {
      display: inline-block; width: 8px; height: 8px; border-radius: 50%;
      background: var(--dim);
      box-shadow: inset -1px -1px 0 rgba(0,0,0,.3), 0 0 0 1.5px var(--line);
    }
    .ap-led.on { background: var(--emerald); box-shadow: inset -1px -1px 0 rgba(0,0,0,.25), 0 0 0 1.5px var(--line), 0 0 4px var(--emerald); }
    .ap-led.busy { background: var(--amber-deep); box-shadow: inset -1px -1px 0 rgba(0,0,0,.25), 0 0 0 1.5px var(--line), 0 0 4px var(--amber-deep); animation: ap-blink .8s step-end infinite; }
    .ap-led.off { background: var(--dim); }
    .ap-led.red { background: var(--rose); box-shadow: inset -1px -1px 0 rgba(0,0,0,.25), 0 0 0 1.5px var(--line), 0 0 4px var(--rose); }
    @keyframes ap-blink { 50% { opacity: .35; } }

    .ap-scan {
      background-image: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,.025) 3px 4px);
    }
    .ap-grid-bg {
      background-color: var(--cream);
      background-image:
        linear-gradient(var(--cream-md) 1px, transparent 1px),
        linear-gradient(90deg, var(--cream-md) 1px, transparent 1px);
      background-size: 24px 24px;
    }
    .ap-dash-row > * + * { position: relative; }
    .ap-dash-b { border-top: 2px dashed var(--line-soft); }

    /* Phosphor mini-screen for status readouts */
    .ap-phos {
      background: radial-gradient(ellipse at center, #2A2412 0%, #14110A 100%);
      color: var(--phos);
      border: 2px solid var(--line);
      font-family: 'VT323', monospace;
      text-shadow: 0 0 3px rgba(233,185,73,.7);
      position: relative;
    }
    .ap-phos::before {
      content:''; position:absolute; inset:0; pointer-events:none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 2px, rgba(0,0,0,.14) 2px 3px);
    }
    .ap-phos .hi { color: #FFD77A; text-shadow: 0 0 6px rgba(255,215,122,.9); }
    .ap-phos .dim { color: var(--phos-dim); }

    /* Coin / rupee icons rendered via CSS */
    .ap-coin {
      display: inline-block; width: 14px; height: 14px;
      background: var(--amber); border: 1.5px solid var(--line);
      border-radius: 50%;
      box-shadow: inset -2px -2px 0 rgba(0,0,0,.15), inset 1px 1px 0 rgba(255,255,255,.4);
      position: relative; flex-shrink: 0;
    }
    .ap-coin::after {
      content: ''; position: absolute; inset: 3px;
      border: 1.2px solid var(--line); border-radius: 50%;
    }

    /* Cartridge shelf slot */
    .ap-shelf {
      background: linear-gradient(to bottom, var(--cream-dk) 0 10px, var(--cream-md) 10px 100%);
      border: 2px solid var(--line);
      box-shadow: inset 0 4px 0 rgba(0,0,0,.08), 3px 3px 0 var(--line);
      position: relative;
    }
    .ap-shelf::before {
      content:''; position:absolute; left: 0; right: 0; top: 10px; height: 2px;
      background: var(--line);
    }

    /* Blocky pixel "thumbnail" patterns (for recipe covers) */
    .ap-pixart {
      image-rendering: pixelated;
      border: 2px solid var(--line);
    }

    /* Table stripes */
    .ap-row:nth-child(odd) { background: var(--cream-hi); }
    .ap-row:nth-child(even) { background: var(--cream-md); }
    .ap-row:hover { background: var(--amber-soft); }

    /* Scroll */
    .ap-scroll::-webkit-scrollbar { width: 10px; height: 10px; }
    .ap-scroll::-webkit-scrollbar-track { background: var(--cream-md); border-left: 1.5px solid var(--line); }
    .ap-scroll::-webkit-scrollbar-thumb { background: var(--ink); border: 2px solid var(--cream-md); }

    /* "Now-loading" dotted border */
    .ap-dotted { border: 2px dashed var(--line); }

    /* Cartridge cover color swatches */
    .ap-swatch-a { background: repeating-linear-gradient(45deg, #FFD600 0 8px, #FFC000 8px 16px); }
    .ap-swatch-b { background: repeating-linear-gradient(45deg, #9B8ACB 0 8px, #7A6AAB 8px 16px); }
    .ap-swatch-c { background: repeating-linear-gradient(45deg, #6BBE58 0 8px, #4A9838 8px 16px); }
    .ap-swatch-d { background: repeating-linear-gradient(45deg, #4AA3E6 0 8px, #2F80C2 8px 16px); }
    .ap-swatch-e { background: repeating-linear-gradient(45deg, #DC2626 0 8px, #9B1717 8px 16px); }
    .ap-swatch-f { background: repeating-linear-gradient(45deg, #2D2A20 0 8px, #555045 8px 16px); }
  `;
  document.head.appendChild(s);
}

// Shared TopBar used across Home / Cookbook / History / Review
function ApTopBar({ crumbs = [], right, glow = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '10px 20px',
      borderBottom: '2px solid var(--line)',
      background: 'var(--cream-hi)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        {/* Logo mark */}
        <div style={{
          width: 32, height: 32, background: 'var(--amber)',
          border: '2px solid var(--line)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '2px 2px 0 var(--line)',
          fontFamily: '"Press Start 2P", monospace', fontSize: 13, color: 'var(--ink)',
        }}>K</div>
        <div className="ap-press" style={{ fontSize: 13, color: 'var(--ink)' }}>
          COOKREW<span style={{ color: 'var(--muted)' }}>·ARCADE</span>
        </div>
        <div style={{ width: 1, height: 20, background: 'var(--line-soft)' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: '"Silkscreen", monospace', fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1 }}>
          {crumbs.map((c, i) => (
            <React.Fragment key={i}>
              {i > 0 && <span style={{ color: 'var(--dim)' }}>▸</span>}
              <span style={{ color: i === crumbs.length - 1 ? 'var(--ink)' : 'var(--muted)' }}>{c}</span>
            </React.Fragment>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {right}
      </div>
    </div>
  );
}

// Player login pill — top-right identity
function ApPlayerPill({ name = 'ALEX', level = 7, coins = 248, loggedIn = true }) {
  if (!loggedIn) {
    return (
      <>
        <button className="ap-btn sm ghost">? HELP</button>
        <button className="ap-btn primary sm">⌘ CONNECT WALLET</button>
      </>
    );
  }
  return (
    <>
      <div className="ap-sunken" style={{ padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="ap-coin" />
        <span className="ap-mono" style={{ fontSize: 12, fontWeight: 600 }}>{coins}</span>
      </div>
      <div className="ap-card flat" style={{ padding: '4px 10px 4px 6px', display: 'flex', alignItems: 'center', gap: 8, borderWidth: 2 }}>
        <div style={{
          width: 22, height: 22, background: 'var(--amber)',
          border: '1.5px solid var(--line)',
          fontFamily: '"Press Start 2P", monospace', fontSize: 9,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>A</div>
        <div style={{ lineHeight: 1 }}>
          <div className="ap-silk" style={{ fontSize: 10, color: 'var(--ink)' }}>{name}</div>
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: 'var(--muted)' }}>LVL {level} · 0x7a..c9</div>
        </div>
        <span className="ap-led on" />
      </div>
    </>
  );
}

// Mini pixel "cartridge cover" — 2-layer patterned label for recipes/cookbooks
function ApCartridge({ title, subtitle, swatch = 'a', icon = '▤', w = 180, h = 220 }) {
  return (
    <div className="ap-pixart" style={{ width: w, height: h, background: 'var(--cream-hi)', position: 'relative', display: 'flex', flexDirection: 'column' }}>
      <div className={`ap-swatch-${swatch}`} style={{ height: h * 0.58, position: 'relative', borderBottom: '2px solid var(--line)' }}>
        <div style={{
          position: 'absolute', inset: 10,
          background: 'var(--cream-hi)',
          border: '2px solid var(--line)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: '"Press Start 2P", monospace', fontSize: 28, color: 'var(--ink)',
        }}>{icon}</div>
        <div style={{
          position: 'absolute', top: 4, right: 4,
          width: 18, height: 18, background: 'var(--line)',
        }} />
        <div style={{
          position: 'absolute', top: 4, left: 4,
          width: 18, height: 18, background: 'var(--cream-hi)', border: '1.5px solid var(--line)',
        }} />
      </div>
      <div style={{ padding: 10, flex: 1 }}>
        <div className="ap-silk" style={{ fontSize: 10, color: 'var(--ink)', lineHeight: 1.25 }}>{title}</div>
        <div className="ap-mono" style={{ fontSize: 10, color: 'var(--muted)', marginTop: 4 }}>{subtitle}</div>
      </div>
      {/* cartridge notches */}
      <div style={{ position: 'absolute', bottom: -2, left: 14, width: 20, height: 6, background: 'var(--line)' }} />
      <div style={{ position: 'absolute', bottom: -2, right: 14, width: 20, height: 6, background: 'var(--line)' }} />
    </div>
  );
}

Object.assign(window, { ApTopBar, ApPlayerPill, ApCartridge });
