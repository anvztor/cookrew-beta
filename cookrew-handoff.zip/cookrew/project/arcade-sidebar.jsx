// Arcade Sidebar — Tamagotchi-style human+agent party roster
// Pixelated portraits, HP (heartbeat) / MP (context window) bars.

const ROSTER = [
  {
    id: 'u_alex',
    kind: 'human',
    name: 'ALEX',
    role: 'OPERATOR',
    sprite: 'human',
    status: 'on',
    hp: 100, hpMax: 100,
    mp: null,
    class: 'HUMAN · LVL 07',
    detail: 'Just prompted a bundle',
  },
  {
    id: 'a_gatekeeper',
    kind: 'agent',
    name: 'GATEKEEPER',
    role: 'CLAUDE-OPUS',
    sprite: 'agent_a',
    status: 'busy',
    hp: 84, hpMax: 100,
    mp: 142, mpMax: 200,
    class: 'AGENT · LVL 12',
    detail: 'Quest #2 · Routing',
    taskId: 't2',
    tools: ['git','bash','fs','web'],
  },
  {
    id: 'a_scout',
    kind: 'agent',
    name: 'SCOUT',
    role: 'GPT-5-MINI',
    sprite: 'agent_b',
    status: 'busy',
    hp: 72, hpMax: 100,
    mp: 56, mpMax: 128,
    class: 'AGENT · LVL 08',
    detail: 'Quest #1 · Heartbeat',
    taskId: 't1',
    tools: ['git','bash','fs'],
  },
  {
    id: 'a_smith',
    kind: 'agent',
    name: 'SMITH',
    role: 'CLAUDE-HAIKU',
    sprite: 'agent_c',
    status: 'on',
    hp: 100, hpMax: 100,
    mp: 178, mpMax: 200,
    class: 'AGENT · LVL 05',
    detail: 'Idle · awaiting claim',
    tools: ['bash','fs'],
  },
  {
    id: 'a_reaver',
    kind: 'agent',
    name: 'REAVER',
    role: 'CURSOR-CMP',
    sprite: 'agent_d',
    status: 'off',
    hp: 0, hpMax: 100,
    mp: 0, mpMax: 100,
    class: 'AGENT · LVL 03',
    detail: 'offline · 4m',
    tools: ['fs'],
  },
  {
    id: 'a_reflex',
    kind: 'agent',
    name: 'REFLEX',
    role: 'CODEX-TINY',
    sprite: 'agent_e',
    status: 'on',
    hp: 22, hpMax: 100,   // low HP — recent flaky heartbeat
    mp: 96, mpMax: 128,
    class: 'AGENT · LVL 04',
    detail: 'Flaky heartbeat',
    tools: ['bash'],
  },
];

function PartyMember({ m, collapsed, onHover, active, hl, onClick }) {
  const { HPBar, LED, Sprite16, PORTRAITS } = window;
  if (collapsed) {
    return (
      <div
        className={`pc-party-mini ${active ? 'active' : ''} ${hl ? 'hl' : ''}`}
        data-agent-id={m.id}
        onMouseEnter={() => onHover?.(m.id)}
        onMouseLeave={() => onHover?.(null)}
        onClick={() => onClick?.(m)}
        style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
          padding: 4, cursor: 'pointer',
          border: active ? '2px solid var(--amber-deep)' : '2px solid transparent',
          background: hl ? 'var(--amber-soft)' : 'transparent',
        }}
      >
        <div style={{ position: 'relative' }}>
          <Sprite16 art={PORTRAITS[m.sprite]} size={32} bg={m.status === 'off' ? '#444' : '#FFFEF5'} />
          <div style={{ position: 'absolute', top: -3, right: -3 }}>
            <LED state={m.status} />
          </div>
        </div>
        <div className="pc-silk" style={{ fontSize: 7, color: 'var(--ink)' }}>{m.name.slice(0,5)}</div>
        {m.kind === 'agent' && (
          <div style={{ width: 30, height: 4, background: 'var(--cream-md)', border: '1px solid var(--line)' }}>
            <div style={{ height: '100%', width: `${(m.hp/m.hpMax)*100}%`, background: m.hp < 25 ? 'var(--rose)' : 'var(--hp)' }} />
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      className={`pc-party-row ${active ? 'active' : ''} ${hl ? 'hl' : ''}`}
      data-agent-id={m.id}
      onMouseEnter={() => onHover?.(m.id)}
      onMouseLeave={() => onHover?.(null)}
      onClick={() => onClick?.(m)}
      style={{
        display: 'grid',
        gridTemplateColumns: '40px 1fr',
        gap: 10,
        padding: 10,
        cursor: 'pointer',
        border: active ? '2px solid var(--amber-deep)' : '2px solid transparent',
        background: hl ? 'var(--amber-soft)' : active ? 'var(--amber-cream)' : 'transparent',
        borderBottom: '1px dashed var(--line-soft)',
        transition: 'background 100ms',
      }}
    >
      <div style={{ position: 'relative' }}>
        <Sprite16 art={PORTRAITS[m.sprite]} size={40} bg={m.status === 'off' ? '#555' : '#FFFEF5'} />
        <div style={{ position: 'absolute', top: -3, right: -3 }}>
          <LED state={m.status} />
        </div>
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, justifyContent: 'space-between' }}>
          <div className="pc-silk" style={{ fontSize: 11, color: 'var(--ink)' }}>{m.name}</div>
          <div className="pc-silk" style={{ fontSize: 7, color: 'var(--muted)' }}>{m.class.split('·')[1]}</div>
        </div>
        <div className="pc-mono" style={{ fontSize: 9, color: 'var(--muted)', marginTop: 1, marginBottom: 5, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {m.role} — {m.detail}
        </div>
        {m.kind === 'agent' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <HPBar label="HP" value={m.hp} max={m.hpMax} kind="hp" />
            <HPBar label="MP" value={m.mp} max={m.mpMax} kind="mp" />
          </div>
        )}
        {m.kind === 'human' && (
          <div className="pc-chip amber" style={{ fontSize: 8 }}>★ OPERATOR</div>
        )}
      </div>
    </div>
  );
}

function ArcadeSidebar({ collapsed, onToggleCollapse, onHoverAgent, highlightedAgent, activeAgent, onSelectAgent }) {
  const { PixelBtn } = window;
  const online = ROSTER.filter(m => m.status !== 'off').length;
  const total = ROSTER.length;

  return (
    <aside className="pc-sidebar" style={{
      width: collapsed ? 72 : 260,
      borderRight: '2px solid var(--line)',
      background: 'var(--cream-hi)',
      display: 'flex', flexDirection: 'column',
      minHeight: 0,
      transition: 'width 180ms ease',
    }}>
      {/* Header — cartridge label */}
      <div style={{
        padding: collapsed ? '10px 6px' : '12px 14px',
        borderBottom: '2px solid var(--line)',
        background: 'var(--amber)',
        display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'space-between', gap: 8,
      }}>
        {!collapsed && (
          <div>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--ink-soft)', letterSpacing: 1.4 }}>PARTY · 4/6 ONLINE</div>
            <div className="pc-display" style={{ fontSize: 11, marginTop: 4, color: 'var(--ink)' }}>THE KREW</div>
          </div>
        )}
        <PixelBtn size="tiny" onClick={onToggleCollapse} style={{ padding: '4px 6px', minWidth: 24 }}>
          {collapsed ? '▶' : '◀'}
        </PixelBtn>
      </div>

      {/* Humans section */}
      {!collapsed && (
        <div style={{ padding: '8px 14px 4px', background: 'var(--cream-md)' }}>
          <div className="pc-kicker">▸ OPERATORS</div>
        </div>
      )}
      <div style={{ display: collapsed ? 'flex' : 'block', flexWrap: 'wrap', padding: collapsed ? 4 : 0, justifyContent: 'center', gap: collapsed ? 2 : 0 }}>
        {ROSTER.filter(m => m.kind === 'human').map(m => (
          <PartyMember
            key={m.id} m={m} collapsed={collapsed}
            onHover={onHoverAgent} hl={highlightedAgent === m.id}
            active={activeAgent === m.id} onClick={onSelectAgent}
          />
        ))}
      </div>

      {!collapsed && (
        <div style={{ padding: '8px 14px 4px', background: 'var(--cream-md)', marginTop: collapsed ? 0 : 0 }}>
          <div className="pc-kicker">▸ AGENTS · {online-1}/{total-1}</div>
        </div>
      )}
      <div className="pc-scroll" style={{ display: collapsed ? 'flex' : 'block', flexWrap: 'wrap', padding: collapsed ? 4 : 0, justifyContent: 'center', gap: collapsed ? 2 : 0, overflowY: 'auto', flex: 1, minHeight: 0 }}>
        {ROSTER.filter(m => m.kind === 'agent').map(m => (
          <PartyMember
            key={m.id} m={m} collapsed={collapsed}
            onHover={onHoverAgent} hl={highlightedAgent === m.id}
            active={activeAgent === m.id} onClick={onSelectAgent}
          />
        ))}
      </div>

      {/* Footer legend */}
      {!collapsed && (
        <div style={{ padding: '10px 14px', borderTop: '2px solid var(--line)', background: 'var(--cream-md)' }}>
          <div className="pc-silk" style={{ fontSize: 8, color: 'var(--muted)', marginBottom: 4 }}>LEGEND</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 3, fontSize: 9, fontFamily: 'JetBrains Mono, monospace', color: 'var(--muted)' }}>
            <div><span style={{display:'inline-block',width:8,height:8,background:'var(--hp)',border:'1px solid var(--line)',marginRight:6}}/>HP · HEARTBEAT</div>
            <div><span style={{display:'inline-block',width:8,height:8,background:'var(--mp)',border:'1px solid var(--line)',marginRight:6}}/>MP · CONTEXT WINDOW</div>
          </div>
        </div>
      )}
    </aside>
  );
}

Object.assign(window, { ArcadeSidebar, ROSTER });
