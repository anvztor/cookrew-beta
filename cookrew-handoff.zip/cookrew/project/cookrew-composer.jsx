// Cookrew Composer Dock — input + slash menu + mode roller
//   • Desktop: persistent bottom dock, full-width
//   • Tablet:  bottom dock, slimmer
//   • Mobile:  bottom-sheet style, single-line input + expand button

const CK_MODES = [
  { v: 'seed',  l: 'SEED',  short: 'SEED',  bg: 'var(--amber)',     fg: '#1A1408',  tip: 'start a new bundle' },
  { v: 'patch', l: 'PATCH', short: 'PATCH', bg: 'var(--violet)',    fg: '#FFF',     tip: 'patch existing bundle' },
  { v: 'ask',   l: 'ASK',   short: 'ASK',   bg: 'var(--cream-md)',  fg: 'var(--ink)', tip: 'read-only consultation' },
];

const CK_SLASH = [
  { cmd: '/bundle',  desc: 'Start a new bundle from a prompt',  icon: '◆' },
  { cmd: '/claim',   desc: 'Force-claim an open quest',         icon: '♦' },
  { cmd: '/digest',  desc: 'Summarize a session',               icon: '▤' },
  { cmd: '/replay',  desc: 'Replay a digest as new bundle',     icon: '▷' },
  { cmd: '/spawn',   desc: 'Spawn an agent on a quest',         icon: '✦' },
];

function CkComposerDock({ variant = 'desktop' }) {
  const [mode, setMode] = React.useState('seed');
  const [text, setText] = React.useState('');
  const [showSlash, setShowSlash] = React.useState(false);
  const m = CK_MODES.find(x => x.v === mode) || CK_MODES[0];
  const isMobile = variant === 'mobile';
  const { CkBtn, CkChip, CkLED } = window;

  return (
    <div className="ck" style={{
      background: 'var(--cream-hi)',
      borderTop: '2px solid var(--line)',
      padding: isMobile ? '8px 10px' : '12px 14px',
      paddingBottom: isMobile ? 'calc(8px + env(safe-area-inset-bottom, 0))' : 12,
      position: 'relative',
    }}>
      {showSlash && (
        <div className="ck-bevel" style={{
          position: 'absolute', bottom: '100%', left: isMobile ? 8 : 14, right: isMobile ? 8 : 'auto',
          marginBottom: 6, width: isMobile ? 'auto' : 320,
          maxHeight: 220, overflowY: 'auto', zIndex: 10, padding: 4,
          background: 'var(--cream-hi)',
        }}>
          {CK_SLASH.map(s => (
            <button key={s.cmd} onClick={() => { setText(s.cmd + ' '); setShowSlash(false); }} style={{
              display: 'flex', width: '100%', alignItems: 'center', gap: 10,
              padding: '8px 10px', border: 'none', background: 'transparent',
              cursor: 'pointer', textAlign: 'left',
            }}>
              <span style={{ fontSize: 14 }}>{s.icon}</span>
              <span className="ck-mono" style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink)' }}>{s.cmd}</span>
              <span style={{ fontSize: 11, color: 'var(--muted)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.desc}</span>
            </button>
          ))}
        </div>
      )}

      {/* Mode roller */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
        {CK_MODES.map(x => (
          <button key={x.v} onClick={() => setMode(x.v)} style={{
            padding: isMobile ? '5px 8px' : '6px 10px',
            border: '2px solid var(--line)',
            background: mode === x.v ? x.bg : 'transparent',
            color: mode === x.v ? x.fg : 'var(--ink)',
            fontFamily: 'Silkscreen, monospace', fontSize: isMobile ? 9 : 10, fontWeight: 700,
            cursor: 'pointer', letterSpacing: 0.6,
            boxShadow: mode === x.v ? '2px 2px 0 var(--line)' : 'none',
          }}>{isMobile ? x.short : x.l}</button>
        ))}
        <span style={{ flex: 1 }} />
        <span className="ck-mono" style={{ fontSize: 10, color: 'var(--muted)', display: isMobile ? 'none' : 'inline' }}>{m.tip}</span>
      </div>

      {/* Input row */}
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
        <button onClick={() => setShowSlash(s => !s)} style={{
          border: '2px solid var(--line)', background: 'var(--cream-hi)',
          width: 40, height: 40, fontFamily: 'JetBrains Mono, monospace', fontSize: 16, fontWeight: 700,
          cursor: 'pointer', boxShadow: '2px 2px 0 var(--line)', flexShrink: 0,
        }}>/</button>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={m.v === 'seed' ? 'Describe a new bundle…' : m.v === 'patch' ? 'Patch instructions…' : 'Ask the kitchen…'}
          rows={1}
          style={{
            flex: 1, minHeight: 40, maxHeight: 120,
            border: '2px solid var(--line)',
            background: 'var(--cream-hi)',
            padding: '10px 12px',
            fontFamily: 'JetBrains Mono, monospace', fontSize: 13,
            color: 'var(--ink)', resize: 'none', outline: 'none',
            boxShadow: 'inset 2px 2px 0 rgba(0,0,0,0.10)',
          }}
        />
        <CkBtn variant="primary" touch={isMobile} style={{ flexShrink: 0 }}>
          {isMobile ? '▶' : 'SEND ▶'}
        </CkBtn>
      </div>

      {/* Status row */}
      {!isMobile && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8, paddingTop: 8, borderTop: '1.5px dashed var(--line-soft)' }}>
          <CkLED state="on" />
          <span className="ck-mono" style={{ fontSize: 10, color: 'var(--muted)' }}>3 AGENTS READY</span>
          <span style={{ flex: 1 }} />
          <CkChip tone="slate">⌘K SLASH</CkChip>
          <CkChip tone="slate">@ MENTION</CkChip>
          <CkChip tone="slate">↵ SEND</CkChip>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { CkComposerDock, CK_MODES, CK_SLASH });
