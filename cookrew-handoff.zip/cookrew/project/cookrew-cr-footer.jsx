// ════════════════════════════════════════════════════════════
// Cookrew · Footer — ModeDial + PromptShipBox
//   ModeDial:      cylindrical mode roller (ORCH / ASSIGN / ASK)
//   PromptShipBox: textarea + slash menu + ship button
// ════════════════════════════════════════════════════════════

const CR_MODES = [
  { v:'orch',   l:'ORCH',   bg:'var(--amber)',     fg:'#1A1408',    tip:'compose a bundle of tasks for agents' },
  { v:'assign', l:'ASSIGN', bg:'#A9E4C2',          fg:'#0B4F2E',    tip:'send one task to one agent'           },
  { v:'ask',    l:'ASK',    bg:'var(--cream-md)',  fg:'var(--ink)', tip:'clarify before agents act'            },
];

const CR_SLASH = [
  { cmd:'/bundle',  desc:'Start a new bundle from a prompt',  icon:'◆' },
  { cmd:'/claim',   desc:'Force-claim an open quest',         icon:'♦' },
  { cmd:'/digest',  desc:'Summarize a session',               icon:'▤' },
  { cmd:'/replay',  desc:'Replay a digest as new bundle',     icon:'▷' },
  { cmd:'/spawn',   desc:'Spawn an agent on a quest',         icon:'✦' },
];

// ── ModeDial — cylindrical 3D roller ────────────────────────
function CrModeDial({ value='seed', onChange, variant='desktop' }) {
  const N = CR_MODES.length;
  const idx = Math.max(0, CR_MODES.findIndex(m => m.v === value));
  const m = CR_MODES[idx] || CR_MODES[0];
  const isMobile = variant === 'mobile';

  const FACES = Math.max(N, 8);
  const FACE_H = isMobile ? 22 : 26;
  const FACE_ANGLE = 360 / FACES;
  const RADIUS = (FACE_H / 2) / Math.tan(Math.PI / FACES);
  const VIEWPORT_H = Math.round(RADIUS * 2 + 4);
  const ROLLER_W = isMobile ? 116 : 144;

  const [animating, setAnimating] = React.useState(false);
  const [drag, setDrag] = React.useState(null);
  const wheelLock = React.useRef(0);
  const wrap = (i) => ((i % N) + N) % N;
  const setIdx = (next) => { const v = CR_MODES[wrap(next)].v; if (v !== value) onChange?.(v); };
  const step = (dir) => { setAnimating(true); setIdx(idx + dir); window.setTimeout(()=>setAnimating(false), 240); };

  const onPointerDown = (e) => { e.preventDefault(); e.stopPropagation(); e.currentTarget.setPointerCapture?.(e.pointerId); setDrag({ startY: e.clientY, dy: 0, moved: false }); };
  const onPointerMove = (e) => { if (!drag) return; const dy = e.clientY - drag.startY; setDrag(d => d ? { ...d, dy, moved: d.moved || Math.abs(dy) > 3 } : d); };
  const onPointerUp = (e) => {
    if (!drag) return;
    const { dy, moved } = drag; setDrag(null);
    if (!moved) { step(1); return; }
    const steps = Math.round(-dy / FACE_H);
    if (steps !== 0) { setAnimating(true); setIdx(idx + steps); window.setTimeout(()=>setAnimating(false), 240); }
  };
  const onWheel = (e) => {
    e.preventDefault(); e.stopPropagation();
    const now = Date.now();
    if (now - wheelLock.current < 180) return;
    if (Math.abs(e.deltaY) < 4) return;
    wheelLock.current = now; step(e.deltaY > 0 ? 1 : -1);
  };

  const dragSteps = drag ? Math.max(-1.6, Math.min(1.6, -drag.dy / FACE_H)) : 0;
  const virtualIdx = idx + dragSteps;
  const drumAngle = -virtualIdx * FACE_ANGLE;
  const drumTransition = drag ? 'none' : (animating ? 'transform 240ms cubic-bezier(.2,.85,.3,1)' : 'transform 0ms');

  const Face = ({ face, slot, isCenter }) => {
    const angle = slot * FACE_ANGLE;
    return (
      <div style={{
        position:'absolute', left:0, right:0, top:'50%', height: FACE_H, marginTop: -FACE_H/2,
        transform: `rotateX(${angle}deg) translateZ(${RADIUS}px)`, backfaceVisibility:'hidden',
        display:'flex', alignItems:'center', justifyContent:'center', gap: 6,
        background: isCenter ? 'var(--amber-soft)' : 'var(--cream-hi)',
        borderTop:'1px dashed rgba(45,42,32,0.18)', borderBottom:'1px dashed rgba(45,42,32,0.18)',
      }}>
        <span style={{
          width: 8, height: 8, background: face.bg,
          boxShadow:'inset -1px -1px 0 rgba(0,0,0,0.25), inset 1px 1px 0 rgba(255,255,255,0.6)',
        }} />
        <span style={{ fontFamily:"'Silkscreen',monospace", fontSize: 10, fontWeight:700, letterSpacing:0.5, color:'var(--ink)' }}>{face.l}</span>
      </div>
    );
  };

  return (
    <div title={`${m.tip} · drag, click, or scroll`}
      onContextMenu={(e)=>{ e.preventDefault(); e.stopPropagation(); step(-1); }}
      onPointerDown={onPointerDown} onPointerMove={onPointerMove}
      onPointerUp={onPointerUp} onPointerCancel={onPointerUp} onWheel={onWheel}
      style={{
        position:'relative', width: ROLLER_W, height: VIEWPORT_H, flexShrink:0,
        background:'var(--cream-md)',
        boxShadow:'inset 2px 2px 0 rgba(0,0,0,0.18), inset -2px -2px 0 var(--cream-hi)',
        userSelect:'none', cursor: drag ? 'grabbing' : 'grab', touchAction:'none', overflow:'hidden',
      }}>
      <div style={{ position:'absolute', inset: 0, perspective: 600, perspectiveOrigin:'50% 50%' }}>
        <div style={{
          position:'absolute', inset: 0, transformStyle:'preserve-3d',
          transform:`translateZ(${-RADIUS}px) rotateX(${drumAngle}deg)`,
          transition: drumTransition, willChange:'transform',
        }}>
          {CR_MODES.map((face, i) => {
            let slot = i - idx;
            if (slot > N/2) slot -= N;
            if (slot < -N/2) slot += N;
            return <Face key={face.v} face={face} slot={slot} isCenter={slot === 0} />;
          })}
        </div>
      </div>
      <div style={{ position:'absolute', left:0, right:0, top:0, height:'40%', background:'linear-gradient(to bottom, rgba(45,42,32,0.22), rgba(45,42,32,0))', pointerEvents:'none', zIndex: 4 }} />
      <div style={{ position:'absolute', left:0, right:0, bottom:0, height:'40%', background:'linear-gradient(to top, rgba(45,42,32,0.22), rgba(45,42,32,0))', pointerEvents:'none', zIndex: 4 }} />
      <div style={{
        position:'absolute', left:0, right:0, top:'50%', height: FACE_H, marginTop: -FACE_H/2,
        borderTop:'1.5px solid var(--amber-deep)', borderBottom:'1.5px solid var(--amber-deep)',
        boxShadow:'inset 0 0 0 1px rgba(217,119,6,0.18)', pointerEvents:'none', zIndex: 5,
      }} />
      <div style={{ position:'absolute', right:4, top:2, fontFamily:"'Silkscreen',monospace", fontSize: 6, color:'var(--muted)', pointerEvents:'none', zIndex: 6 }}>▲</div>
      <div style={{ position:'absolute', right:4, bottom:2, fontFamily:"'Silkscreen',monospace", fontSize: 6, color:'var(--muted)', pointerEvents:'none', zIndex: 6 }}>▼</div>
      <div style={{ position:'absolute', left:4, top:'50%', marginTop: -FACE_H/2 - 9, fontFamily:"'Silkscreen',monospace", fontSize: 7, color:'var(--amber-deep)', pointerEvents:'none', zIndex: 6 }}>{idx+1}/{N}</div>
    </div>
  );
}

// ── CrComposer — unified Dial · Input · Ship rail ──────────
// One bordered shell. Internal hairlines only. No gaps. No voids.
function CrComposer({ mode='seed', onModeChange, variant='desktop', onSend }) {
  const [text, setText] = React.useState('');
  const [showSlash, setShowSlash] = React.useState(false);
  const taRef = React.useRef(null);
  const isMobile = variant === 'mobile';
  const placeholder =
    mode === 'ask'    ? 'clarify before agents act · ⏎ to ask' :
    mode === 'assign' ? 'send one task to one agent · "@" · ⏎ to ship' :
                        'compose a bundle of tasks · "/" · "@" · ⏎ to ship';

  const onChange = (e) => {
    const v = e.target.value;
    setText(v);
    const last = v.split(/\s/).pop() || '';
    setShowSlash(last.startsWith('/'));
  };
  const insertCmd = (cmd) => {
    const parts = text.split(/\s/);
    parts[parts.length - 1] = cmd + ' ';
    setText(parts.join(' '));
    setShowSlash(false);
    taRef.current?.focus();
  };
  const send = () => { if (!text.trim()) return; onSend?.({ mode, text }); setText(''); };
  const ready = !!text.trim();
  const SHIP_W = isMobile ? 56 : 92;

  return (
    <div style={{ position:'relative' }}>
      {showSlash && (
        <div className="cr-bevel" style={{
          position:'absolute', bottom:'100%', left: 0, right: 0, marginBottom: 6,
          maxHeight: 220, overflowY:'auto', zIndex: 10, padding: 4, background:'var(--cream-hi)',
        }}>
          <div className="cr-kicker" style={{ fontSize: 8, padding:'6px 10px', borderBottom:'1.5px solid var(--line-soft)' }}>SLASH COMMANDS</div>
          {CR_SLASH.filter(c => c.cmd.startsWith(text.split(/\s/).pop() || '/')).map(s => (
            <button key={s.cmd} onClick={() => insertCmd(s.cmd)} style={{
              display:'flex', width:'100%', alignItems:'center', gap: 10, padding:'8px 10px',
              border:'none', background:'transparent', cursor:'pointer', textAlign:'left',
            }}>
              <span style={{ fontSize: 14 }}>{s.icon}</span>
              <span className="cr-mono" style={{ fontSize: 12, fontWeight:600, color:'var(--ink)' }}>{s.cmd}</span>
              <span style={{ fontSize: 11, color:'var(--muted)', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{s.desc}</span>
            </button>
          ))}
        </div>
      )}

      {/* Unified rail — one outer border, three flush cells, hairline dividers */}
      <div style={{
        display:'flex', alignItems:'stretch',
        border:'2px solid var(--line)',
        background:'var(--cream-hi)',
        boxShadow:'2px 2px 0 var(--line)',
      }}>
        {/* Cell 1 — Mode dial (no own border, sits flush) */}
        <div style={{
          display:'flex', alignItems:'center', justifyContent:'center',
          padding:'4px 4px',
          borderRight:'1.5px solid var(--line)',
          background:'var(--cream-md)',
          flexShrink: 0,
        }}>
          <CrModeDial value={mode} onChange={onModeChange} variant={variant} />
        </div>

        {/* Cell 2 — Inline slash + textarea (flush, no inner borders) */}
        <div style={{ flex:1, minWidth:0, display:'flex', alignItems:'stretch' }}>
          <button onClick={() => setShowSlash(s => !s)} title="slash commands"
            style={{
              border:'none', background:'transparent', cursor:'pointer',
              padding:'0 10px', fontFamily:"'Silkscreen',monospace",
              fontSize: 14, fontWeight:700,
              color: showSlash ? 'var(--amber-deep)' : 'var(--muted)',
              flexShrink:0,
            }}>/</button>
          <textarea ref={taRef} value={text} onChange={onChange} placeholder={placeholder}
            rows={1}
            onKeyDown={(e)=>{ if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            style={{
              flex: 1, minWidth: 0, alignSelf:'stretch',
              border:'none', background:'transparent',
              padding: isMobile ? '12px 10px 12px 0' : '14px 12px 14px 0',
              fontFamily:'JetBrains Mono, monospace',
              fontSize: 13, color:'var(--ink)', resize:'none', outline:'none',
            }}/>
        </div>

        {/* Cell 3 — Ship (full-height, flush right) */}
        <button onClick={send} disabled={!ready}
          title="ship ⏎"
          style={{
            width: SHIP_W, flexShrink:0,
            border:'none', borderLeft:'1.5px solid var(--line)',
            background: ready ? 'var(--amber)' : 'var(--cream-md)',
            color: ready ? '#1A1408' : 'var(--muted)',
            fontFamily:"'Silkscreen',monospace",
            fontSize: isMobile ? 14 : 11, fontWeight:700, letterSpacing:0.5,
            cursor: ready ? 'pointer' : 'default',
            transition:'background 120ms ease',
            display:'flex', alignItems:'center', justifyContent:'center', gap: 6,
          }}>
          {isMobile ? '▶' : <><span>SHIP</span><span>▶</span></>}
        </button>
      </div>
    </div>
  );
}

// Back-compat shim — anything still importing CrPromptShipBox gets the new rail.
function CrPromptShipBox(props) {
  const [mode, setMode] = React.useState(props.mode || 'seed');
  return <CrComposer {...props} mode={mode} onModeChange={setMode} />;
}

// ── Footer — unified composer + (desktop) status row ─────────
function CrFooter({ variant='desktop', onSend }) {
  const { CrChip, CrLED } = window;
  const [mode, setMode] = React.useState('orch');
  const isMobile = variant === 'mobile';
  return (
    <footer className="cr" style={{
      borderTop:'2px solid var(--line)', background:'var(--cream-hi)',
      padding: isMobile ? '10px 12px 0' : '12px 18px',
      paddingBottom: isMobile ? 'env(safe-area-inset-bottom, 0)' : 14,
      flexShrink: 0,
    }}>
      <CrComposer mode={mode} onModeChange={setMode} variant={variant} onSend={onSend} />
      {!isMobile && (
        <div style={{ display:'flex', alignItems:'center', gap: 10, marginTop: 8, paddingTop: 8, borderTop:'1.5px dashed var(--line-soft)' }}>
          <CrLED state="on" />
          <span className="cr-mono" style={{ fontSize: 10, color:'var(--muted)' }}>3 AGENTS READY</span>
          <span style={{ flex: 1 }} />
          <CrChip tone="slate">⌘K SLASH</CrChip>
          <CrChip tone="slate">@ MENTION</CrChip>
          <CrChip tone="slate">↵ SHIP</CrChip>
        </div>
      )}
    </footer>
  );
}

Object.assign(window, { CrModeDial, CrPromptShipBox, CrComposer, CrFooter, CR_MODES, CR_SLASH });
