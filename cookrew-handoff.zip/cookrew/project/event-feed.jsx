// Event Feed — Pip-Boy pop-out scrolling window w/ phosphor CRT
// Fixed to right side, scrolls events, expandable to full drawer.

const EVENTS = [
  { t: '14:22:09', src: 'SYS',       kind: 'bundle', msg: '>> BUNDLE bun_4a2c CREATED · 5 quests seeded' },
  { t: '14:22:14', src: 'SCOUT',     kind: 'claim',  msg: '@scout CLAIMED quest #01 "heartbeat endpoint"' },
  { t: '14:22:47', src: 'SCOUT',     kind: 'tool',   msg: 'bash$ git checkout -b agent-scout/heartbeat' },
  { t: '14:23:02', src: 'SCOUT',     kind: 'think',  msg: '... reading packages/shared/src/presence.ts' },
  { t: '14:24:19', src: 'SCOUT',     kind: 'milestone', msg: '✓ MILESTONE — 30s TTL heartbeat wired' },
  { t: '14:24:20', src: 'SCOUT',     kind: 'fact',   msg: '§ FACT: agent online if last_heartbeat < 30s' },
  { t: '14:24:25', src: 'SCOUT',     kind: 'code',   msg: 'ƒ PUSH sha:abc123 · server/agents.ts, cli/heartbeat.ts' },
  { t: '14:24:41', src: 'SCOUT',     kind: 'done',   msg: '✓ QUEST #01 CLEARED · +XP 120' },
  { t: '14:24:42', src: 'GATEKEEPER', kind: 'claim', msg: '@gatekeeper CLAIMED quest #02 "CLI task.claim"' },
  { t: '14:25:07', src: 'SMITH',     kind: 'claim',  msg: '@smith CLAIMED quest #03 "persist last_heartbeat"' },
  { t: '14:25:44', src: 'GATEKEEPER', kind: 'tool',  msg: 'rg "POST /tasks/:id/claim" packages/bff' },
  { t: '14:26:11', src: 'REFLEX',    kind: 'warn',   msg: '⚠ QUEST #04 BLOCKED — cron runner not configured' },
  { t: '14:26:18', src: 'SYS',       kind: 'bundle', msg: '!! BUNDLE STATUS → BLOCKED (1 quest halted)' },
];

const KIND_COLOR = {
  bundle:    'var(--phos-hi)',
  claim:     'var(--phos)',
  tool:      '#7AC4E5',
  think:     '#BFA3E0',
  milestone: '#6BCF88',
  fact:      '#6BCF88',
  code:      '#E9B949',
  done:      '#6BCF88',
  warn:      '#FF9A6B',
  prompt:    '#E9B949',
};

function EventFeed({ expanded, onToggle, highlightedAgent, onHoverAgent }) {
  const { PixelBtn } = window;
  const [filter, setFilter] = React.useState('ALL');
  const filters = ['ALL','TOOL','THINK','MILESTONE','WARN'];
  const filtered = filter === 'ALL'
    ? EVENTS
    : EVENTS.filter(e => e.kind.toUpperCase().startsWith(filter));

  return (
    <div className={`pc-pipboy ${expanded ? 'expanded' : ''}`} style={{
      position: 'absolute',
      right: expanded ? 0 : 16,
      top: expanded ? 0 : 16,
      bottom: expanded ? 0 : 140, // leave room for composer dock (pinned at bottom)
      width: expanded ? 'min(680px, 55%)' : 320,
      zIndex: 20,
      display: 'flex', flexDirection: 'column',
      transition: 'width 200ms ease, right 200ms ease, top 200ms ease, bottom 200ms ease',
    }}>
      <div className="pc-phos-screen pc-crt" style={{
        flex: 1,
        display: 'flex', flexDirection: 'column',
        minHeight: 0,
        padding: 0,
        boxShadow: expanded ? 'none' : '6px 6px 0 var(--line)',
        borderRadius: 0,
      }}>
        {/* Title bar */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '8px 12px',
          borderBottom: '1px solid rgba(233,185,73,0.35)',
          background: 'rgba(233,185,73,0.08)',
          position: 'relative', zIndex: 4,
        }}>
          <div className="pc-silk pc-phos-hi" style={{ fontSize: 10, letterSpacing: 1.5 }}>
            ▮ KREWHUB FEED · REC_BBQ-2026
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            <button
              onClick={() => onToggle?.(false)}
              style={{ background: 'transparent', border: '1px solid var(--phos-dim)', color: 'var(--phos)', padding: '2px 6px', fontFamily: 'Silkscreen, monospace', fontSize: 9, cursor: 'pointer' }}
            >{expanded ? 'MIN' : '·'}</button>
            <button
              onClick={() => onToggle?.(true)}
              style={{ background: 'transparent', border: '1px solid var(--phos-dim)', color: 'var(--phos)', padding: '2px 6px', fontFamily: 'Silkscreen, monospace', fontSize: 9, cursor: 'pointer' }}
            >{expanded ? '□' : '⊞'}</button>
          </div>
        </div>

        {/* Filter tabs */}
        <div style={{
          display: 'flex', gap: 1, padding: '6px 8px',
          borderBottom: '1px solid rgba(233,185,73,0.35)',
          position: 'relative', zIndex: 4,
        }}>
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              style={{
                background: filter === f ? 'rgba(233,185,73,0.22)' : 'transparent',
                border: '1px solid ' + (filter === f ? 'var(--phos)' : 'var(--phos-dim)'),
                color: filter === f ? 'var(--phos-glow)' : 'var(--phos-dim)',
                padding: '2px 6px',
                fontFamily: 'Silkscreen, monospace', fontSize: 8,
                cursor: 'pointer', letterSpacing: 0.5,
              }}
            >{f}</button>
          ))}
          <div style={{ flex: 1 }} />
          <div className="pc-mono" style={{ color: 'var(--phos-dim)', fontSize: 10, alignSelf: 'center' }}>{filtered.length} EVTS</div>
        </div>

        {/* Scrolling feed */}
        <div className="pc-scroll" style={{
          flex: 1, minHeight: 0, overflowY: 'auto',
          padding: '8px 12px',
          fontFamily: 'VT323, monospace',
          fontSize: 14,
          lineHeight: 1.35,
          position: 'relative', zIndex: 4,
        }}>
          {filtered.map((e, i) => (
            <div key={i} style={{
              marginBottom: 4,
              opacity: highlightedAgent && !e.src.toLowerCase().includes(String(highlightedAgent).replace(/^a_/,'').toLowerCase()) ? 0.4 : 1,
              transition: 'opacity 120ms',
            }}>
              <span className="pc-phos-dim">[{e.t}]</span>{' '}
              <span style={{ color: KIND_COLOR[e.kind] || 'var(--phos)' }}>{e.msg}</span>
            </div>
          ))}
          <div className="pc-cursor pc-phos-hi" style={{ fontSize: 14 }}>$&nbsp;</div>
        </div>

        {/* Footer heartbeat */}
        <div style={{
          padding: '4px 10px',
          borderTop: '1px solid rgba(233,185,73,0.35)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          fontFamily: 'JetBrains Mono, monospace', fontSize: 9,
          color: 'var(--phos-dim)',
          position: 'relative', zIndex: 4,
        }}>
          <span>SSE · connected</span>
          <span style={{ animation: 'pc-blink 1.2s step-end infinite' }}>♥ 30s TTL</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EventFeed, EVENTS });
