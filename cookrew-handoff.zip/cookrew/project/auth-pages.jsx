// Cookrew auth pages — 3 login variants (wallet / user+password / plugin)
// + profile/account page. Pixel-arcade aesthetic matching Cookrew Pages.html.

if (typeof document !== 'undefined' && !document.getElementById('auth-extras-styles')) {
  const s = document.createElement('style');
  s.id = 'auth-extras-styles';
  s.textContent = `
    .auth-root { --cream:#FAF8F4; --cream-hi:#FFFEF5; --cream-md:#F5F0E8; --cream-dk:#EAE4D6;
      --ink:#2D2A20; --ink-soft:#5C4A1F; --muted:#78716C; --dim:#A8A29E;
      --line:#2D2A20; --line-soft:#D6D3CC;
      --amber:#FFD600; --amber-soft:#FFF3AD; --amber-cream:#FFFBEB; --amber-deep:#D97706;
      --phos:#E9B949; --phos-dim:#8A6D1C;
      --violet:#9B8ACB; --violet-ink:#7A6AAB; --violet-soft:#F3E8FF;
      --emerald:#6BBE58; --emerald-dim:#2B5A22; --emerald-soft:#D8F3E6;
      --rose:#DC2626; --rose-soft:#FEF2F2;
      --blue:#4AA3E6; --blue-soft:#DBEAFE;
      --paper:#F7F2E6;
      font-family:'Inter', ui-sans-serif, sans-serif; color:var(--ink); background:var(--cream); }
    .auth-root, .auth-root * { box-sizing:border-box; }
    .auth-silk { font-family:'Silkscreen', monospace; letter-spacing:.6px; text-transform:uppercase; font-weight:700; }
    .auth-press { font-family:'Press Start 2P', monospace; letter-spacing:0; line-height:1.35; }
    .auth-mono  { font-family:'JetBrains Mono', ui-monospace, monospace; }
    .auth-screen{ font-family:'VT323', monospace; letter-spacing:.5px; }

    .auth-btn {
      display:inline-flex; align-items:center; justify-content:center; gap:8px;
      padding:11px 16px; border:2px solid var(--line); background:var(--cream-hi); color:var(--ink);
      font-family:'Silkscreen', monospace; font-size:12px; font-weight:700; letter-spacing:1px;
      text-transform:uppercase; line-height:1; cursor:pointer;
      box-shadow:3px 3px 0 var(--line); transition:transform 80ms, box-shadow 80ms;
      width:100%;
    }
    .auth-btn:hover { transform:translate(1px,1px); box-shadow:2px 2px 0 var(--line); }
    .auth-btn:active{ transform:translate(3px,3px); box-shadow:0 0 0 var(--line); }
    .auth-btn.primary { background:var(--amber); }
    .auth-btn.violet  { background:var(--violet-soft); }
    .auth-btn.emerald { background:var(--emerald-soft); }
    .auth-btn.danger  { background:var(--rose-soft); color:var(--rose); }
    .auth-btn.ghost   { box-shadow:none; background:transparent; }
    .auth-btn.sm { padding:6px 10px; font-size:10px; }
    .auth-btn.tiny { padding:4px 7px; font-size:9px; box-shadow:2px 2px 0 var(--line); }
    .auth-btn.inline { width:auto; }

    .auth-chip {
      display:inline-flex; align-items:center; gap:5px;
      padding:3px 7px; border:1.5px solid var(--line); background:var(--cream-hi);
      font-family:'Silkscreen', monospace; font-size:9px; font-weight:700;
      letter-spacing:.6px; text-transform:uppercase; line-height:1.4;
    }
    .auth-chip.amber { background:var(--amber); }
    .auth-chip.violet { background:var(--violet-soft); color:#5B21B6; }
    .auth-chip.emerald { background:#A9E4C2; color:#0B4F2E; }
    .auth-chip.rose   { background:var(--rose-soft); color:var(--rose); }
    .auth-chip.blue   { background:var(--blue-soft); color:#1E40AF; }
    .auth-chip.slate  { background:var(--cream-md); color:var(--muted); }
    .auth-chip.phos   { background:#14110A; color:var(--phos); border-color:var(--phos-dim); text-shadow:0 0 3px rgba(233,185,73,.7); }

    .auth-coin {
      display:inline-block; width:14px; height:14px; background:var(--amber);
      border:1.5px solid var(--line); border-radius:50%;
      box-shadow: inset -2px -2px 0 rgba(0,0,0,.15), inset 1px 1px 0 rgba(255,255,255,.4);
      position:relative; flex-shrink:0;
    }
    .auth-coin::after { content:''; position:absolute; inset:3px; border:1.2px solid var(--line); border-radius:50%; }

    .auth-led { display:inline-block; width:8px; height:8px; border-radius:50%;
      background:var(--dim); box-shadow: inset -1px -1px 0 rgba(0,0,0,.3), 0 0 0 1.5px var(--line); }
    .auth-led.on { background:var(--emerald); box-shadow: inset -1px -1px 0 rgba(0,0,0,.25), 0 0 0 1.5px var(--line), 0 0 4px var(--emerald); }
    .auth-led.busy { background:var(--amber-deep); animation:auth-blink .8s step-end infinite;
      box-shadow: inset -1px -1px 0 rgba(0,0,0,.25), 0 0 0 1.5px var(--line), 0 0 4px var(--amber-deep); }
    .auth-led.off { background:var(--dim); }
    .auth-led.red { background:var(--rose); box-shadow: inset -1px -1px 0 rgba(0,0,0,.25), 0 0 0 1.5px var(--line), 0 0 4px var(--rose); }
    @keyframes auth-blink { 50% { opacity:.35; } }

    .auth-phos {
      background: radial-gradient(ellipse at center, #2A2412 0%, #14110A 100%);
      color:var(--phos); border:2px solid var(--line);
      font-family:'VT323', monospace; text-shadow: 0 0 3px rgba(233,185,73,.7);
      position:relative;
    }
    .auth-phos::before { content:''; position:absolute; inset:0; pointer-events:none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 2px, rgba(0,0,0,.14) 2px 3px); }
    .auth-phos .hi  { color:#FFD77A; text-shadow:0 0 6px rgba(255,215,122,.9); }
    .auth-phos .dim { color:var(--phos-dim); }

    .auth-card { background:var(--cream-hi); border:2px solid var(--line); box-shadow:6px 6px 0 var(--line); }
    .auth-sunken { background:var(--cream-md); border:2px solid var(--line);
      box-shadow: inset 2px 2px 0 rgba(0,0,0,.1); }
    .auth-paper {
      background:
        repeating-linear-gradient(to bottom, transparent 0 22px, rgba(45,42,32,.05) 22px 23px),
        var(--paper);
      border:2px solid var(--line);
    }

    .auth-input {
      width:100%; padding:10px 12px;
      border:2px solid var(--line); background:var(--cream-hi);
      font-family:'JetBrains Mono', monospace; font-size:13px; color:var(--ink);
      box-shadow: inset 2px 2px 0 rgba(0,0,0,.06);
      outline:none;
    }
    .auth-input:focus { background:var(--amber-cream); box-shadow: inset 2px 2px 0 rgba(0,0,0,.08), 0 0 0 2px var(--amber); }
    .auth-label { font-family:'Silkscreen', monospace; font-size:10px; font-weight:700;
      letter-spacing:1px; text-transform:uppercase; color:var(--muted); display:block; margin-bottom:6px; }

    .auth-scan {
      background-image: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,.03) 3px 4px);
    }

    .auth-marquee {
      background:
        repeating-linear-gradient(90deg, var(--amber) 0 12px, #FFC000 12px 24px);
      border-top:2px solid var(--line); border-bottom:2px solid var(--line);
      padding:6px 14px; font-family:'Silkscreen', monospace; font-size:10px;
      letter-spacing:1.2px; text-transform:uppercase; color:var(--ink);
      display:flex; align-items:center; gap:16px;
    }
    .auth-marquee .dot { width:8px; height:8px; background:var(--line); }

    .auth-dash { border-top:2px dashed var(--line-soft); }

    .auth-stripes-a { background:repeating-linear-gradient(45deg, #FFD600 0 8px, #FFC000 8px 16px); }
    .auth-stripes-b { background:repeating-linear-gradient(45deg, #9B8ACB 0 8px, #7A6AAB 8px 16px); }
    .auth-stripes-c { background:repeating-linear-gradient(45deg, #6BBE58 0 8px, #4A9838 8px 16px); }
    .auth-stripes-d { background:repeating-linear-gradient(45deg, #4AA3E6 0 8px, #2F80C2 8px 16px); }
    .auth-stripes-ink { background:repeating-linear-gradient(45deg, #2D2A20 0 6px, #555045 6px 12px); }

    /* 8-bit keypad keys for password screen */
    .auth-key {
      width:56px; height:56px; border:2px solid var(--line);
      background:var(--cream-hi); box-shadow:3px 3px 0 var(--line);
      font-family:'Press Start 2P', monospace; font-size:14px;
      display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--ink);
      transition:transform 80ms, box-shadow 80ms;
    }
    .auth-key:hover { transform:translate(1px,1px); box-shadow:2px 2px 0 var(--line); }
    .auth-key:active { transform:translate(3px,3px); box-shadow:0 0 0 var(--line); }
    .auth-key.wide { width:120px; }
    .auth-key.dark { background:var(--ink); color:var(--amber); }
  `;
  document.head.appendChild(s);
}

// =======================================================================
// Shared: arcade cabinet frame used by all 4 artboards
// =======================================================================
function AuthCabinet({ title, subtitle, rightSlot, children, footer, width = 1040, height = 820 }) {
  return (
    <div className="auth-root" style={{
      width, height, display:'flex', flexDirection:'column', overflow:'hidden',
      position:'relative', background:'var(--cream)',
    }}>
      {/* Top bar / marquee */}
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        padding:'10px 18px', background:'var(--cream-hi)', borderBottom:'2px solid var(--line)',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{
            width:30, height:30, background:'var(--amber)', border:'2px solid var(--line)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontFamily:'"Press Start 2P", monospace', fontSize:12, boxShadow:'2px 2px 0 var(--line)',
          }}>K</div>
          <div className="auth-press" style={{ fontSize:12 }}>
            COOKREW<span style={{ color:'var(--muted)' }}>·ARCADE</span>
          </div>
          <div style={{ width:1, height:20, background:'var(--line-soft)' }} />
          <div className="auth-silk" style={{ fontSize:10, color:'var(--muted)' }}>
            ▸ LOBBY ▸ <span style={{ color:'var(--ink)' }}>{title}</span>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          {rightSlot}
        </div>
      </div>

      {/* Amber marquee */}
      <div className="auth-marquee">
        <span>★ INSERT COIN TO CONTINUE</span>
        <span className="dot" />
        <span>{subtitle}</span>
        <span className="dot" />
        <span style={{ marginLeft:'auto' }}>KREWAUTH · ERC-8004 · SIWE · WEBAUTHN</span>
      </div>

      {/* Body */}
      <div className="auth-scan" style={{ flex:1, minHeight:0, overflow:'hidden', display:'flex' }}>
        {children}
      </div>

      {/* Footer */}
      {footer || (
        <div style={{
          display:'flex', alignItems:'center', justifyContent:'space-between',
          padding:'8px 16px', borderTop:'2px solid var(--line)', background:'var(--cream-md)',
          fontFamily:'"Silkscreen", monospace', fontSize:9, color:'var(--muted)', letterSpacing:1,
        }}>
          <span>© KREW INDUSTRIES · PRESS START</span>
          <span>v0.3.1 · krewauth</span>
          <span>↑↓←→ NAV · [A] SELECT · [B] BACK</span>
        </div>
      )}
    </div>
  );
}

// =======================================================================
// 1) LOGIN — CONNECT WALLET (SIWE)
// =======================================================================
function LoginWallet() {
  const chains = [
    { id:'krewnet', name:'KREWNET', chain:'48816', active:true },
    { id:'eth',     name:'ETHEREUM', chain:'1' },
    { id:'base',    name:'BASE',    chain:'8453' },
    { id:'op',      name:'OPTIMISM',chain:'10' },
  ];
  return (
    <AuthCabinet
      title="SIGN-IN ▸ WALLET"
      subtitle="SIWE · SIGN-IN WITH ETHEREUM"
      rightSlot={<>
        <div className="auth-chip slate">STEP 1/3</div>
        <button className="auth-btn tiny ghost inline">? HELP</button>
      </>}
    >
      {/* Left — the pick-a-wallet console */}
      <div style={{ flex:1.15, padding:'26px 32px', display:'flex', flexDirection:'column', gap:18, minWidth:0 }}>
        <div>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--amber-deep)' }}>▸ PLAYER · NEW GAME</div>
          <div className="auth-press" style={{ fontSize:22, marginTop:10, lineHeight:1.25 }}>
            CONNECT YOUR <span style={{ color:'var(--amber-deep)' }}>WALLET</span>
          </div>
          <div style={{ fontSize:13, color:'var(--muted)', marginTop:8, maxWidth:480, lineHeight:1.55 }}>
            Sign a message with your wallet to claim your krewhub account. No password, no email — just your key. Your wallet address becomes your player ID across all Krew tools.
          </div>
        </div>

        {/* Chain selector */}
        <div>
          <div className="auth-label">Network</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:8 }}>
            {chains.map(c => (
              <div key={c.id} className="auth-card" style={{
                padding:'10px 10px', boxShadow: c.active ? '3px 3px 0 var(--line)' : 'none',
                borderColor: c.active ? 'var(--line)' : 'var(--line-soft)',
                background: c.active ? 'var(--amber-cream)' : 'var(--cream-hi)',
                display:'flex', flexDirection:'column', gap:4, cursor:'pointer',
              }}>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span className={`auth-led ${c.active ? 'on' : 'off'}`} />
                  <span className="auth-silk" style={{ fontSize:10 }}>{c.name}</span>
                </div>
                <div className="auth-mono" style={{ fontSize:10, color:'var(--muted)' }}>chain: {c.chain}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Wallet providers grid */}
        <div>
          <div className="auth-label">Pick a wallet provider</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            {[
              { n:'METAMASK',    s:'a', i:'🦊', d:'Browser extension · eth_requestAccounts', primary:true },
              { n:'RAINBOW',     s:'b', i:'◉',  d:'WalletConnect v2' },
              { n:'COINBASE',    s:'d', i:'◆',  d:'Coinbase Smart Wallet' },
              { n:'LEDGER',      s:'ink',i:'▤', d:'Hardware · connect via USB' },
            ].map(w => (
              <div key={w.n} className="auth-card" style={{
                padding:10, display:'flex', gap:10, alignItems:'center',
                boxShadow: w.primary ? '4px 4px 0 var(--line)' : '3px 3px 0 var(--line)',
                background: w.primary ? 'var(--amber-cream)' : 'var(--cream-hi)',
              }}>
                <div className={`auth-stripes-${w.s}`} style={{
                  width:44, height:44, border:'2px solid var(--line)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  color: w.s === 'ink' ? 'var(--amber)' : 'var(--ink)',
                  fontFamily:'"Press Start 2P", monospace', fontSize:14,
                }}>{w.i}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div className="auth-silk" style={{ fontSize:11 }}>{w.n}</div>
                  <div style={{ fontSize:10, color:'var(--muted)', marginTop:2 }}>{w.d}</div>
                </div>
                {w.primary && <span className="auth-chip amber">DEFAULT</span>}
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop:'auto', display:'flex', gap:8 }}>
          <button className="auth-btn primary">▶ CONNECT · SIGN MESSAGE</button>
          <button className="auth-btn inline" style={{ width:'auto' }}>⎇ OTHER PLUGIN</button>
        </div>
      </div>

      {/* Right — SIWE message preview (phosphor) */}
      <aside style={{
        width:400, borderLeft:'2px solid var(--line)', background:'var(--cream-md)',
        display:'flex', flexDirection:'column', padding:20, gap:14, overflow:'hidden',
      }}>
        <div>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--muted)' }}>▸ MESSAGE TO SIGN · EIP-4361</div>
          <div className="auth-press" style={{ fontSize:12, marginTop:6 }}>SIWE PREVIEW</div>
        </div>
        <div className="auth-phos" style={{ padding:'12px 14px', fontSize:15, lineHeight:1.45, flex:1, overflow:'auto' }}>
          <div><span className="hi">krewhub.krew.dev</span> wants you</div>
          <div>to sign in with your ethereum</div>
          <div>account:</div>
          <div><span className="hi">0x7a3f...c9d2</span></div>
          <div>&nbsp;</div>
          <div className="dim">URI: https://krewhub.krew.dev</div>
          <div className="dim">Version: 1</div>
          <div className="dim">Chain ID: 48816</div>
          <div className="dim">Nonce: <span className="hi">8fQp_X2v</span></div>
          <div className="dim">Issued At: 2026-04-23T14:02:10Z</div>
          <div className="dim">Expires: 2026-04-23T14:12:10Z</div>
          <div>&nbsp;</div>
          <div>Statement:</div>
          <div><span className="hi">I accept the Krew terms.</span></div>
          <div><span className="hi">No funds will be moved.</span></div>
          <div>_<span style={{ animation:'auth-blink .7s step-end infinite' }}>▮</span></div>
        </div>

        <div className="auth-card" style={{ padding:'10px 12px', boxShadow:'none', borderColor:'var(--line-soft)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
            <span className="auth-chip emerald">SAFE</span>
            <span className="auth-silk" style={{ fontSize:9, color:'var(--muted)' }}>WHY YOU CAN TRUST THIS</span>
          </div>
          <ul style={{ margin:0, paddingLeft:16, fontSize:11, lineHeight:1.55, color:'var(--muted)' }}>
            <li>Signature proves key ownership. <b style={{ color:'var(--ink)' }}>No transaction, no gas.</b></li>
            <li>Nonce expires in 10 minutes.</li>
            <li>Domain-bound — can't be replayed to another site.</li>
          </ul>
        </div>
      </aside>
    </AuthCabinet>
  );
}

// =======================================================================
// 2) LOGIN — USERNAME + PASSWORD
// =======================================================================
function LoginPassword() {
  return (
    <AuthCabinet
      title="SIGN-IN ▸ PASSWORD"
      subtitle="CLASSIC · FOR HUMANS"
      rightSlot={<>
        <div className="auth-chip slate">STEP 1/2</div>
        <button className="auth-btn tiny ghost inline">? HELP</button>
      </>}
    >
      {/* Left — login form as an arcade save-screen */}
      <div style={{ flex:1, padding:'30px 38px', display:'flex', flexDirection:'column', gap:16, minWidth:0 }}>
        <div>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--amber-deep)' }}>▸ ENTER CREDENTIALS</div>
          <div className="auth-press" style={{ fontSize:22, marginTop:10, lineHeight:1.25 }}>
            SIGN IN TO <span style={{ color:'var(--amber-deep)' }}>KREWHUB</span>
          </div>
          <div style={{ fontSize:13, color:'var(--muted)', marginTop:8, maxWidth:480, lineHeight:1.55 }}>
            One account works across cookrew, krewcli, krewhub and the watchtower. Prefer plugins? <u style={{ color:'var(--ink)' }}>Use a wallet plugin instead</u>.
          </div>
        </div>

        {/* Username */}
        <div>
          <label className="auth-label">Username or email</label>
          <div style={{ position:'relative' }}>
            <input className="auth-input" defaultValue="alex@krew.dev" style={{ paddingLeft:36 }} />
            <div style={{ position:'absolute', left:10, top:10, fontFamily:'"Press Start 2P", monospace', fontSize:12, color:'var(--muted)' }}>@</div>
          </div>
          <div className="auth-mono" style={{ fontSize:10, color:'var(--muted)', marginTop:4 }}>
            ✓ account found · player_id <span style={{ color:'var(--ink)' }}>alex</span> · last seen 14m ago
          </div>
        </div>

        {/* Password */}
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <label className="auth-label">Password</label>
            <button className="auth-btn tiny ghost inline">FORGOT?</button>
          </div>
          <div style={{ position:'relative' }}>
            <input className="auth-input" type="password" defaultValue="●●●●●●●●●●●●" style={{ paddingRight:72 }} />
            <button className="auth-btn tiny inline" style={{ position:'absolute', right:6, top:5, boxShadow:'1px 1px 0 var(--line)' }}>SHOW</button>
          </div>
          <div style={{ display:'flex', gap:4, marginTop:6 }}>
            {[1,1,1,1,1,0,0,0].map((on,i) => (
              <div key={i} style={{ flex:1, height:6, background: on ? 'var(--emerald)' : 'var(--cream-dk)', border:'1.5px solid var(--line)' }} />
            ))}
          </div>
          <div className="auth-mono" style={{ fontSize:10, color:'var(--emerald-dim)', marginTop:4 }}>
            STRENGTH · STRONG (5/8) · 14 chars · mixed case · digits
          </div>
        </div>

        {/* Options */}
        <div style={{ display:'flex', alignItems:'center', gap:14, marginTop:4 }}>
          <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer' }}>
            <span style={{
              width:18, height:18, border:'2px solid var(--line)', background:'var(--amber)',
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              fontFamily:'"Press Start 2P", monospace', fontSize:10,
            }}>✓</span>
            <span className="auth-silk" style={{ fontSize:10 }}>REMEMBER THIS CABINET · 30D</span>
          </label>
          <span className="auth-chip slate">2FA ENABLED</span>
        </div>

        <div style={{ display:'flex', gap:10, marginTop:6 }}>
          <button className="auth-btn primary">▶ PRESS START · SIGN IN</button>
          <button className="auth-btn inline" style={{ width:'auto' }}>＋ NEW ACCOUNT</button>
        </div>

        <div className="auth-dash" style={{ margin:'8px 0 4px' }} />

        {/* Alt providers row */}
        <div>
          <div className="auth-silk" style={{ fontSize:9, color:'var(--muted)', marginBottom:8 }}>▸ OR SIGN IN WITH</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
            <button className="auth-btn violet inline">⎇ PLUGIN</button>
            <button className="auth-btn inline">⌘ WALLET · SIWE</button>
            <button className="auth-btn inline">▢ SSO · GITHUB</button>
          </div>
        </div>
      </div>

      {/* Right — 8-bit keypad (the "arcade" angle) */}
      <aside style={{
        width:400, borderLeft:'2px solid var(--line)', background:'var(--cream-md)',
        display:'flex', flexDirection:'column', padding:20, gap:14, overflow:'hidden',
      }}>
        <div>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--muted)' }}>▸ RETRO · ARCADE KEYPAD</div>
          <div className="auth-press" style={{ fontSize:12, marginTop:6 }}>TAP TO TYPE</div>
        </div>

        <div className="auth-card" style={{ padding:'16px 14px' }}>
          {/* Simulated display */}
          <div className="auth-phos" style={{ padding:'10px 12px', fontSize:18, letterSpacing:3, marginBottom:14 }}>
            <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, letterSpacing:1 }}>
              <span className="dim">&gt; password</span><span className="hi">14</span>
            </div>
            <div style={{ marginTop:4 }}>●●●●●●●●●●●●<span className="hi" style={{ animation:'auth-blink .7s step-end infinite' }}>▮</span></div>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:8, placeItems:'center' }}>
            {['1','2','3','4','5','6','7','8','9'].map(k => (
              <div key={k} className="auth-key">{k}</div>
            ))}
            <div className="auth-key">✳</div>
            <div className="auth-key">0</div>
            <div className="auth-key dark">⌫</div>
          </div>

          <div style={{ display:'flex', gap:8, marginTop:12 }}>
            <div className="auth-key wide" style={{ background:'var(--amber)' }}>A · OK</div>
            <div className="auth-key wide" style={{ background:'var(--rose-soft)', color:'var(--rose)' }}>B · CLR</div>
          </div>
        </div>

        <div className="auth-card" style={{ padding:'10px 12px', boxShadow:'none', borderColor:'var(--line-soft)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:6 }}>
            <span className="auth-led busy" />
            <span className="auth-silk" style={{ fontSize:9 }}>RATE LIMIT</span>
          </div>
          <div className="auth-mono" style={{ fontSize:11, color:'var(--muted)' }}>
            2 of 5 attempts used · resets in 04:12
          </div>
        </div>
      </aside>
    </AuthCabinet>
  );
}

// =======================================================================
// 3) LOGIN — PLUGIN WALLET (injected browser-extension wallets)
// =======================================================================
function LoginPlugin() {
  const plugins = [
    { n:'METAMASK',   s:'a',   i:'🦊', d:'Injected · window.ethereum',        chains:'EVM · 60+ chains', detected:true, primary:true },
    { n:'RABBY',      s:'b',   i:'◈',  d:'Injected · pre-tx risk scan',       chains:'EVM · security-first', detected:true },
    { n:'PHANTOM',    s:'d',   i:'◉',  d:'Injected · window.solana',          chains:'Solana · EVM · Bitcoin', detected:false },
    { n:'COINBASE',   s:'c',   i:'◆',  d:'Injected · Smart Wallet fallback',  chains:'EVM · Base', detected:false },
    { n:'RAINBOW',    s:'b',   i:'▢',  d:'Injected · mobile deeplink',        chains:'EVM · L2s', detected:false },
    { n:'KREW PLUGIN',s:'ink', i:'▣',  d:'First-party · session-scoped',      chains:'krewnet · 48816', detected:true },
  ];
  return (
    <AuthCabinet
      title="SIGN-IN ▸ PLUGIN WALLET"
      subtitle="EIP-6963 · INJECTED PROVIDERS · SIWE"
      rightSlot={<>
        <div className="auth-chip violet">EIP-6963</div>
        <button className="auth-btn tiny ghost inline">? HELP</button>
      </>}
    >
      {/* Left — detected plugins */}
      <div style={{ flex:1.15, padding:'26px 32px', display:'flex', flexDirection:'column', gap:18, minWidth:0 }}>
        <div>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--violet-ink)' }}>▸ PLAYER · DISCOVER</div>
          <div className="auth-press" style={{ fontSize:22, marginTop:10, lineHeight:1.25 }}>
            USE A <span style={{ color:'var(--violet-ink)' }}>PLUGIN WALLET</span>
          </div>
          <div style={{ fontSize:13, color:'var(--muted)', marginTop:8, maxWidth:500, lineHeight:1.55 }}>
            Krewauth discovers wallet plugins installed in your browser via EIP-6963 — no hardcoded list, no popup blockers. Pick one, sign once, you're in. One wallet per player: the first plugin you connect becomes your player ID.
          </div>
        </div>

        {/* Detection banner */}
        <div className="auth-card" style={{ padding:'10px 14px', display:'flex', alignItems:'center', gap:10, background:'var(--emerald-soft)' }}>
          <span className="auth-led on" />
          <div className="auth-silk" style={{ fontSize:10 }}>3 PLUGINS DETECTED · 3 AVAILABLE ON STORE</div>
          <div style={{ flex:1 }} />
          <span className="auth-mono" style={{ fontSize:10, color:'var(--muted)' }}>scan · 42ms</span>
        </div>

        {/* Plugin grid */}
        <div>
          <div className="auth-label">Injected providers</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            {plugins.map(p => (
              <div key={p.n} className="auth-card" style={{
                padding:12, display:'flex', gap:10, alignItems:'flex-start',
                boxShadow: p.primary ? '4px 4px 0 var(--line)' : (p.detected ? '3px 3px 0 var(--line)' : 'none'),
                borderColor: p.detected ? 'var(--line)' : 'var(--line-soft)',
                background: p.primary ? 'var(--amber-cream)' : (p.detected ? 'var(--cream-hi)' : 'var(--cream-md)'),
                opacity: p.detected ? 1 : 0.55,
              }}>
                <div className={`auth-stripes-${p.s}`} style={{
                  width:44, height:44, border:'2px solid var(--line)', flexShrink:0,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  color: p.s === 'ink' ? 'var(--amber)' : 'var(--ink)',
                  fontFamily:'"Press Start 2P", monospace', fontSize:14,
                }}>{p.i}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                    <div className="auth-silk" style={{ fontSize:11 }}>{p.n}</div>
                    {p.primary && <span className="auth-chip amber">LAST USED</span>}
                  </div>
                  <div style={{ fontSize:10, color:'var(--muted)', marginTop:2, lineHeight:1.45 }}>{p.d}</div>
                  <div className="auth-mono" style={{ fontSize:9, color:'var(--muted)', marginTop:4 }}>{p.chains}</div>
                </div>
                <span className={`auth-chip ${p.detected ? 'emerald' : 'slate'}`} style={{ fontSize:8 }}>
                  {p.detected ? 'READY' : 'INSTALL'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* One-wallet-per-player notice */}
        <div className="auth-sunken" style={{ padding:'10px 12px', display:'flex', gap:10, alignItems:'flex-start' }}>
          <div style={{ width:22, height:22, background:'var(--amber)', border:'2px solid var(--line)',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:11,
            fontFamily:'"Press Start 2P", monospace', flexShrink:0 }}>!</div>
          <div style={{ fontSize:11, color:'var(--ink-soft)', lineHeight:1.5 }}>
            <b>One wallet per player.</b> Your plugin's first signing address becomes <span className="auth-mono">player.wallet</span> and cannot be swapped — agent wallets (ERC-4337) are minted separately under it.
          </div>
        </div>

        <div style={{ marginTop:'auto', display:'flex', gap:8 }}>
          <button className="auth-btn primary">▶ CONNECT · SIGN SIWE</button>
          <button className="auth-btn inline" style={{ width:'auto' }}>@ PASSWORD</button>
          <button className="auth-btn inline" style={{ width:'auto' }}>⎇ RESCAN</button>
        </div>
      </div>

      {/* Right — EIP-6963 phosphor log */}
      <aside style={{
        width:400, borderLeft:'2px solid var(--line)', background:'var(--cream-md)',
        display:'flex', flexDirection:'column', padding:20, gap:14, overflow:'hidden',
      }}>
        <div>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--muted)' }}>▸ DISCOVERY · EIP-6963</div>
          <div className="auth-press" style={{ fontSize:12, marginTop:6 }}>PROVIDER BUS</div>
        </div>

        <div className="auth-phos" style={{ padding:'12px 14px', fontSize:13, lineHeight:1.55, flex:1, overflow:'hidden' }}>
          <div>&gt; window.dispatchEvent(</div>
          <div>&nbsp;&nbsp;new Event('<span className="hi">eip6963:requestProvider</span>'))</div>
          <div className="dim">&gt; ...</div>
          <div>&gt; <span className="hi">announceProvider</span> · metamask</div>
          <div className="dim">&nbsp;&nbsp;uuid: 7a1e-...-d3f0</div>
          <div className="dim">&nbsp;&nbsp;rdns: io.metamask</div>
          <div>&gt; <span className="hi">announceProvider</span> · rabby</div>
          <div className="dim">&nbsp;&nbsp;rdns: io.rabby</div>
          <div>&gt; <span className="hi">announceProvider</span> · krew</div>
          <div className="dim">&nbsp;&nbsp;rdns: dev.krew.plugin</div>
          <div>&gt; 3 providers ready</div>
          <div>&gt; await <span className="hi">siwe</span>.prepareMessage()</div>
          <div>&gt; waiting on user<span className="hi" style={{ animation:'auth-blink .7s step-end infinite' }}>▮</span></div>
        </div>

        <div className="auth-dash" />

        <div className="auth-sunken" style={{ padding:'10px 12px' }}>
          <div className="auth-silk" style={{ fontSize:9, color:'var(--muted)', marginBottom:6 }}>▸ PLUGIN STORE · COMING SOON</div>
          <div style={{ fontSize:11, color:'var(--ink-soft)', lineHeight:1.5 }}>
            Third-party <b>krew plugins</b> — custom signers, MPC shards, hardware bridges — register via <span className="auth-mono">krew.registerPlugin()</span>.
          </div>
        </div>
      </aside>
    </AuthCabinet>
  );
}

// =======================================================================
// 4) PROFILE / PLAYER CARD
// =======================================================================
function ProfilePage() {
  return (
    <AuthCabinet
      width={1280} height={860}
      title="PLAYER CARD ▸ ALEX"
      subtitle="ACCOUNT · AUTHORITIES · AGENTS"
      rightSlot={<>
        <div className="auth-sunken" style={{ padding:'4px 10px', display:'flex', alignItems:'center', gap:8 }}>
          <span className="auth-coin" />
          <span className="auth-mono" style={{ fontSize:12, fontWeight:600 }}>248</span>
        </div>
        <button className="auth-btn tiny inline">⚙ SETTINGS</button>
        <button className="auth-btn tiny danger inline">⏻ SIGN OUT</button>
      </>}
    >
      {/* Left column — hero + identity */}
      <div style={{ flex:1.1, padding:'22px 26px', display:'flex', flexDirection:'column', gap:16, minWidth:0, overflow:'auto' }}>

        {/* Player hero card */}
        <div className="auth-card" style={{ padding:0, overflow:'hidden' }}>
          <div className="auth-stripes-a" style={{
            height:96, borderBottom:'2px solid var(--line)', position:'relative',
            display:'flex', alignItems:'center', paddingLeft:130,
          }}>
            {/* big avatar */}
            <div style={{
              position:'absolute', left:20, bottom:-24,
              width:96, height:96, background:'var(--cream-hi)', border:'2px solid var(--line)',
              boxShadow:'4px 4px 0 var(--line)',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'"Press Start 2P", monospace', fontSize:38, color:'var(--ink)',
            }}>A</div>
            <div>
              <div className="auth-silk" style={{ fontSize:10, color:'var(--ink-soft)' }}>▸ PLAYER · LVL 07 · RANK GOLD</div>
              <div className="auth-press" style={{ fontSize:16, marginTop:6 }}>ALEX KIM</div>
            </div>
            <div style={{ marginLeft:'auto', marginRight:16, display:'flex', gap:6 }}>
              <span className="auth-chip emerald"><span className="auth-led on" />ONLINE</span>
              <span className="auth-chip slate">SINCE 2024-09</span>
            </div>
          </div>

          <div style={{ padding:'36px 22px 18px', display:'grid', gridTemplateColumns:'1.2fr 1fr', gap:20 }}>
            <div>
              <div className="auth-label">Handle · email</div>
              <div className="auth-mono" style={{ fontSize:13, marginBottom:10 }}>alex · alex@krew.dev</div>

              <div className="auth-label">Account ID</div>
              <div className="auth-mono" style={{ fontSize:12, color:'var(--muted)', marginBottom:10 }}>acc_01HN6TP2R9X3Y7Z4K8M2V5Q1B6</div>

              <div className="auth-label">ERC-8004 agent identity</div>
              <div className="auth-mono" style={{ fontSize:12, color:'var(--muted)' }}>
                did:pkh:eip155:48816:0x7a3f...c9d2
              </div>
            </div>

            {/* Stats grid */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
              {[
                ['DIGESTS', '42',  '+6 this wk'],
                ['RECIPES', '8',   'owned'],
                ['COINS',   '248', 'earned'],
                ['AGENTS',  '3',   'minted'],
              ].map(([k,v,sub]) => (
                <div key={k} className="auth-sunken" style={{ padding:'8px 10px' }}>
                  <div className="auth-silk" style={{ fontSize:9, color:'var(--muted)' }}>▸ {k}</div>
                  <div className="auth-press" style={{ fontSize:14, marginTop:4 }}>{v}</div>
                  <div className="auth-mono" style={{ fontSize:10, color:'var(--muted)', marginTop:2 }}>{sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Authority — Player Wallet (single, plugin-bound) */}
        <div className="auth-card" style={{ padding:0 }}>
          <div style={{ padding:'10px 14px', borderBottom:'2px dashed var(--line-soft)', display:'flex', alignItems:'center', gap:10, background:'var(--cream-hi)' }}>
            <span className="auth-chip amber">PLAYER WALLET</span>
            <div className="auth-silk" style={{ fontSize:10, color:'var(--muted)' }}>▸ ONE PER PLAYER · PLUGIN-BOUND · SIWE</div>
            <div style={{ flex:1 }} />
            <button className="auth-btn tiny inline">CHANGE PLUGIN</button>
          </div>
          <div style={{ padding:'16px 18px', display:'grid', gridTemplateColumns:'1fr 1fr', gap:18 }}>
            {/* Left — the wallet itself */}
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                <div className="auth-stripes-a" style={{ width:56, height:56, border:'2px solid var(--line)',
                  boxShadow:'3px 3px 0 var(--line)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontFamily:'"Press Start 2P", monospace', fontSize:22 }}>⌘</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6, flexWrap:'wrap' }}>
                    <span className="auth-press" style={{ fontSize:13 }}>ALEX.KREW</span>
                    <span className="auth-chip emerald"><span className="auth-led on" />LIVE</span>
                  </div>
                  <div className="auth-mono" style={{ fontSize:11, color:'var(--muted)', marginTop:4 }}>0x7a3f…c9d2</div>
                </div>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
                <div className="auth-sunken" style={{ padding:'6px 8px' }}>
                  <div className="auth-silk" style={{ fontSize:8, color:'var(--muted)' }}>CHAIN</div>
                  <div className="auth-mono" style={{ fontSize:11 }}>krewnet · 48816</div>
                </div>
                <div className="auth-sunken" style={{ padding:'6px 8px' }}>
                  <div className="auth-silk" style={{ fontSize:8, color:'var(--muted)' }}>TX SIGNED</div>
                  <div className="auth-mono" style={{ fontSize:11 }}>214</div>
                </div>
                <div className="auth-sunken" style={{ padding:'6px 8px' }}>
                  <div className="auth-silk" style={{ fontSize:8, color:'var(--muted)' }}>SIWE EXPIRES</div>
                  <div className="auth-mono" style={{ fontSize:11 }}>11h 23m</div>
                </div>
                <div className="auth-sunken" style={{ padding:'6px 8px' }}>
                  <div className="auth-silk" style={{ fontSize:8, color:'var(--muted)' }}>NONCE</div>
                  <div className="auth-mono" style={{ fontSize:11 }}>8fQp_X2v</div>
                </div>
              </div>
              <div style={{ display:'flex', gap:6 }}>
                <button className="auth-btn tiny inline">COPY ADDR</button>
                <button className="auth-btn tiny inline">RE-SIGN SIWE</button>
                <button className="auth-btn tiny inline">DISCONNECT</button>
              </div>
            </div>
            {/* Right — plugin source + permissions */}
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <div className="auth-card" style={{ padding:'8px 10px', background:'var(--cream-hi)',
                display:'flex', alignItems:'center', gap:10 }}>
                <div className="auth-stripes-a" style={{ width:28, height:28, border:'2px solid var(--line)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontFamily:'"Press Start 2P", monospace', fontSize:12 }}>🦊</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div className="auth-silk" style={{ fontSize:10 }}>SIGNED BY · METAMASK</div>
                  <div className="auth-mono" style={{ fontSize:10, color:'var(--muted)' }}>io.metamask · v12.4.1 · injected</div>
                </div>
                <span className="auth-chip violet">PLUGIN</span>
              </div>
              <div className="auth-label">Permissions granted to krewhub</div>
              <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                {[
                  ['personal_sign',     'auto · siwe refresh',     true],
                  ['eth_sendTransaction','ask every time',         true],
                  ['wallet_watchAsset', 'KREW · CHIP · AGENT',     true],
                  ['eth_signTypedData', 'ask · EIP-712 only',      true],
                ].map(([p, d, on]) => (
                  <div key={p} style={{ display:'flex', alignItems:'center', gap:8, padding:'3px 0' }}>
                    <span className={`auth-led ${on ? 'on' : 'off'}`} />
                    <span className="auth-mono" style={{ fontSize:11, flex:'0 0 170px' }}>{p}</span>
                    <span style={{ fontSize:10, color:'var(--muted)' }}>{d}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Agents — ERC-4337 AA wallets (per-user, multiple allowed) */}
        <div className="auth-card" style={{ padding:0 }}>
          <div style={{ padding:'10px 14px', borderBottom:'2px dashed var(--line-soft)', display:'flex', alignItems:'center', gap:10, background:'var(--cream-hi)' }}>
            <span className="auth-chip blue">AGENT WALLETS</span>
            <div className="auth-silk" style={{ fontSize:10, color:'var(--muted)' }}>▸ ERC-4337 · SESSION KEYS · OWNED BY PLAYER WALLET</div>
            <div style={{ flex:1 }} />
            <span className="auth-chip slate">4 / 10 USED</span>
            <button className="auth-btn tiny primary inline">＋ MINT AGENT</button>
          </div>

          {/* Column headers */}
          <div style={{ padding:'6px 14px', display:'grid',
            gridTemplateColumns:'140px 150px 1fr 110px 100px 110px', gap:8,
            borderBottom:'1px dashed var(--line-soft)', background:'var(--cream-md)' }}>
            {['AGENT','AA ADDRESS','SESSION KEY · LIMITS','SPENT 24H','DIGESTS','STATE'].map(h => (
              <div key={h} className="auth-silk" style={{ fontSize:9, color:'var(--muted)' }}>▸ {h}</div>
            ))}
          </div>

          <div>
            {[
              { n:'SCOUT',      c:'c', aa:'0xA1…E7', sess:'sess_14', policy:'read-only · 0.2 ETH cap', spent:'0.03', digests:28, state:'on' },
              { n:'GATEKEEPER', c:'b', aa:'0xC4…2F', sess:'sess_19', policy:'approve · 2/3 multisig',    spent:'0.11', digests:36, state:'on' },
              { n:'REFLEX',     c:'d', aa:'0x6D…8B', sess:'sess_07', policy:'rapid · 0.05 ETH · 5min',   spent:'0.04', digests:6,  state:'on' },
              { n:'ARCHIVIST',  c:'a', aa:'0x2F…41', sess:'sess_22', policy:'write-only · IPFS pin',     spent:'0.00', digests:12, state:'paused' },
            ].map((a, i) => (
              <div key={a.n} style={{
                padding:'10px 14px', display:'grid',
                gridTemplateColumns:'140px 150px 1fr 110px 100px 110px', gap:8, alignItems:'center',
                borderTop: i === 0 ? 'none' : '1px dashed var(--line-soft)',
              }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <div className={`auth-stripes-${a.c}`} style={{ width:26, height:26, border:'2px solid var(--line)',
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontFamily:'"Press Start 2P", monospace', fontSize:11 }}>◆</div>
                  <span className="auth-silk" style={{ fontSize:10 }}>{a.n}</span>
                </div>
                <span className="auth-mono" style={{ fontSize:10 }}>{a.aa}</span>
                <div style={{ minWidth:0 }}>
                  <div className="auth-mono" style={{ fontSize:10 }}>{a.sess}</div>
                  <div style={{ fontSize:10, color:'var(--muted)', marginTop:1 }}>{a.policy}</div>
                </div>
                <span className="auth-mono" style={{ fontSize:11 }}>{a.spent} ETH</span>
                <span className="auth-mono" style={{ fontSize:11 }}>{a.digests}</span>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span className={`auth-led ${a.state === 'on' ? 'on' : 'off'}`} />
                  <span className="auth-silk" style={{ fontSize:9 }}>{a.state === 'on' ? 'ACTIVE' : 'PAUSED'}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Session key limits recap */}
          <div style={{ padding:'10px 14px', borderTop:'2px dashed var(--line-soft)', background:'var(--cream-hi)',
            display:'flex', alignItems:'center', gap:14 }}>
            <div className="auth-silk" style={{ fontSize:9, color:'var(--muted)' }}>▸ POLICY · AGENT WALLETS CANNOT</div>
            <span className="auth-chip slate">ROTATE PLAYER WALLET</span>
            <span className="auth-chip slate">BRIDGE OFF KREWNET</span>
            <span className="auth-chip slate">TRANSFER &gt; 1 ETH</span>
            <div style={{ flex:1 }} />
            <button className="auth-btn tiny inline">EDIT POLICY</button>
          </div>
        </div>

      </div>

      {/* Right rail — security timeline + sessions */}
      <aside style={{
        width:380, borderLeft:'2px solid var(--line)', background:'var(--cream-md)',
        display:'flex', flexDirection:'column', overflow:'hidden',
      }}>
        <div style={{ padding:'12px 16px', borderBottom:'2px solid var(--line)', background:'var(--amber)' }}>
          <div className="auth-silk" style={{ fontSize:10, color:'var(--ink-soft)' }}>▸ HIGH SCORE · REPUTATION</div>
          <div className="auth-press" style={{ fontSize:12, marginTop:5 }}>PLAYER STATS</div>
        </div>

        {/* Weekly sparkbars */}
        <div style={{ padding:'14px 16px', borderBottom:'1px dashed var(--line-soft)' }}>
          <div className="auth-silk" style={{ fontSize:9, color:'var(--muted)', marginBottom:8 }}>▸ DIGESTS THIS WEEK · 42</div>
          <div style={{ display:'flex', alignItems:'flex-end', gap:4, height:60 }}>
            {[12,18,9,22,14,27,8].map((v,i) => (
              <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
                <div style={{ width:'100%', height:v*2, background:'var(--amber)', border:'1.5px solid var(--line)' }} />
                <div className="auth-mono" style={{ fontSize:9, color:'var(--muted)' }}>{['M','T','W','T','F','S','S'][i]}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Active sessions */}
        <div style={{ padding:'12px 16px', borderBottom:'1px dashed var(--line-soft)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
            <div className="auth-silk" style={{ fontSize:10 }}>▸ ACTIVE SESSIONS</div>
            <span className="auth-chip slate" style={{ marginLeft:'auto' }}>4</span>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {[
              { d:'MacBook · Chrome · SF',   m:'siwe · metamask', t:'now', here:true },
              { d:'iPhone · Safari · SF',    m:'siwe · rabby',    t:'2h' },
              { d:'krewcli · device · tty',  m:'device',  t:'6h' },
              { d:'krewcli · CI · github',   m:'code',    t:'2d' },
            ].map((s,i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0', borderTop: i === 0 ? 'none' : '1px dashed var(--line-soft)' }}>
                <span className={`auth-led ${s.here ? 'on' : 'off'}`} />
                <div style={{ flex:1, minWidth:0 }}>
                  <div className="auth-mono" style={{ fontSize:11, color:'var(--ink)' }}>{s.d}</div>
                  <div className="auth-silk" style={{ fontSize:9, color:'var(--muted)' }}>{s.m} · {s.t}</div>
                </div>
                {s.here ? <span className="auth-chip emerald">THIS</span> : <button className="auth-btn tiny danger inline">END</button>}
              </div>
            ))}
          </div>
        </div>

        {/* Security log */}
        <div style={{ padding:'12px 16px', flex:1, overflow:'auto', display:'flex', flexDirection:'column', gap:6 }}>
          <div className="auth-silk" style={{ fontSize:10, marginBottom:4 }}>▸ SECURITY LOG</div>
          {[
            { t:'14m', k:'siwe.verify.ok',     d:'MacBook · metamask plugin', c:'emerald' },
            { t:'2h',  k:'siwe.verify.ok',     d:'0x7a3f..c9d2 · krewnet', c:'emerald' },
            { t:'6h',  k:'device.approve.ok',  d:'krewcli · laptop', c:'blue' },
            { t:'yday',k:'agent.session.new',  d:'SCOUT · sess_14 · 7d ttl', c:'violet' },
            { t:'2d',  k:'session.revoke',     d:'CI · github-actions', c:'rose' },
            { t:'3d',  k:'agent.deploy',       d:'REFLEX · 0x6D..8B', c:'amber' },
          ].map((e,i) => (
            <div key={i} style={{ display:'flex', gap:8, alignItems:'flex-start', padding:'5px 0', borderTop: i === 0 ? 'none' : '1px dashed var(--line-soft)' }}>
              <span className="auth-mono" style={{ fontSize:10, color:'var(--muted)', width:32, flexShrink:0 }}>{e.t}</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div className="auth-mono" style={{ fontSize:11, color:'var(--ink)' }}>{e.k}</div>
                <div style={{ fontSize:10, color:'var(--muted)' }}>{e.d}</div>
              </div>
              <span className={`auth-chip ${e.c}`} style={{ fontSize:8 }}>OK</span>
            </div>
          ))}
        </div>

        <div className="auth-phos" style={{ margin:12, padding:'10px 12px', fontSize:13, lineHeight:1.5 }}>
          <div>&gt; <span className="hi">krewauth</span> jwt · 11h 23m left</div>
          <div>&gt; <span className="hi">rotate</span> in 22h</div>
          <div>&gt; _<span style={{ animation:'auth-blink .7s step-end infinite' }}>▮</span></div>
        </div>
      </aside>
    </AuthCabinet>
  );
}

Object.assign(window, { LoginWallet, LoginPassword, LoginPlugin, ProfilePage });
