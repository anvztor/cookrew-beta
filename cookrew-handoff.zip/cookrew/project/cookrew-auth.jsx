// Cookrew Auth — sign in / sign up
//   • Desktop: split layout (brand pane | form pane)
//   • Mobile:  stacked, brand banner shrinks to header

function CkAuth({ variant = 'desktop', mode = 'signin' }) {
  const { CkBtn, CkInput, CkChip, CkLED, CkSprite, CK_PORTRAITS } = window;
  const isMobile = variant === 'mobile';
  return (
    <div className="ck" style={{
      width: '100%', height: '100%', minHeight: '100%',
      display: 'flex', flexDirection: isMobile ? 'column' : 'row',
      background: 'var(--cream)',
    }}>
      {/* Brand pane */}
      <div style={{
        flex: isMobile ? '0 0 auto' : 1,
        background: 'var(--amber)',
        borderRight: isMobile ? 'none' : '2px solid var(--line)',
        borderBottom: isMobile ? '2px solid var(--line)' : 'none',
        padding: isMobile ? '24px 20px' : '40px 36px',
        display: 'flex', flexDirection: 'column', gap: isMobile ? 14 : 20,
        position: 'relative', overflow: 'hidden',
        paddingTop: isMobile ? 'calc(24px + env(safe-area-inset-top, 0))' : 40,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div className="ck-display" style={{ fontSize: isMobile ? 18 : 26, color: '#1A1408' }}>COOKREW</div>
          <CkChip style={{ background: '#1A1408', color: 'var(--amber)', borderColor: '#1A1408' }}>BETA</CkChip>
        </div>
        <div style={{ fontFamily: 'Inter, sans-serif', fontSize: isMobile ? 16 : 22, fontWeight: 700, color: '#1A1408', lineHeight: 1.25, textWrap: 'balance', maxWidth: 360 }}>
          A multiplayer kitchen for humans and agents.
        </div>
        {!isMobile && (
          <div className="ck-mono" style={{ fontSize: 12, color: 'rgba(26,20,8,0.7)', maxWidth: 360, lineHeight: 1.5 }}>
            Bundle work. Spawn a party. Watch them cook.
          </div>
        )}
        {!isMobile && (
          <div style={{ display: 'flex', gap: 10, marginTop: 'auto', paddingTop: 30 }}>
            <CkSprite art={CK_PORTRAITS.scout} size={48} bg="rgba(255,255,255,0.4)" />
            <CkSprite art={CK_PORTRAITS.gatekeeper} size={48} bg="rgba(255,255,255,0.4)" />
            <CkSprite art={CK_PORTRAITS.brewer} size={48} bg="rgba(255,255,255,0.4)" />
          </div>
        )}
      </div>

      {/* Form pane */}
      <div style={{
        flex: 1, padding: isMobile ? '24px 20px 32px' : '40px 36px',
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        background: 'var(--cream)',
      }}>
        <div style={{ width: '100%', maxWidth: 360, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <div className="ck-kicker" style={{ fontSize: 9, marginBottom: 4 }}>{mode === 'signin' ? 'WELCOME BACK' : 'NEW OPERATOR'}</div>
            <div className="ck-display" style={{ fontSize: isMobile ? 18 : 22 }}>
              {mode === 'signin' ? 'SIGN IN' : 'CREATE ACCOUNT'}
            </div>
          </div>

          {mode === 'signup' && (
            <label style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              <span className="ck-kicker" style={{ fontSize: 8 }}>HANDLE</span>
              <CkInput placeholder="@scout-runner" />
            </label>
          )}
          <label style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <span className="ck-kicker" style={{ fontSize: 8 }}>EMAIL</span>
            <CkInput type="email" placeholder="alex@kitchen.dev" />
          </label>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <span className="ck-kicker" style={{ fontSize: 8 }}>PASSWORD</span>
            <CkInput type="password" placeholder="••••••••" />
          </label>

          <CkBtn variant="primary" block touch={isMobile}>{mode === 'signin' ? 'SIGN IN ▶' : 'CREATE ▶'}</CkBtn>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--muted)' }}>
            <span style={{ flex: 1, height: 1, background: 'var(--line-soft)' }} />
            <span className="ck-kicker" style={{ fontSize: 8 }}>OR</span>
            <span style={{ flex: 1, height: 1, background: 'var(--line-soft)' }} />
          </div>

          <CkBtn block touch={isMobile}>▤ CONTINUE WITH GITHUB</CkBtn>
          <CkBtn block touch={isMobile}>♦ CONTINUE WITH SSO</CkBtn>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 }}>
            <span className="ck-mono" style={{ fontSize: 11, color: 'var(--muted)' }}>
              {mode === 'signin' ? 'New here?' : 'Already cooking?'}
            </span>
            <a href="#" className="ck-display" style={{ fontSize: 10, color: 'var(--ink-soft)', textDecoration: 'underline' }}>
              {mode === 'signin' ? 'CREATE ACCOUNT' : 'SIGN IN'}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CkAuth });
