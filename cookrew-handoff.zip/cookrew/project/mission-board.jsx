// Mission Board — bundle tasks as pinned cards with string-drawn dependencies
// Uses SVG overlay for the "yarn" strings between cards.

const TASKS = [
  { id: 't1', no: '01', title: 'Add heartbeat endpoint', status: 'done',
    assignee: 'SCOUT', role: 'GPT-5-MINI', deps: [],
    meta: { mil: 3, facts: 2, code: 1 }, xp: 120, reward: '+XP 120',
    col: 0, row: 0 },
  { id: 't2', no: '02', title: 'Route CLI task.claim', status: 'working',
    assignee: 'GATEKEEPER', role: 'CLAUDE-OPUS', deps: ['t1'],
    meta: { mil: 2, facts: 1, code: 1 }, xp: 180, reward: 'XP 180',
    col: 1, row: 0 },
  { id: 't3', no: '03', title: 'Persist AgentPresence.last_heartbeat', status: 'claimed',
    assignee: 'SMITH', role: 'CLAUDE-HAIKU', deps: ['t1'],
    meta: { mil: 0, facts: 0, code: 0 }, xp: 90, reward: 'XP 90',
    col: 1, row: 1 },
  { id: 't4', no: '04', title: 'Milestone retention sweep (7d TTL)', status: 'blocked',
    assignee: 'REFLEX', role: 'CODEX-TINY', deps: ['t2','t3'],
    meta: { mil: 0, facts: 0, code: 0 }, xp: 150, reward: 'XP 150',
    blockedReason: 'Cron runner not configured',
    col: 2, row: 0 },
  { id: 't5', no: '05', title: 'Submit bundle digest', status: 'locked',
    assignee: '—', role: 'UNCLAIMED', deps: ['t4'],
    meta: { mil: 0, facts: 0, code: 0 }, xp: 240, reward: 'XP 240',
    col: 3, row: 0 },
];

const STATUS_STYLES = {
  done:    { bg: '#D8F3E6', ink: '#0B4F2E', pin: '#059669', label: 'CLEARED' },
  working: { bg: '#FFF3AD', ink: '#5C4A1F', pin: '#D97706', label: 'IN PROGRESS' },
  claimed: { bg: '#DBEAFE', ink: '#1E40AF', pin: '#3B82F6', label: 'CLAIMED' },
  blocked: { bg: '#FEE2E2', ink: '#991B1B', pin: '#DC2626', label: 'BLOCKED' },
  locked:  { bg: '#F5F0E8', ink: '#78716C', pin: '#A8A29E', label: 'LOCKED' },
  open:    { bg: '#FFFEF5', ink: '#2D2A20', pin: '#2D2A20', label: 'OPEN' },
};

const CARD_W = 192, CARD_H = 132, COL_GAP = 52, ROW_GAP = 22;

function TaskCard({ t, hl, onHover, onClick }) {
  const { LED } = window;
  const st = STATUS_STYLES[t.status];
  const left = t.col * (CARD_W + COL_GAP);
  const top  = t.row * (CARD_H + ROW_GAP);
  return (
    <div
      data-task-id={t.id}
      onMouseEnter={() => onHover?.(t.id)}
      onMouseLeave={() => onHover?.(null)}
      onClick={() => onClick?.(t)}
      className={`pc-mission-card ${hl ? 'hl' : ''}`}
      style={{
        position: 'absolute', left, top, width: CARD_W, height: CARD_H,
        background: st.bg,
        border: '2px solid var(--line)',
        boxShadow: '3px 3px 0 var(--line)',
        padding: 10,
        display: 'flex', flexDirection: 'column', gap: 6,
        cursor: 'pointer',
        transform: hl ? 'translate(-1px,-1px)' : 'none',
        outline: hl ? '3px solid var(--amber-deep)' : 'none',
        outlineOffset: 2,
      }}
    >
      {/* Pushpin */}
      <div style={{
        position: 'absolute', top: -8, left: 14,
        width: 14, height: 14, borderRadius: '50%',
        background: st.pin,
        border: '2px solid var(--line)',
        boxShadow: '1px 1px 0 var(--line), inset 1px 1px 0 rgba(255,255,255,0.5)',
      }}/>
      {/* Status LED + quest no */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div className="pc-silk" style={{ fontSize: 8, color: st.ink, opacity: 0.8 }}>QUEST #{t.no}</div>
        <div className="pc-chip" style={{ background: st.pin, color: '#fff', borderColor: 'var(--line)', fontSize: 7 }}>{st.label}</div>
      </div>
      {/* Title */}
      <div style={{ fontFamily: 'Inter', fontSize: 13, fontWeight: 700, color: st.ink, lineHeight: 1.2, flex: 1 }}>
        {t.title}
      </div>
      {/* Blocked reason */}
      {t.blockedReason && (
        <div className="pc-mono" style={{ fontSize: 9, color: st.ink, opacity: 0.85, lineHeight: 1.3 }}>
          ⚠ {t.blockedReason}
        </div>
      )}
      {/* Footer — assignee + reward */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 9, borderTop: '1px dashed var(--line)', paddingTop: 5 }}>
        <div className="pc-mono" style={{ color: st.ink, fontWeight: 600, fontSize: 10 }}>@{t.assignee}</div>
        <div className="pc-silk" style={{ fontSize: 8, color: st.ink }}>{t.reward}</div>
      </div>
    </div>
  );
}

function MissionBoard({ tasks = TASKS, highlightedTask, onHoverTask, onSelectTask, focusMode = false }) {
  // compute bounding size
  const cols = Math.max(...tasks.map(t => t.col)) + 1;
  const rows = Math.max(...tasks.map(t => t.row)) + 1;
  const W = cols * CARD_W + (cols - 1) * COL_GAP;
  const H = rows * CARD_H + (rows - 1) * ROW_GAP + 16;

  // build edges
  const edges = [];
  tasks.forEach(t => {
    t.deps.forEach(d => {
      const src = tasks.find(x => x.id === d);
      if (src) {
        edges.push({
          id: `${src.id}-${t.id}`,
          x1: src.col * (CARD_W + COL_GAP) + CARD_W,
          y1: src.row * (CARD_H + ROW_GAP) + CARD_H / 2,
          x2: t.col * (CARD_W + COL_GAP),
          y2: t.row * (CARD_H + ROW_GAP) + CARD_H / 2,
          active: src.status === 'done' && t.status !== 'locked',
          hl: highlightedTask === t.id || highlightedTask === src.id,
        });
      }
    });
  });

  return (
    <div style={{
      position: 'relative',
      padding: 20,
      paddingTop: 24,
      width: W + 40,
      minHeight: H + 40,
    }}>
      {/* String/yarn SVG overlay */}
      <svg width={W} height={H} style={{ position: 'absolute', left: 20, top: 24, pointerEvents: 'none' }}>
        <defs>
          <pattern id="yarn" patternUnits="userSpaceOnUse" width="8" height="2">
            <rect width="4" height="2" fill="#DC2626" />
          </pattern>
        </defs>
        {edges.map(e => {
          const mx = (e.x1 + e.x2) / 2;
          const color = e.hl ? '#D97706' : (e.active ? '#7A6AAB' : '#A8A29E');
          const dash = e.active ? '6 3' : '3 3';
          return (
            <g key={e.id}>
              {/* curve line */}
              <path
                d={`M ${e.x1} ${e.y1} C ${mx} ${e.y1}, ${mx} ${e.y2}, ${e.x2} ${e.y2}`}
                stroke={color} strokeWidth={e.hl ? 3 : 2}
                fill="none"
                strokeDasharray={dash}
              />
              {/* arrowhead */}
              <polygon
                points={`${e.x2},${e.y2} ${e.x2-6},${e.y2-4} ${e.x2-6},${e.y2+4}`}
                fill={color}
              />
              {/* pins on endpoints */}
              <circle cx={e.x1} cy={e.y1} r={3} fill="#2D2A20" />
              <circle cx={e.x2} cy={e.y2} r={3} fill="#2D2A20" />
            </g>
          );
        })}
      </svg>

      {tasks.map(t => (
        <TaskCard
          key={t.id} t={t}
          hl={highlightedTask === t.id}
          onHover={onHoverTask}
          onClick={onSelectTask}
        />
      ))}
    </div>
  );
}

Object.assign(window, { MissionBoard, TASKS, STATUS_STYLES });
