// Cookrew Responsive — design tokens + global styles
// Cream + amber + phosphor pixel-chrome aesthetic, scaled across breakpoints.

if (typeof document !== 'undefined' && !document.getElementById('ck-styles')) {
  const f = document.createElement('link');
  f.rel = 'stylesheet';
  f.href = 'https://fonts.googleapis.com/css2?family=VT323&family=Silkscreen:wght@400;700&family=JetBrains+Mono:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap';
  document.head.appendChild(f);

  const s = document.createElement('style');
  s.id = 'ck-styles';
  s.textContent = `
    .ck {
      --cream: #FAF8F4;
      --cream-hi: #FFFEF5;
      --cream-md: #F5F0E8;
      --cream-lo: #ECE6DA;
      --ink: #2D2A20;
      --ink-soft: #5C4A1F;
      --muted: #78716C;
      --dim: #A8A29E;
      --line: #2D2A20;
      --line-soft: #D9D3C5;
      --amber: #FFD600;
      --amber-soft: #FFF3AD;
      --amber-deep: #D97706;
      --phos: #E9B949;
      --phos-dim: #8A6D1C;
      --phos-glow: #FFD77A;
      --phos-bg: #14110A;
      --hp: #6BBE58;
      --hp-dim: #2B5A22;
      --mp: #4AA3E6;
      --mp-dim: #1D4A7A;
      --rose: #DC2626;
      --rose-soft: #FEF2F2;
      --emerald: #059669;
      --violet: #9B8ACB;
      --violet-soft: #F3E8FF;
      color: var(--ink);
      font-family: 'Inter', system-ui, sans-serif;
      box-sizing: border-box;
    }
    .ck *, .ck *::before, .ck *::after { box-sizing: border-box; }
    .ck-display { font-family: 'Silkscreen', monospace; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 700; }
    .ck-screen  { font-family: 'VT323', monospace; letter-spacing: 0.5px; }
    .ck-mono    { font-family: 'JetBrains Mono', ui-monospace, monospace; }
    .ck-kicker  { font-family: 'Silkscreen', monospace; font-weight: 700; text-transform: uppercase; letter-spacing: 1.4px; color: var(--muted); }

    /* CRT scanline overlay (desktop only — too noisy on mobile) */
    .ck-crt { position: relative; isolation: isolate; }
    .ck-crt::before {
      content: ''; position: absolute; inset: 0; pointer-events: none; z-index: 2;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 2px, rgba(0,0,0,0.10) 2px 3px);
      mix-blend-mode: multiply;
    }
    @media (max-width: 600px) {
      .ck-crt::before { background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,0.06) 3px 4px); }
    }

    /* Bevels */
    .ck-bevel {
      background: var(--cream-hi);
      border: 2px solid var(--line);
      box-shadow: inset 1.5px 1.5px 0 rgba(255,255,255,0.7), inset -1.5px -1.5px 0 rgba(0,0,0,0.06), 3px 3px 0 var(--line);
    }
    .ck-bevel-sunken {
      background: var(--cream-md);
      border: 2px solid var(--line);
      box-shadow: inset 2px 2px 0 rgba(0,0,0,0.12), inset -1.5px -1.5px 0 var(--cream-hi);
    }

    /* Phosphor screen */
    .ck-phos {
      background: radial-gradient(ellipse at center, #2A2412 0%, var(--phos-bg) 100%);
      color: var(--phos);
      text-shadow: 0 0 3px rgba(233,185,73,0.7), 0 0 8px rgba(233,185,73,0.25);
      border: 2px solid var(--line);
      box-shadow: inset 0 0 14px rgba(233,185,73,0.18), 3px 3px 0 var(--line);
    }
    .ck-phos-hi { color: var(--phos-glow); text-shadow: 0 0 6px rgba(255,215,122,0.9); }
    .ck-phos-dim { color: var(--phos-dim); text-shadow: none; }

    /* LCD (tamagotchi) */
    .ck-lcd {
      background: #A9C47C; color: #2B3E1A;
      font-family: 'VT323', monospace;
      border: 2px solid var(--line);
      box-shadow: inset 2px 2px 0 #8BAD5E, inset -2px -2px 0 #C3D89C, 3px 3px 0 var(--line);
      position: relative;
    }
    .ck-lcd::before {
      content: ''; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,0.06) 3px 4px);
    }

    /* ── Buttons ─────────────────────────────────── */
    .ck-btn {
      display: inline-flex; align-items: center; justify-content: center; gap: 6px;
      padding: 10px 14px;
      min-height: 36px;
      border: 2px solid var(--line);
      background: var(--cream-hi);
      color: var(--ink);
      font-family: 'Silkscreen', monospace;
      font-size: 11px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 1px;
      line-height: 1; cursor: pointer; user-select: none;
      box-shadow: inset 1px 1px 0 #FFF, inset -2px -2px 0 rgba(0,0,0,0.10), 3px 3px 0 var(--line);
      transition: transform 80ms linear, box-shadow 80ms linear;
      touch-action: manipulation;
    }
    .ck-btn:hover { transform: translate(1px,1px); box-shadow: inset 1px 1px 0 #FFF, inset -2px -2px 0 rgba(0,0,0,0.10), 2px 2px 0 var(--line); }
    .ck-btn:active { transform: translate(3px,3px); box-shadow: inset 2px 2px 0 rgba(0,0,0,0.18), 0 0 0 var(--line); }
    .ck-btn.primary { background: var(--amber); }
    .ck-btn.danger  { background: var(--rose-soft); color: var(--rose); }
    .ck-btn.ghost   { background: transparent; box-shadow: 0 0 0 var(--line); border-color: var(--line-soft); }
    .ck-btn.sm      { padding: 6px 10px; font-size: 9px; min-height: 28px; }
    .ck-btn.tiny    { padding: 4px 7px; font-size: 8px; min-height: 22px; box-shadow: 2px 2px 0 var(--line); }
    .ck-btn.touch   { min-height: 44px; padding: 12px 18px; font-size: 12px; }
    .ck-btn.block   { width: 100%; }

    /* ── Chips ───────────────────────────────────── */
    .ck-chip {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 3px 7px;
      border: 1.5px solid var(--line);
      background: var(--cream-hi);
      font-family: 'Silkscreen', monospace;
      font-size: 8px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.6px; line-height: 1.4;
    }
    .ck-chip.amber   { background: var(--amber); }
    .ck-chip.violet  { background: var(--violet-soft); color: #5B21B6; }
    .ck-chip.emerald { background: #A9E4C2; color: #0B4F2E; }
    .ck-chip.rose    { background: var(--rose-soft); color: var(--rose); }
    .ck-chip.blue    { background: #DBEAFE; color: #1E40AF; }
    .ck-chip.slate   { background: var(--cream-md); color: var(--muted); }
    .ck-chip.phos    { background: var(--phos-bg); color: var(--phos); border-color: var(--phos-dim); text-shadow: 0 0 3px rgba(233,185,73,0.7); }

    /* ── LED ─────────────────────────────────────── */
    .ck-led {
      display: inline-block; width: 8px; height: 8px; border-radius: 50%;
      background: var(--muted);
      box-shadow: inset -1px -1px 0 rgba(0,0,0,0.25), 0 0 0 1.5px var(--line), 0 0 4px currentColor;
    }
    .ck-led.on    { background: var(--hp); color: var(--hp); }
    .ck-led.busy  { background: var(--amber-deep); color: var(--amber-deep); animation: ck-blink 0.8s step-end infinite; }
    .ck-led.off   { background: var(--dim); color: transparent; }
    .ck-led.red   { background: var(--rose); color: var(--rose); }
    @keyframes ck-blink { 50% { opacity: .35; } }
    @keyframes ck-flash { 50% { opacity: .55; } }

    /* ── HP / token bars ─────────────────────────── */
    .ck-bar {
      display: grid; grid-template-columns: 18px 1fr 42px;
      gap: 6px; align-items: center;
      font-family: 'Silkscreen', monospace; font-size: 9px; font-weight: 700;
    }
    .ck-bar-track {
      position: relative; height: 10px;
      background: var(--cream-md);
      border: 1.5px solid var(--line);
      box-shadow: inset 1px 1px 0 rgba(0,0,0,0.12);
      overflow: hidden;
    }
    .ck-bar-track::after {
      content: ''; position: absolute; inset: 0;
      background-image: repeating-linear-gradient(to right, rgba(0,0,0,0.22) 0 1px, transparent 1px 8px);
      pointer-events: none;
    }
    .ck-bar-fill {
      height: 100%; background: var(--hp);
      box-shadow: inset 0 -3px 0 var(--hp-dim), inset 0 1px 0 rgba(255,255,255,0.4);
      transition: width 300ms linear;
    }
    .ck-bar.mp .ck-bar-fill { background: var(--mp); box-shadow: inset 0 -3px 0 var(--mp-dim), inset 0 1px 0 rgba(255,255,255,0.4); }
    .ck-bar.xp .ck-bar-fill { background: #E6A94A; box-shadow: inset 0 -3px 0 #8A5A1C, inset 0 1px 0 rgba(255,255,255,0.4); }
    .ck-bar.low .ck-bar-fill { background: var(--rose); animation: ck-flash 1s step-end infinite; }
    .ck-bar-val { text-align: right; font-size: 9px; color: var(--muted); font-family: 'JetBrains Mono', monospace; }

    /* ── Token segmented bar ─────────────────────── */
    .ck-tok {
      display: grid; grid-template-columns: 18px 1fr auto;
      gap: 6px; align-items: center;
      font-family: 'Silkscreen', monospace; font-size: 8px; font-weight: 700;
    }
    .ck-tok-track { display: flex; gap: 1px; padding: 1px; height: 10px; background: var(--cream-md); border: 1.5px solid var(--line); box-shadow: inset 1px 1px 0 rgba(0,0,0,0.18); }
    .ck-tok-seg { flex: 1; background: transparent; box-shadow: inset 0 0 0 0.5px rgba(0,0,0,0.05); }
    .ck-tok.hp    .ck-tok-seg.on { background: var(--hp);   box-shadow: inset 0 -2px 0 var(--hp-dim); }
    .ck-tok.mp    .ck-tok-seg.on { background: var(--mp);   box-shadow: inset 0 -2px 0 var(--mp-dim); }
    .ck-tok.amber .ck-tok-seg.on { background: var(--amber-deep); box-shadow: inset 0 -2px 0 #8A5A1C; }
    .ck-tok.rose  .ck-tok-seg.on { background: var(--rose); box-shadow: inset 0 -2px 0 #7A1515; animation: ck-flash 0.9s step-end infinite; }
    .ck-tok-val  { text-align: right; font-size: 9px; color: var(--muted); font-family: 'JetBrains Mono', monospace; white-space: nowrap; }

    /* ── Inputs ──────────────────────────────────── */
    .ck-input {
      width: 100%;
      border: 2px solid var(--line);
      background: var(--cream-hi);
      padding: 11px 12px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 13px;
      color: var(--ink);
      box-shadow: inset 2px 2px 0 rgba(0,0,0,0.10);
      outline: none;
    }
    .ck-input:focus { box-shadow: inset 2px 2px 0 rgba(0,0,0,0.10), 0 0 0 2px var(--amber); }

    /* ── Scrollbars ──────────────────────────────── */
    .ck-scroll::-webkit-scrollbar { width: 8px; height: 8px; }
    .ck-scroll::-webkit-scrollbar-track { background: var(--cream-md); }
    .ck-scroll::-webkit-scrollbar-thumb { background: var(--line); }

    /* hide scrollbars on touch lists */
    .ck-noscrollbar { scrollbar-width: none; }
    .ck-noscrollbar::-webkit-scrollbar { display: none; }
  `;
  document.head.appendChild(s);
}

// ── Atoms ───────────────────────────────────────────
function CkBtn({ variant = '', size = '', block, touch, children, onClick, style, title, type }) {
  const cls = ['ck-btn', variant, size, block && 'block', touch && 'touch'].filter(Boolean).join(' ');
  return <button type={type} className={cls} onClick={onClick} style={style} title={title}>{children}</button>;
}
function CkChip({ tone = '', children, style }) {
  return <span className={['ck-chip', tone].filter(Boolean).join(' ')} style={style}>{children}</span>;
}
function CkLED({ state = 'on', style }) {
  return <span className={`ck-led ${state}`} style={style} />;
}
function CkBar({ label, value, max = 100, kind = 'hp' }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const low = kind === 'hp' && pct < 25;
  return (
    <div className={`ck-bar ${kind}${low ? ' low' : ''}`}>
      <div>{label}</div>
      <div className="ck-bar-track"><div className="ck-bar-fill" style={{ width: pct + '%' }} /></div>
      <div className="ck-bar-val">{value}/{max}</div>
    </div>
  );
}
function fmtTok(n) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1).replace('.0','') + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(n >= 10_000 ? 0 : 1).replace('.0','') + 'k';
  return String(n);
}
function CkTokBar({ label = '5h', used = 0, max = 1, kind = 'mp', segments = 12 }) {
  const remaining = Math.max(0, max - used);
  const remPct = remaining / Math.max(1, max);
  const filled = Math.round(remPct * segments);
  const critical = remPct <= 0.1;
  const tone = critical ? 'rose' : kind;
  return (
    <div className={`ck-tok ${tone}`}>
      <div style={{ fontSize: 8, color: 'var(--ink)' }}>{label}</div>
      <div className="ck-tok-track">
        {Array.from({ length: segments }).map((_, i) => (
          <span key={i} className={`ck-tok-seg${i < filled ? ' on' : ''}`} />
        ))}
      </div>
      <div className="ck-tok-val">{fmtTok(remaining)}/{fmtTok(max)}</div>
    </div>
  );
}
function CkInput(props) { return <input {...props} className={['ck-input', props.className].filter(Boolean).join(' ')} />; }

// 16x16 sprite renderer
const CK_PAL = {
  '.': 'transparent', '#': '#2D2A20', '+': '#FFD600', 'y': '#FFEDB0',
  'o': '#D97706', 'p': '#9B8ACB', 'P': '#7A6AAB', 'g': '#6BBE58',
  'G': '#2B5A22', 'b': '#4AA3E6', 'B': '#1D4A7A', 'r': '#DC2626',
  'w': '#FFFEF5', 's': '#A8A29E', 'e': '#059669', 'c': '#14110A',
};
function CkSprite({ art, size = 48, bg = '#FFFEF5' }) {
  const cell = size / 16;
  return (
    <div style={{
      width: size, height: size,
      display: 'grid',
      gridTemplateColumns: `repeat(16, ${cell}px)`,
      gridTemplateRows: `repeat(16, ${cell}px)`,
      background: bg, border: '1.5px solid #2D2A20',
      imageRendering: 'pixelated', flexShrink: 0,
    }}>
      {art.flatMap((row, y) => [...row].map((ch, x) => (
        <div key={`${y}-${x}`} style={{ background: CK_PAL[ch] || 'transparent' }} />
      )))}
    </div>
  );
}

const CK_PORTRAITS = {
  human: ['................','................','......####......','.....#yyyy#.....','....#yy##yy#....','....#y####y#....','....#yyyyyy#....','.....#yyyy#.....','......####......','.....#++++#.....','....#+#++#+#....','...#++++++++#...','..#++#++++#++#..','..#+#++++++#+#..','...#+#....#+#...','...####..####...'],
  scout: ['................','....########....','...#ssssssss#...','..#ss######ss#..','.#ss#gg##gg#ss#.','.#ss#gg##gg#ss#.','.#ss########ss#.','.#ssss#ss#ssss#.','.#sssssssssss#.','..#sss####sss#..','...#########....','....#+++++#.....','...#+++++++#....','..#++#+++#++#...','..#+#++++++#....','..##.......##...'],
  gatekeeper: ['................','......####......','.....#pppp#.....','....#pp##pp#....','...#p#pppp#p#...','...#pppppppp#...','...#p#pppp#p#...','....#pp##pp#....','.....#pppp#.....','......####......','.....#ppPp#.....','....#p#PP#p#....','...#pp####pp#...','...#p#####p#....','....#p####p#....','....##....##....'],
  brewer: ['................','....########....','...#eeeeeeee#...','..#ee######ee#..','.#ee#bb##bb#ee#.','.#ee########ee#.','.#ee#wwwwww#ee#.','.#ee########ee#.','..#ee######ee#..','...#eeeeeeee#...','....#+#++#+#....','...#+++##+++#...','...#+++##+++#...','...#+#++++#+#...','...##......##...','................'],
  patcher: ['................','......####......','.....#rrrr#.....','....#rr##rr#....','...#r#o##o#r#...','...#rr####rr#...','...#rr#oo#rr#...','....#r####r#....','.....#####......','....#+++++#.....','...#+++++++#....','..#+#+++++#+#...','..#+#+++++#+#...','...#+#+++#+#....','....##...##.....','................'],
};

Object.assign(window, { CkBtn, CkChip, CkLED, CkBar, CkTokBar, CkInput, CkSprite, CK_PORTRAITS, fmtTok });
