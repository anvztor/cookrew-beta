// Workspace Card — unified 4-tab modal for Cookbook · History · Review · Profile.
// Opens inside ArcadeWorkspace. Reuses po-* modal chrome.
// Key new idea: opening a Cookbook recipe reveals its SANDBOX filesystem —
// the scratch tree an agent explores when claiming a task from that recipe.

(function(){
if (typeof document !== 'undefined' && !document.getElementById('wc-styles')) {
  const s = document.createElement('style');
  s.id = 'wc-styles';
  s.textContent = `
    .wc-tabs { display: flex; gap: 0; padding: 0 12px; background: var(--cream-md); border-bottom: 2px solid var(--line); }
    .wc-tab {
      position: relative;
      padding: 9px 16px 8px;
      font-family: 'Silkscreen', monospace;
      font-size: 10px; letter-spacing: 1px; text-transform: uppercase;
      background: transparent; border: none; cursor: pointer;
      color: var(--muted);
      border-right: 1px dashed var(--line-soft);
      display: inline-flex; align-items: center; gap: 6px;
    }
    .wc-tab:hover { color: var(--ink); background: rgba(0,0,0,0.03); }
    .wc-tab.on {
      background: var(--cream-hi);
      color: var(--ink);
      box-shadow: inset 0 3px 0 var(--amber);
    }
    .wc-tab .wc-badge {
      display: inline-flex; align-items: center; justify-content: center;
      min-width: 16px; height: 14px; padding: 0 4px;
      background: var(--amber); border: 1.5px solid var(--line);
      font-family: 'JetBrains Mono', monospace; font-size: 9px; font-weight: 700;
      color: var(--ink);
    }
    .wc-tab.on .wc-badge { background: var(--cream-hi); }

    .wc-fs { font-family: 'JetBrains Mono', monospace; font-size: 11px; line-height: 1.6; color: var(--ink); }
    .wc-fs-row { display: flex; align-items: center; gap: 6px; padding: 1px 8px; cursor: pointer; border-radius: 0; }
    .wc-fs-row:hover { background: var(--amber-soft); }
    .wc-fs-row.sel { background: var(--amber); }
    .wc-fs-row .wc-chev { width: 10px; opacity: 0.5; }
    .wc-fs-row .wc-icon { width: 14px; text-align: center; font-size: 11px; }
    .wc-fs-row .wc-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .wc-fs-row .wc-meta { font-family: 'Silkscreen', monospace; font-size: 8px; color: var(--muted); }
  `;
  document.head.appendChild(s);
}
})();

// Shared card chrome (tabs instead of a single title)
function WCard({ width, height, tab, onTab, onClose, counts, children }) {
  const TABS = [
    { id: 'cookbook', label: 'COOKBOOK', icon: '📖', badge: counts.cookbook },
    { id: 'history',  label: 'HISTORY',  icon: '⟳',  badge: counts.history  },
    { id: 'review',   label: 'REVIEW',   icon: '▣',  badge: counts.review   },
    { id: 'profile',  label: 'PROFILE',  icon: '◉',  badge: counts.profile  },
  ];
  return (
    <div className="po-backdrop">
      <div className="po-card" style={{ width, height, maxWidth: '100%' }}>
        <div className="po-titlebar">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingLeft: 10 }}>
            <div className="pc-display" style={{ fontSize: 11, color: 'var(--ink)' }}>WORKSPACE</div>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--ink-soft)' }}>▸ KREW-DEV · ALEX</div>
          </div>
          <button className="po-close" onClick={onClose}>×</button>
        </div>
        <div className="wc-tabs">
          {TABS.map(t => (
            <button key={t.id} className={`wc-tab${tab === t.id ? ' on' : ''}`} onClick={() => onTab(t.id)}>
              <span style={{ fontSize: 12, opacity: 0.8 }}>{t.icon}</span>
              <span>{t.label}</span>
              {t.badge != null && <span className="wc-badge">{t.badge}</span>}
            </button>
          ))}
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 10px', color: 'var(--muted)' }} className="pc-silk">
            <span style={{ fontSize: 9 }}>⌘ 1·2·3·4 TO SWITCH</span>
          </div>
        </div>
        <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// ── Filesystem tree used for Cookbook sandbox view ─────────
function WCFSTree({ nodes, depth = 0, onPick, picked, openSet }) {
  return (
    <div>
      {nodes.map((n, i) => {
        const key = (n.path || n.name) + i;
        const isOpen = n.kind === 'dir' && openSet.has(n.path);
        const isSel = picked === n.path;
        return (
          <React.Fragment key={key}>
            <div
              className={`wc-fs-row${isSel ? ' sel' : ''}`}
              style={{ paddingLeft: 8 + depth * 14 }}
              onClick={() => onPick(n)}
            >
              <span className="wc-chev">{n.kind === 'dir' ? (isOpen ? '▾' : '▸') : ''}</span>
              <span className="wc-icon">
                {n.kind === 'dir' ? (isOpen ? '📂' : '📁') : (n.icon || '·')}
              </span>
              <span className="wc-name">{n.name}</span>
              {n.mark && <span className="wc-meta">{n.mark}</span>}
            </div>
            {n.kind === 'dir' && isOpen && n.children && (
              <WCFSTree nodes={n.children} depth={depth + 1} onPick={onPick} picked={picked} openSet={openSet} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// Build a small fake filesystem per recipe — lightly modeled on krew-dev/cookrew
function sandboxFor(recipeId) {
  const base = {
    'krewhub': {
      readme: 'KrewHub · control plane HTTP API. Bundles, tasks, digests.',
      entry: 'apps/krewhub/src/server.ts',
      tree: [
        { name: 'apps', kind: 'dir', path: 'apps', children: [
          { name: 'krewhub', kind: 'dir', path: 'apps/krewhub', children: [
            { name: 'src', kind: 'dir', path: 'apps/krewhub/src', children: [
              { name: 'server.ts',   kind: 'file', path: 'apps/krewhub/src/server.ts',   icon: '·', mark: '+28 ~2' },
              { name: 'routes',      kind: 'dir',  path: 'apps/krewhub/src/routes', children: [
                { name: 'claim.ts',    kind: 'file', path: 'apps/krewhub/src/routes/claim.ts', icon: '·', mark: '+42' },
                { name: 'digest.ts',   kind: 'file', path: 'apps/krewhub/src/routes/digest.ts', icon: '·' },
                { name: 'presence.ts', kind: 'file', path: 'apps/krewhub/src/routes/presence.ts', icon: '·' },
              ]},
              { name: 'db', kind: 'dir', path: 'apps/krewhub/src/db', children: [
                { name: 'schema.ts', kind: 'file', path: 'apps/krewhub/src/db/schema.ts', icon: '·' },
              ]},
            ]},
            { name: 'package.json', kind: 'file', path: 'apps/krewhub/package.json', icon: '▤' },
          ]},
        ]},
        { name: 'packages', kind: 'dir', path: 'packages', children: [
          { name: 'krewschemas', kind: 'dir', path: 'packages/krewschemas', children: [
            { name: 'fact.ts',   kind: 'file', path: 'packages/krewschemas/fact.ts', icon: '·' },
            { name: 'digest.ts', kind: 'file', path: 'packages/krewschemas/digest.ts', icon: '·' },
          ]},
        ]},
        { name: 'tests', kind: 'dir', path: 'tests', children: [
          { name: 'claim.e2e.ts', kind: 'file', path: 'tests/claim.e2e.ts', icon: '·', mark: 'FAIL' },
        ]},
        { name: 'README.md',     kind: 'file', path: 'README.md',     icon: '▤' },
        { name: 'package.json',  kind: 'file', path: 'package.json',  icon: '▤' },
        { name: '.facts',        kind: 'dir',  path: '.facts', children: [
          { name: 'schema_v2.json',   kind: 'file', path: '.facts/schema_v2.json',   icon: '≋', mark: 'PIN' },
          { name: 'heartbeat_7s.json',kind: 'file', path: '.facts/heartbeat_7s.json',icon: '≋', mark: 'TTL' },
        ]},
      ],
    },
  };
  return base.krewhub; // single sandbox shape for now — all recipes share layout
}

// ==============================================================
// COOKBOOK TAB — shelf + on-click reveals a sandbox filesystem
// ==============================================================
function WCMiniCartridge({ title, subtitle, swatch = 'a', icon = '▤', w = '100%', h = 140 }) {
  // Fallback cartridge tile — self-contained so WorkspaceCard doesn't depend on ApCartridge.
  const swatches = {
    a: { bg: '#F4D08C', fg: '#6D3A1F' },
    b: { bg: '#AED8C5', fg: '#1F4F3E' },
    c: { bg: '#E7B6C9', fg: '#6A2B44' },
    d: { bg: '#B8C9E8', fg: '#27406E' },
    e: { bg: '#E8CDA3', fg: '#6B4A1C' },
    f: { bg: '#C9BDE8', fg: '#3D2A6B' },
    g: { bg: '#E8E0A3', fg: '#5A4A1C' },
    h: { bg: '#A3D4E8', fg: '#1C4A5A' },
  };
  const sw = swatches[swatch] || swatches.a;
  return (
    <div style={{
      width: w, height: h, background: sw.bg, color: sw.fg,
      border: '2px solid var(--line)',
      boxShadow: '3px 3px 0 var(--line)',
      position: 'relative',
      display: 'flex', flexDirection: 'column',
      fontFamily: '"Silkscreen", monospace',
      imageRendering: 'pixelated',
    }}>
      <div style={{
        padding: '6px 8px', borderBottom: '2px solid rgba(0,0,0,0.25)',
        fontSize: 8, letterSpacing: 1, opacity: 0.85,
      }}>COOKREW · RECIPE</div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, opacity: 0.85 }}>{icon}</div>
      <div style={{
        padding: '6px 8px', background: 'rgba(0,0,0,0.12)', borderTop: '2px solid rgba(0,0,0,0.25)',
      }}>
        <div style={{ fontSize: 11, letterSpacing: 0.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</div>
        <div style={{ fontSize: 8, opacity: 0.7, marginTop: 2 }}>{subtitle}</div>
      </div>
      {/* pixel notches */}
      <div style={{ position: 'absolute', top: 4, right: 4, width: 10, height: 10, background: 'rgba(0,0,0,0.2)' }} />
      <div style={{ position: 'absolute', bottom: 4, left: 4, width: 6, height: 6, background: 'rgba(0,0,0,0.2)' }} />
    </div>
  );
}

function WCCookbook({ recipes, openedRecipe, setOpenedRecipe }) {
  const recipe = recipes.find(r => r.id === openedRecipe) || null;
  const fs = recipe ? sandboxFor(recipe.id) : null;
  const [pickedPath, setPicked] = React.useState('apps/krewhub/src/routes/claim.ts');
  const [openSet, setOpenSet] = React.useState(() => new Set(['apps','apps/krewhub','apps/krewhub/src','apps/krewhub/src/routes','.facts']));

  const togglePick = (n) => {
    if (n.kind === 'dir') {
      setOpenSet(prev => {
        const nxt = new Set(prev);
        if (nxt.has(n.path)) nxt.delete(n.path); else nxt.add(n.path);
        return nxt;
      });
    } else setPicked(n.path);
  };

  if (!recipe) {
    // SHELF
    return (
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: 18, background: 'var(--cream)' }}>
          <div style={{
            border: '2px solid var(--line)', background: 'var(--amber-cream)',
            padding: '10px 14px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ fontSize: 20 }}>📖</div>
            <div style={{ flex: 1 }}>
              <div className="pc-silk" style={{ fontSize: 10 }}>▸ COOKBOOK · 8 RECIPES</div>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 3 }}>
                Pick a recipe to open it as a <b style={{ color: 'var(--ink)' }}>sandbox</b> — a scratch filesystem agents can explore + mutate on claim.
              </div>
            </div>
            <button className="pc-btn tiny primary">＋ NEW RECIPE</button>
            <button className="pc-btn tiny">⎘ IMPORT</button>
          </div>
          <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 8 }}>▸ SHELF</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {recipes.map(r => (
              <div key={r.id} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                <WCMiniCartridge title={r.title} subtitle={r.v} swatch={r.swatch} icon={r.icon} w="100%" h={140} />
                <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <span className={`ap-led ${r.cook > 0 ? 'busy' : (r.stale ? 'off' : 'on')}`} />
                  <span className="pc-mono" style={{ fontSize: 10 }}>{r.cook > 0 ? `${r.cook} cooking` : (r.stale ? 'stale' : 'idle')}</span>
                  <span style={{ marginLeft: 'auto', fontFamily: '"Silkscreen", monospace', fontSize: 8, color: 'var(--muted)' }}>
                    {r.digests}✓·{r.commits}c
                  </span>
                </div>
                <div style={{ fontSize: 10, color: 'var(--muted)', lineHeight: 1.3, minHeight: 26 }}>{r.blurb}</div>
                <button
                  className="pc-btn tiny primary"
                  onClick={() => setOpenedRecipe(r.id)}
                >▶ OPEN SANDBOX</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // RECIPE OPENED AS SANDBOX
  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      {/* Left: FS tree */}
      <div style={{ width: 320, borderRight: '2px solid var(--line)', display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)' }}>
        <div style={{ padding: '8px 12px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', alignItems: 'center', gap: 8 }}>
          <button className="pc-btn tiny" onClick={() => setOpenedRecipe(null)}>◀</button>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="pc-display" style={{ fontSize: 11, color: 'var(--ink)', overflow: 'hidden', textOverflow: 'ellipsis' }}>{recipe.title}</div>
            <div className="pc-silk" style={{ fontSize: 8, color: 'var(--muted)' }}>SANDBOX · agent-scratch/alex-42</div>
          </div>
        </div>
        <div style={{ padding: '6px 10px', borderBottom: '1px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', gap: 4, alignItems: 'center' }}>
          <span className="pc-silk" style={{ fontSize: 8, color: 'var(--muted)' }}>BRANCH:</span>
          <span className="pc-mono" style={{ fontSize: 10, padding: '2px 6px', border: '1.5px solid var(--line)', background: 'var(--cream-hi)' }}>sandbox/bun_482 ▾</span>
          <span style={{ marginLeft: 'auto' }} className="pc-chip violet">◉ LIVE</span>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '8px 4px' }}>
          <div className="wc-fs">
            <WCFSTree nodes={fs.tree} onPick={togglePick} picked={pickedPath} openSet={openSet} />
          </div>
        </div>
        <div style={{ padding: '8px 12px', borderTop: '2px solid var(--line)', background: 'var(--cream-md)' }}>
          <div className="pc-silk" style={{ fontSize: 8, color: 'var(--muted)', marginBottom: 4 }}>▸ SANDBOX STATS</div>
          <div className="pc-mono" style={{ fontSize: 10, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
            14 files · 2 modified<br/>
            <span style={{ color: 'var(--emerald)' }}>+70</span> / <span style={{ color: 'var(--rose)' }}>−2</span> · 1 fact bumped
          </div>
        </div>
      </div>

      {/* Right: file preview + agent explorer */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)', minWidth: 0 }}>
        <div style={{ padding: '8px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ FILE</span>
          <span className="pc-mono" style={{ fontSize: 11, color: 'var(--ink)', fontWeight: 600 }}>{pickedPath}</span>
          <div style={{ flex: 1 }} />
          <button className="pc-btn tiny">RAW</button>
          <button className="pc-btn tiny">BLAME</button>
          <button className="pc-btn tiny primary">DIFF</button>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', fontFamily: '"JetBrains Mono", monospace', fontSize: 11, lineHeight: 1.65, padding: '8px 0' }}>
          {[
            { t: 'ctx', n: 'import { auth } from "../auth";' },
            { t: 'ctx', n: 'import { tasks } from "../db/tasks";' },
            { t: 'ctx', n: '' },
            { t: 'ctx', n: 'export async function claim(req: Request) {' },
            { t: 'del', n: '  const body = await req.json();' },
            { t: 'add', n: '  const body = claimSchema.parse(await req.json());' },
            { t: 'add', n: '  const agent = await auth.resolve(req.headers.get("x-agent-sig"));' },
            { t: 'add', n: '  if (!agent) return new Response("401", { status: 401 });' },
            { t: 'ctx', n: '  const task = await tasks.claim(agent.id, body.task_id);' },
            { t: 'ctx', n: '  return Response.json({ task });' },
            { t: 'ctx', n: '}' },
          ].map((l, i) => (
            <div key={i} style={{
              display: 'flex',
              background: l.t === 'add' ? '#E8F7E0' : l.t === 'del' ? '#FEE2E2' : 'transparent',
              color: l.t === 'add' ? '#1A6B2E' : l.t === 'del' ? '#9B1717' : 'var(--ink)',
              borderLeft: l.t === 'add' ? '3px solid #6BBE58' : l.t === 'del' ? '3px solid #DC2626' : '3px solid transparent',
              padding: '0 12px',
            }}>
              <span style={{ width: 26, opacity: .5, textAlign: 'right' }}>{i+1}</span>
              <span style={{ width: 14, opacity: .7 }}>{l.t === 'add' ? '+' : l.t === 'del' ? '-' : ' '}</span>
              <span style={{ whiteSpace: 'pre' }}>{l.n}</span>
            </div>
          ))}
        </div>

        {/* Agent activity in sandbox */}
        <div style={{ borderTop: '2px solid var(--line)', background: 'var(--cream-md)', padding: '8px 14px' }}>
          <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ AGENTS EXPLORING · 2</div>
          <div className="pc-phos-screen" style={{ padding: '6px 10px', fontSize: 12, minHeight: 72 }}>
            <div>&gt; <span className="pc-phos-hi">SCOUT</span> read apps/krewhub/src/routes/claim.ts</div>
            <div>&gt; <span className="pc-phos-hi">SCOUT</span> wrote tests/claim.e2e.ts</div>
            <div>&gt; <span className="pc-phos-hi">GATEKEEPER</span> read packages/krewschemas/digest.ts</div>
            <div>&gt; <span className="pc-phos-hi">GATEKEEPER</span> ran `pnpm test claim` <span style={{ color:'#D96' }}>FAIL</span></div>
            <div>&gt; _<span style={{ animation: 'pc-blink .7s step-end infinite' }}>▮</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==============================================================
// HISTORY TAB — condensed timeline of one recipe
// ==============================================================
function WCHistory() {
  const commits = [
    { sha: '4a7c9e1', msg: 'fix: heartbeat retry under flaky DNS', who: 'SCOUT',      kind: 'agent', t: '14m', digest: 'bun_482', tag: null, active: true },
    { sha: '3b91c4a', msg: 'feat(cli): task.claim + task.complete', who: 'GATEKEEPER',kind: 'agent', t: '1h',  digest: 'bun_471', tag: 'v0.3.1' },
    { sha: '2fe0a13', msg: 'chore: bump fact-envelope schema to v2', who: 'ALEX',     kind: 'human', t: '3h',  digest: '—',       tag: null },
    { sha: '1d48b2e', msg: 'fix: presence TTL rounded wrong',       who: 'SMITH',    kind: 'agent', t: '5h',  digest: 'bun_465', tag: null },
    { sha: '0c7a22f', msg: 'feat: SSE watchtower endpoint',         who: 'GATEKEEPER',kind: 'agent', t: 'yday',digest: 'bun_458', tag: 'v0.3.0' },
    { sha: 'e814c0a', msg: 'feat: bundle → task → digest loop',     who: 'GATEKEEPER',kind: 'agent', t: '3d',  digest: 'bun_441', tag: 'v0.2.0' },
  ];
  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '10px 16px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ RECIPE · KREWHUB·API</div>
          <span className="pc-mono" style={{ fontSize: 10, padding: '2px 6px', border: '1.5px solid var(--line)', background: 'var(--cream-hi)' }}>main ▾</span>
          <div style={{ flex: 1 }} />
          <span className="pc-chip amber">⟳ 847 COMMITS</span>
          <span className="pc-chip violet">≋ 142 FACTS</span>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '14px 18px', background: 'var(--cream-hi)' }}>
          <div style={{ position: 'relative', paddingLeft: 26 }}>
            <div style={{ position: 'absolute', left: 8, top: 0, bottom: 0, width: 2, background: 'var(--line)' }} />
            {commits.map(c => (
              <div key={c.sha} style={{ position: 'relative', paddingBottom: 12 }}>
                <div style={{
                  position: 'absolute', left: -21, top: 4, width: 12, height: 12,
                  background: c.active ? 'var(--amber)' : (c.kind === 'human' ? 'var(--violet-soft)' : 'var(--cream-hi)'),
                  border: '2px solid var(--line)',
                }}/>
                <div style={{
                  border: c.active ? '2px solid var(--amber-deep)' : '1.5px solid var(--line)',
                  background: c.active ? 'var(--amber-cream)' : 'var(--cream-hi)',
                  padding: '7px 11px', boxShadow: '2px 2px 0 var(--line)',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 3, flexWrap: 'wrap' }}>
                    <span className="pc-mono" style={{ fontSize: 10, fontWeight: 600 }}>{c.sha}</span>
                    {c.tag && <span className="pc-chip amber" style={{ fontSize: 8 }}>{c.tag}</span>}
                    <span className={`pc-chip ${c.kind === 'human' ? 'violet' : 'blue'}`} style={{ fontSize: 8 }}>{c.who}</span>
                    {c.digest !== '—' && <span className="pc-chip emerald" style={{ fontSize: 8 }}>↑ {c.digest}</span>}
                    <span style={{ marginLeft: 'auto', fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: 'var(--muted)' }}>{c.t}</span>
                  </div>
                  <div style={{ fontSize: 11, fontFamily: '"JetBrains Mono", monospace' }}>{c.msg}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <aside style={{ width: 280, borderLeft: '2px solid var(--line)', background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '10px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)' }}>
          <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ FACTS LEDGER · 6</div>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '10px 12px' }}>
          {[
            { k: 'fact/schema_v2',     t: '3h',  kind: 'pinned' },
            { k: 'fact/rfc_digests',   t: '2d',  kind: 'pinned' },
            { k: 'fact/heartbeat_7s',  t: '30m', kind: 'live' },
            { k: 'fact/claim_timeout', t: '1h',  kind: 'live' },
            { k: 'fact/flaky_dns',     t: '10m', kind: 'event' },
          ].map(f => (
            <div key={f.k} style={{
              border: '1.5px solid var(--line)',
              background: f.kind === 'pinned' ? 'var(--amber-cream)' : 'var(--cream-hi)',
              padding: '6px 8px', marginBottom: 6, boxShadow: '2px 2px 0 var(--line)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <span className="pc-mono" style={{ fontSize: 10, flex: 1 }}>{f.k}</span>
                {f.kind === 'pinned' && <span className="pc-chip amber" style={{ fontSize: 8 }}>📌</span>}
                {f.kind === 'live' && <span className="pc-chip blue" style={{ fontSize: 8 }}>◉</span>}
                {f.kind === 'event' && <span className="pc-chip rose" style={{ fontSize: 8 }}>⚡</span>}
              </div>
              <div className="pc-silk" style={{ fontSize: 8, color: 'var(--muted)', marginTop: 2 }}>{f.t}</div>
            </div>
          ))}
        </div>
      </aside>
    </div>
  );
}

// ==============================================================
// REVIEW TAB — HITL approval condensed
// ==============================================================
function WCReview() {
  const tasks = [
    { t: '#01 heartbeat loop in krewcli',         by: 'SCOUT',      ok: true,  adds: 86,  dels: 12 },
    { t: '#02 task.claim + task.complete routes', by: 'GATEKEEPER', ok: true,  adds: 142, dels: 23 },
    { t: '#03 SSE watchtower presence stream',    by: 'GATEKEEPER', ok: true,  adds: 58,  dels: 4  },
    { t: '#04 retry under flaky DNS',             by: 'SCOUT',      ok: false, adds: 24,  dels: 11 },
    { t: '#05 fact-envelope v2 schema',           by: 'SMITH',      ok: true,  adds: 38,  dels: 5  },
  ];
  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      <div style={{ width: 360, borderRight: '2px solid var(--line)', display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)' }}>
        <div style={{ padding: '12px 14px', background: '#FEE2E2', borderBottom: '2px solid var(--line)' }}>
          <div className="pc-silk" style={{ fontSize: 10, color: 'var(--ink-soft)' }}>▸ HITL · STAGE 3/3</div>
          <div className="pc-display" style={{ fontSize: 12, marginTop: 5, lineHeight: 1.35 }}>
            bun_482 · "ADD KREWCLI<br/>PRESENCE & TASK CLAIMING"
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
            <span className="pc-led red" />
            <span className="pc-mono" style={{ fontSize: 10, color: 'var(--rose)', fontWeight: 600 }}>BLOCKED · 1 check failed</span>
          </div>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '10px 12px' }}>
          <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)', marginBottom: 8 }}>▸ TASKS · 5</div>
          {tasks.map((t, i) => (
            <div key={i} style={{
              border: '1.5px solid var(--line)',
              background: t.ok ? 'var(--cream-hi)' : '#FEE2E2',
              padding: '7px 10px', marginBottom: 6, boxShadow: '2px 2px 0 var(--line)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                <div style={{
                  width: 14, height: 14, border: '1.5px solid var(--line)',
                  background: t.ok ? 'var(--emerald)' : 'var(--rose)',
                  color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: '"Press Start 2P", monospace', fontSize: 7,
                }}>{t.ok ? '✓' : '!'}</div>
                <div style={{ flex: 1, fontSize: 11, fontWeight: 500 }}>{t.t}</div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 3, paddingLeft: 22, fontFamily: '"Silkscreen", monospace', fontSize: 8, color: 'var(--muted)' }}>
                <span>{t.by}</span>
                <span style={{ color: 'var(--emerald)' }}>+{t.adds}</span>
                <span style={{ color: 'var(--rose)' }}>−{t.dels}</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding: '10px 14px', borderTop: '2px solid var(--line)', background: '#FEE2E2' }}>
          <div className="pc-silk" style={{ fontSize: 9, color: 'var(--rose)', marginBottom: 5 }}>▸ HOLDS MERGE</div>
          <div style={{ display: 'flex', gap: 4 }}>
            <button className="pc-btn tiny">⇅ REOPEN</button>
            <button className="pc-btn tiny">@ REASSIGN</button>
            <button className="pc-btn tiny primary">✎ OVERRIDE</button>
          </div>
        </div>
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)' }}>
        <div style={{ padding: '10px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ DIFF · TASK #04</span>
          <span className="pc-mono" style={{ fontSize: 10 }}>apps/krewcli/src/heartbeat.ts</span>
          <div style={{ flex: 1 }} />
          <span className="pc-chip amber">＋24</span>
          <span className="pc-chip rose">−11</span>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', fontFamily: '"JetBrains Mono", monospace', fontSize: 11, lineHeight: 1.6 }}>
          {[
            { t: 'ctx', n: 'export async function tick() {' },
            { t: 'del', n: '  const res = await fetch(hub + "/presence");' },
            { t: 'add', n: '  const res = await retry(() => fetch(hub + "/presence"), {' },
            { t: 'add', n: '    tries: 3, backoff_ms: 250,' },
            { t: 'add', n: '  });' },
            { t: 'ctx', n: '  if (!res.ok) throw new Error("heartbeat_failed");' },
            { t: 'ctx', n: '  return res.json();' },
            { t: 'ctx', n: '}' },
          ].map((l, i) => (
            <div key={i} style={{
              display: 'flex',
              background: l.t === 'add' ? '#E8F7E0' : l.t === 'del' ? '#FEE2E2' : 'transparent',
              color: l.t === 'add' ? '#1A6B2E' : l.t === 'del' ? '#9B1717' : 'var(--ink)',
              borderLeft: l.t === 'add' ? '3px solid #6BBE58' : l.t === 'del' ? '3px solid #DC2626' : '3px solid transparent',
              padding: '0 12px',
            }}>
              <span style={{ width: 26, opacity: .5, textAlign: 'right' }}>{i+1}</span>
              <span style={{ width: 14, opacity: .7 }}>{l.t === 'add' ? '+' : l.t === 'del' ? '-' : ' '}</span>
              <span style={{ whiteSpace: 'pre' }}>{l.n}</span>
            </div>
          ))}
        </div>
        <div style={{ borderTop: '2px solid var(--line)', background: 'var(--cream-md)', padding: '10px 14px', display: 'flex', gap: 6, alignItems: 'center' }}>
          <button className="pc-btn sm" style={{ background: '#FEE2E2', color: 'var(--rose)' }}>✗ REJECT</button>
          <button className="pc-btn sm">◎ RECHECK</button>
          <div style={{ flex: 1 }} />
          <button className="pc-btn sm primary" style={{ opacity: 0.4, cursor: 'not-allowed' }}>✓ APPROVE & MERGE</button>
        </div>
      </div>
    </div>
  );
}

// ==============================================================
// PROFILE TAB — my agents / me
// ==============================================================
function WCProfile() {
  const { Sprite16, PORTRAITS, HPBar } = window;
  const myAgents = [
    { id: 'a_gatekeeper', name: 'GATEKEEPER', role: 'CLAUDE-OPUS', sprite: 'agent_a', tier: 'S', hp: 84,  mp: 142, mpMax: 200, tools: ['git','bash','fs','web'], runs: 142, digests: 38, online: true },
    { id: 'a_scout',      name: 'SCOUT',      role: 'GPT-5-MINI',  sprite: 'agent_b', tier: 'A', hp: 72,  mp: 56,  mpMax: 128, tools: ['git','bash','fs'],       runs: 98,  digests: 21, online: true },
    { id: 'a_smith',      name: 'SMITH',      role: 'CLAUDE-HAIKU',sprite: 'agent_c', tier: 'B', hp: 100, mp: 178, mpMax: 200, tools: ['bash','fs'],              runs: 44,  digests: 9,  online: true },
    { id: 'a_reflex',     name: 'REFLEX',     role: 'CODEX-TINY',  sprite: 'agent_e', tier: 'C', hp: 22,  mp: 96,  mpMax: 128, tools: ['bash'],                   runs: 18,  digests: 3,  online: true },
  ];
  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
      {/* left: me */}
      <div style={{ width: 300, borderRight: '2px solid var(--line)', display: 'flex', flexDirection: 'column', background: 'var(--cream-hi)' }}>
        <div style={{ padding: '16px 16px 12px', borderBottom: '2px solid var(--line)', background: 'var(--amber)' }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <Sprite16 art={PORTRAITS.human} size={56} bg="#FFFEF5" />
            <div style={{ flex: 1 }}>
              <div className="pc-display" style={{ fontSize: 12 }}>ALEX</div>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--ink-soft)', marginTop: 3 }}>OPERATOR · LVL 07</div>
              <div className="pc-mono" style={{ fontSize: 9, color: 'var(--ink-soft)', marginTop: 4 }}>0x3a42…c91f</div>
            </div>
          </div>
        </div>
        <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
          <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ STATS</div>
          <div className="pc-mono" style={{ fontSize: 10, lineHeight: 1.7, color: 'var(--ink-soft)' }}>
            <div>recipes owned ·············· <b style={{ color: 'var(--ink)' }}>8</b></div>
            <div>bundles shipped ··········· <b style={{ color: 'var(--ink)' }}>142</b></div>
            <div>digests approved ·········· <b style={{ color: 'var(--ink)' }}>127</b></div>
            <div>digests rejected ············· <b style={{ color: 'var(--ink)' }}>15</b></div>
            <div>streak ························· <b style={{ color: 'var(--amber-deep)' }}>12 days</b></div>
          </div>
        </div>
        <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
          <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ WALLET</div>
          <div className="pc-phos-screen" style={{ padding: '6px 10px', fontSize: 12 }}>
            <div>&gt; ERC-8004 <span className="pc-phos-hi">VERIFIED</span></div>
            <div>&gt; chain: <span className="pc-phos-hi">base-sepolia</span></div>
            <div>&gt; last sig: 2m ago</div>
          </div>
        </div>
        <div style={{ padding: '10px 14px', marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 4 }}>
          <button className="pc-btn sm">⎘ COPY AGENT KEY</button>
          <button className="pc-btn sm">▸ INVITE COLLABORATOR</button>
          <button className="pc-btn sm" style={{ background: '#FEE2E2', color: 'var(--rose)' }}>◌ SIGN OUT</button>
        </div>
      </div>

      {/* right: my agents roster */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--cream)' }}>
        <div style={{ padding: '10px 16px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="pc-silk" style={{ fontSize: 10, color: 'var(--muted)' }}>▸ MY AGENTS · 4</div>
          <div style={{ flex: 1 }} />
          <button className="pc-btn tiny primary">＋ SPAWN AGENT</button>
          <button className="pc-btn tiny">⎘ IMPORT KEY</button>
        </div>
        <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
            {myAgents.map(a => (
              <div key={a.id} className="pc-bevel" style={{ padding: 0, background: 'var(--cream-hi)' }}>
                <div style={{ padding: 10, borderBottom: '2px solid var(--line)', background: a.tier === 'S' ? 'var(--amber)' : 'var(--cream-md)', display: 'flex', gap: 10, alignItems: 'center' }}>
                  <div style={{ position: 'relative' }}>
                    <Sprite16 art={PORTRAITS[a.sprite]} size={44} bg="#FFFEF5" />
                    <div style={{ position: 'absolute', top: -4, right: -4, width: 16, height: 16, border: '1.5px solid var(--line)', background: a.online ? 'var(--hp)' : 'var(--dim)', fontFamily: '"Press Start 2P", monospace', fontSize: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>●</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div className="pc-display" style={{ fontSize: 11 }}>{a.name}</div>
                    <div className="pc-mono" style={{ fontSize: 9, color: 'var(--ink-soft)', marginTop: 2 }}>{a.role}</div>
                  </div>
                  <div style={{ width: 26, height: 26, background: 'var(--cream-hi)', border: '2px solid var(--line)', fontFamily: '"Press Start 2P", monospace', fontSize: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', color: a.tier === 'S' ? 'var(--amber-deep)' : 'var(--ink)' }}>{a.tier}</div>
                </div>
                <div style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <HPBar label="HP" value={a.hp} max={100} kind="hp" />
                  <HPBar label="MP" value={a.mp} max={a.mpMax} kind="mp" />
                  <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap', marginTop: 2 }}>
                    {a.tools.map(t => <span key={t} className="pc-chip violet" style={{ fontSize: 8 }}>{t}</span>)}
                  </div>
                  <div style={{ display: 'flex', gap: 6, paddingTop: 4, borderTop: '1px dashed var(--line-soft)', fontFamily: '"Silkscreen", monospace', fontSize: 8, color: 'var(--muted)' }}>
                    <span>{a.runs} RUNS</span>
                    <span>·</span>
                    <span>{a.digests} ✓</span>
                    <span style={{ marginLeft: 'auto' }}>TIER {a.tier}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 4, marginTop: 2 }}>
                    <button className="pc-btn tiny primary" style={{ flex: 1 }}>▣ DISPATCH</button>
                    <button className="pc-btn tiny" title="edit">✎</button>
                    <button className="pc-btn tiny" title="keys">🔑</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ==============================================================
// WORKSPACE CARD — shell
// ==============================================================
function WorkspaceCard({ initialTab = 'cookbook', initialOpenedRecipe = null, onClose }) {
  const [tab, setTab] = React.useState(initialTab);
  const [openedRecipe, setOpenedRecipe] = React.useState(initialOpenedRecipe);

  const recipes = [
    { id: 'r1', title: 'KREWHUB·API',     swatch: 'a', icon: '⎔', v: 'v1.12.4', agents: 5, cook: 2, digests: 38, blurb: 'Control plane · bundles, tasks, digests',  commits: 847, stale: false },
    { id: 'r2', title: 'KREWHUB·DB',      swatch: 'b', icon: '§', v: 'v0.8.0',  agents: 3, cook: 1, digests: 21, blurb: 'Postgres schema + migrations',              commits: 204, stale: false },
    { id: 'r3', title: 'HEARTBEAT',       swatch: 'c', icon: '◉', v: 'v0.3.2',  agents: 2, cook: 1, digests: 12, blurb: 'SSE watchtower · presence stream',          commits: 98,  stale: false },
    { id: 'r4', title: 'AUTH·8004',       swatch: 'd', icon: '⌘', v: 'v0.1.0',  agents: 1, cook: 0, digests: 3,  blurb: 'Agent identity (ERC-8004)',                  commits: 31,  stale: true  },
    { id: 'r5', title: 'WORKER·LITE',     swatch: 'e', icon: '▸', v: 'v0.2.1',  agents: 2, cook: 0, digests: 7,  blurb: 'Background queue · task dispatch',           commits: 62,  stale: false },
    { id: 'r6', title: 'KREWSCHEMAS',     swatch: 'f', icon: '≋', v: 'v1.0.0',  agents: 0, cook: 0, digests: 5,  blurb: 'Shared types · fact envelopes',              commits: 41,  stale: false },
    { id: 'r7', title: 'WATCHTOWER·CLI',  swatch: 'b', icon: '◈', v: 'v0.4.0',  agents: 1, cook: 0, digests: 4,  blurb: 'Operator CLI · tail events',                 commits: 28,  stale: false },
    { id: 'r8', title: 'ONCHAIN·REG',     swatch: 'f', icon: '§', v: 'v0.0.3',  agents: 0, cook: 0, digests: 0,  blurb: 'Registry contract (foundry)',                commits: 12,  stale: true  },
  ];

  const counts = { cookbook: 8, history: 847, review: '!1', profile: 4 };

  return (
    <WCard width={1280} height={760} tab={tab} onTab={setTab} onClose={onClose} counts={counts}>
      {tab === 'cookbook' && <WCCookbook recipes={recipes} openedRecipe={openedRecipe} setOpenedRecipe={setOpenedRecipe} />}
      {tab === 'history'  && <WCHistory />}
      {tab === 'review'   && <WCReview />}
      {tab === 'profile'  && <WCProfile />}
    </WCard>
  );
}

Object.assign(window, { WorkspaceCard });
