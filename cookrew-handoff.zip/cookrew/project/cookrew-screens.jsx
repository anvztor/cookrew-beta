// Cookrew Pixel Screens demo — phosphor terminal + LCD + bars in standalone form

function CkPhosTerminal({ size = 'md' }) {
  const lines = [
    { t: '> BOOT KREWHUB v0.4.2',   c: 'hi' },
    { t: '> LOADING ROSTER … OK',    c: '' },
    { t: '> 4/5 AGENTS ONLINE',      c: 'hi' },
    { t: '> BUNDLE bun_4a2c READY',  c: '' },
    { t: '> AWAITING DIRECTIVE …',   c: 'dim' },
  ];
  return (
    <div className="ck ck-phos ck-crt" style={{
      padding: '14px 16px', fontFamily: 'VT323, monospace', fontSize: 18,
      width: '100%', height: '100%',
    }}>
      <div className="ck-phos-hi" style={{ fontFamily: 'Silkscreen, monospace', fontSize: 10, fontWeight: 700, marginBottom: 10, letterSpacing: 1 }}>● KREW//TERMINAL</div>
      {lines.map((l, i) => (
        <div key={i} className={l.c === 'hi' ? 'ck-phos-hi' : l.c === 'dim' ? 'ck-phos-dim' : ''}>
          {l.t}
        </div>
      ))}
      <div className="ck-phos-hi">{'>'} <span style={{ animation: 'ck-blink 0.7s step-end infinite' }}>▮</span></div>
    </div>
  );
}

function CkLCDScreen() {
  return (
    <div className="ck ck-lcd" style={{ padding: 14, fontSize: 18, width: '100%', height: '100%' }}>
      <div style={{ fontFamily: 'Silkscreen, monospace', fontSize: 9, fontWeight: 700, marginBottom: 6 }}>● TAMA-CTX</div>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 8 }}>
        <window.CkSprite art={window.CK_PORTRAITS.scout} size={56} bg="#A9C47C" />
        <div style={{ fontFamily: 'VT323, monospace', fontSize: 16, lineHeight: 1.2 }}>
          SCOUT<br/>HP 78/100<br/>CTX 12k/50k
        </div>
      </div>
      <div style={{ fontFamily: 'VT323, monospace', fontSize: 14 }}>♥ ♥ ♥ ♡ ♡</div>
    </div>
  );
}

function CkBarsCard() {
  const { CkBar, CkTokBar } = window;
  return (
    <div className="ck ck-bevel" style={{ padding: 14, background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', gap: 8, width: '100%' }}>
      <div className="ck-display" style={{ fontSize: 11, marginBottom: 4 }}>STATUS BARS</div>
      <CkBar label="HP" value={92} max={100} kind="hp" />
      <CkBar label="MP" value={64} max={100} kind="mp" />
      <CkBar label="XP" value={28} max={100} kind="xp" />
      <CkBar label="HP" value={18} max={100} kind="hp" />
      <div style={{ height: 4 }} />
      <CkTokBar label="5h"  used={38000} max={50000} kind="mp" />
      <CkTokBar label="7d"  used={840000} max={1000000} kind="hp" />
      <CkTokBar label="5h"  used={47500} max={50000} kind="mp" />
    </div>
  );
}

function CkAtomsCard() {
  const { CkBtn, CkChip, CkLED } = window;
  return (
    <div className="ck ck-bevel" style={{ padding: 14, background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', gap: 12, width: '100%' }}>
      <div className="ck-display" style={{ fontSize: 11 }}>BUTTONS</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        <CkBtn variant="primary">PRIMARY</CkBtn>
        <CkBtn>DEFAULT</CkBtn>
        <CkBtn variant="ghost">GHOST</CkBtn>
        <CkBtn variant="danger">DANGER</CkBtn>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        <CkBtn size="sm">SMALL</CkBtn>
        <CkBtn size="tiny">TINY</CkBtn>
        <CkBtn touch>TOUCH</CkBtn>
      </div>
      <div className="ck-display" style={{ fontSize: 11 }}>CHIPS</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
        <CkChip>DEFAULT</CkChip>
        <CkChip tone="amber">AMBER</CkChip>
        <CkChip tone="violet">VIOLET</CkChip>
        <CkChip tone="emerald">EMERALD</CkChip>
        <CkChip tone="rose">ROSE</CkChip>
        <CkChip tone="phos">P1</CkChip>
      </div>
      <div className="ck-display" style={{ fontSize: 11 }}>LEDS</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><CkLED state="on" /><span className="ck-mono" style={{ fontSize: 10 }}>ON</span></span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><CkLED state="busy" /><span className="ck-mono" style={{ fontSize: 10 }}>BUSY</span></span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><CkLED state="off" /><span className="ck-mono" style={{ fontSize: 10 }}>OFF</span></span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><CkLED state="red" /><span className="ck-mono" style={{ fontSize: 10 }}>ALERT</span></span>
      </div>
    </div>
  );
}

Object.assign(window, { CkPhosTerminal, CkLCDScreen, CkBarsCard, CkAtomsCard });
