// Cookrew Event Feed — Pip-Boy phosphor terminal
//   • Desktop: corner pop-out, ~340w, scanlines + amber phosphor
//   • Tablet:  inline panel, scanlines reduced
//   • Mobile:  full-width sheet w/ pull-to-refresh, simplified scanlines

const CK_EVENTS = [
  { t: '14:22:09', src: 'SYS',        kind: 'bundle', msg: '>> BUNDLE bun_4a2c CREATED · 5 quests seeded' },
  { t: '14:22:14', src: 'SCOUT',      kind: 'claim',  msg: '@scout CLAIMED quest #01 "heartbeat endpoint"' },
  { t: '14:22:31', src: 'SCOUT',      kind: 'think',  msg: 'reading krewcli/heartbeat.py …' },
  { t: '14:22:48', src: 'SCOUT',      kind: 'diff',   msg: 'patch +86/−12 in 2 files' },
  { t: '14:23:02', src: 'SCOUT',      kind: 'done',   msg: 'CLEARED #01 in 53s · digest bun_4a2c.01' },
  { t: '14:23:11', src: 'SCOUT',      kind: 'claim',  msg: '@scout CLAIMED quest #02 "retry on flaky DNS"' },
  { t: '14:23:34', src: 'SCOUT',      kind: 'block',  msg: 'BLOCKED · DNS resolver mock missing — needs human' },
  { t: '14:23:38', src: 'GATEKEEPER', kind: 'review', msg: 'review queued for #01' },
  { t: '14:23:40', src: 'BREWER',     kind: 'claim',  msg: '@brewer CLAIMED quest #03 "sandbox reset"' },
  { t: '14:23:55', src: 'BREWER',     kind: 'think',  msg: 'spawning sandbox sbx_a91 …' },
];

const CK_KIND_TONE = {
  bundle: 'phos-hi', claim: 'phos', think: 'phos-dim', diff: 'phos-hi',
  done: 'phos', block: 'rose', review: 'phos', err: 'rose',
};

function CkEventFeed({ variant = 'panel', expanded = false, onClose, onExpand }) {
  const { CkBtn, CkChip } = window;
  const [filter, setFilter] = React.useState('ALL');
  const events = filter === 'ALL' ? CK_EVENTS : CK_EVENTS.filter(e => e.src === filter);
  const sources = ['ALL', ...new Set(CK_EVENTS.map(e => e.src))];

  return (
    <div className={`ck ck-phos ${variant !== 'mobile' ? 'ck-crt' : ''}`} style={{
      width: '100%', height: '100%',
      display: 'flex', flexDirection: 'column',
      fontFamily: 'VT323, monospace',
    }}>
      {/* Header bar */}
      <div style={{
        padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 8,
        borderBottom: '1.5px solid var(--phos-dim)',
        background: 'rgba(233,185,73,0.04)',
      }}>
        <span className="ck-phos-hi" style={{ fontFamily: 'Silkscreen, monospace', fontSize: 10, fontWeight: 700, letterSpacing: 1 }}>EVENT FEED</span>
        <span style={{ flex: 1, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--phos-dim)' }}>
          {events.length} TRACED
        </span>
        {onExpand && (
          <button onClick={onExpand} style={btnStyle}>{expanded ? '▣' : '▢'}</button>
        )}
        {onClose && <button onClick={onClose} style={btnStyle}>×</button>}
      </div>

      {/* Filter chips */}
      <div className="ck-noscrollbar" style={{ display: 'flex', gap: 4, padding: 8, overflowX: 'auto', borderBottom: '1.5px solid var(--phos-dim)' }}>
        {sources.map(s => (
          <button key={s} onClick={() => setFilter(s)} style={{
            ...btnStyle, padding: '3px 8px',
            background: filter === s ? 'var(--phos)' : 'transparent',
            color: filter === s ? 'var(--phos-bg)' : 'var(--phos)',
            textShadow: filter === s ? 'none' : 'inherit',
            flexShrink: 0,
          }}>{s}</button>
        ))}
      </div>

      {/* Event stream */}
      <div className="ck-scroll" style={{ flex: 1, overflowY: 'auto', padding: '6px 10px', fontSize: 14, lineHeight: 1.4 }}>
        {events.map((e, i) => (
          <div key={i} style={{ display: 'flex', gap: 6, padding: '2px 0', alignItems: 'flex-start' }}>
            <span className="ck-phos-dim" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, flexShrink: 0 }}>{e.t}</span>
            <span className="ck-phos-hi" style={{ fontFamily: 'Silkscreen, monospace', fontSize: 9, flexShrink: 0, paddingTop: 1 }}>[{e.src}]</span>
            <span style={{ flex: 1, color: e.kind === 'block' ? 'var(--rose)' : e.kind === 'done' ? 'var(--phos-glow)' : 'var(--phos)', textShadow: e.kind === 'block' ? '0 0 4px rgba(220,38,38,0.6)' : undefined }}>
              {e.msg}
            </span>
          </div>
        ))}
        <div className="ck-phos-hi" style={{ marginTop: 4 }}>{'>'} <span style={{ animation: 'ck-blink 0.7s step-end infinite' }}>▮</span></div>
      </div>
    </div>
  );
}

const btnStyle = {
  background: 'transparent', border: '1.5px solid var(--phos-dim)',
  color: 'var(--phos)', padding: '3px 7px', fontSize: 9,
  fontFamily: 'Silkscreen, monospace', fontWeight: 700, cursor: 'pointer',
  textShadow: '0 0 3px rgba(233,185,73,0.7)', letterSpacing: 0.6,
};

Object.assign(window, { CkEventFeed, CK_EVENTS });
