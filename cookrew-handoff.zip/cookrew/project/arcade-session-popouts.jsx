// Arcade Session Popouts — floating windows over the workspace
// Topic: the Managed Agents architecture (brain / hands / session).
//
// Each popout is a draggable-feeling floating window with its own chrome:
//   • Zoom −/100%/+ (scales inner content)
//   • Fullscreen toggle (fills the workspace area)
//   • Close ×
//   • Corner resize affordance (decorative)
//
// Popouts are opened from the workspace via showPopout:
//   'sandbox'   — SANDBOX · a single container hand
//   'sandbox-died' — same sandbox, container failed; brain retrying
//   'session'   — SESSION · append-only event log tape
//   'session-slice' — same session, brain has selected a positional slice
//   'brain'     — BRAIN · harness composing context from session slices
//   'hands'     — MANY HANDS · one brain, many execute() targets
//
// Visual vocabulary: cream + amber pixel chrome from pc-* tokens.
// The "container-as-cattle" metaphor is made visual: sandbox cards have
// ear-tags, numbered flanks, and replaceable bodies.

// ── styles ────────────────────────────────────────────────────
if (typeof document !== 'undefined' && !document.getElementById('sp-styles')) {
  const s = document.createElement('style');
  s.id = 'sp-styles';
  s.textContent = `
    .sp-overlay {
      position: absolute; inset: 0; z-index: 80;
      background: rgba(20,17,10,0.48);
      backdrop-filter: blur(2px);
      display: flex; align-items: center; justify-content: center;
      padding: 24px 24px 110px;
    }
    .sp-overlay::before {
      content:''; position:absolute; inset:0; pointer-events:none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 3px, rgba(0,0,0,.05) 3px 4px);
    }
    .sp-frame {
      background: var(--cream-hi, #FFFEF5);
      border: 2px solid var(--line, #2D2A20);
      box-shadow: 6px 6px 0 var(--line, #2D2A20);
      position: relative;
      display: flex; flex-direction: column;
      overflow: hidden;
      max-height: 100%;
      --sp-zoom: 1;
    }
    .sp-frame.fullscreen {
      width: 100% !important;
      height: 100% !important;
      max-width: 100%;
      max-height: 100%;
    }
    /* pop-out window chrome */
    .sp-chrome {
      display: flex; align-items: center;
      background: var(--cream-md);
      border-bottom: 2px solid var(--line);
      padding: 6px 8px 6px 12px;
      gap: 10px;
      position: relative;
      flex-shrink: 0;
    }
    .sp-chrome-title {
      font-family: 'Press Start 2P', monospace; font-size: 10px;
      color: var(--ink); letter-spacing: 0;
      display: flex; align-items: center; gap: 10px;
    }
    .sp-chrome-sub {
      font-family: 'Silkscreen', monospace; font-size: 9px;
      color: var(--ink-soft); letter-spacing: .5px; text-transform: uppercase;
    }
    .sp-chrome-spacer { flex: 1; }
    .sp-chrome-btn {
      width: 22px; height: 22px;
      border: 1.5px solid var(--line); background: var(--cream-hi);
      font-family: 'Press Start 2P', monospace; font-size: 9px; line-height: 1;
      display: inline-flex; align-items: center; justify-content: center;
      cursor: pointer; padding: 0;
      box-shadow: 2px 2px 0 var(--line);
      color: var(--ink);
    }
    .sp-chrome-btn:hover { transform: translate(1px,1px); box-shadow: 1px 1px 0 var(--line); }
    .sp-chrome-btn.red { background: #FECACA; }
    .sp-chrome-btn.amber { background: var(--amber); }
    .sp-chrome-zoom {
      display: inline-flex; border: 1.5px solid var(--line); background: var(--cream-hi);
      box-shadow: 2px 2px 0 var(--line);
      overflow: hidden;
    }
    .sp-chrome-zoom button {
      width: 22px; height: 22px; padding: 0;
      border: none; background: transparent;
      font-family: 'Press Start 2P', monospace; font-size: 10px; line-height: 1;
      cursor: pointer; color: var(--ink);
    }
    .sp-chrome-zoom button:hover { background: var(--amber-soft); }
    .sp-chrome-zoom .sp-zoom-val {
      min-width: 40px; padding: 0 6px;
      display: inline-flex; align-items: center; justify-content: center;
      font-family: 'JetBrains Mono', monospace; font-size: 10px;
      border-left: 1.5px solid var(--line); border-right: 1.5px solid var(--line);
      background: var(--cream);
      color: var(--ink);
    }

    /* content scroll frame — zoom applies here */
    .sp-body {
      flex: 1; min-height: 0;
      display: flex; flex-direction: column;
      overflow: hidden;
      background: var(--cream);
    }
    .sp-zoom-wrap {
      flex: 1; min-height: 0; overflow: auto;
      background: var(--cream);
    }
    .sp-zoom-inner {
      transform: scale(var(--sp-zoom));
      transform-origin: top left;
      width: calc(100% / var(--sp-zoom));
      height: max-content;
      min-height: calc(100% / var(--sp-zoom));
    }
    /* corner resize grip (decorative) */
    .sp-resize {
      position: absolute; right: 3px; bottom: 3px;
      width: 14px; height: 14px;
      background:
        linear-gradient(135deg, transparent 46%, var(--line) 46%, var(--line) 52%, transparent 52%,
                                transparent 70%, var(--line) 70%, var(--line) 76%, transparent 76%);
      pointer-events: none;
      opacity: .45;
    }
    /* screen tape rail */
    .sp-rail {
      position: relative;
    }
    .sp-rail::before {
      content:''; position: absolute; left: 14px; top: 0; bottom: 0;
      width: 2px; background: var(--line);
    }
    .sp-tape-hole {
      width: 10px; height: 10px; border-radius: 50%;
      background: var(--cream); border: 1.5px solid var(--line);
    }
    /* punched paper tape edge (session log aesthetic) */
    .sp-tape-edge {
      flex-shrink: 0;
      background:
        radial-gradient(circle at 12px 14px, var(--cream) 3px, transparent 3.5px) repeat-y,
        var(--cream-md);
      background-size: 24px 28px;
      border-right: 1.5px dashed var(--line-soft);
      width: 24px;
    }
    .sp-tape-edge.right {
      background:
        radial-gradient(circle at 12px 14px, var(--cream) 3px, transparent 3.5px) repeat-y,
        var(--cream-md);
      background-size: 24px 28px;
      border-right: none;
      border-left: 1.5px dashed var(--line-soft);
    }

    /* cattle ear-tag */
    .sp-eartag {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 3px 8px 3px 4px;
      background: #FFD600;
      border: 1.5px solid var(--line);
      font-family: 'Silkscreen', monospace; font-size: 9px;
      font-weight: 700; color: var(--ink);
      position: relative;
    }
    .sp-eartag::before {
      content: ''; width: 6px; height: 6px;
      background: var(--line); border-radius: 50%;
      display: inline-block;
    }
    /* ascii arrow connectors */
    .sp-arrow {
      font-family: 'JetBrains Mono', monospace; font-size: 12px;
      color: var(--muted);
      user-select: none;
    }
    /* blinking cursor (local) */
    @keyframes sp-blink { 50% { opacity: .3; } }
    .sp-blink { animation: sp-blink .7s step-end infinite; }

    /* phosphor (dedicated — don't fight pc-phos-screen's scanlines) */
    .sp-phos {
      background: radial-gradient(ellipse at center, #2A2412 0%, #14110A 100%);
      color: #E9B949;
      font-family: 'VT323', monospace;
      text-shadow: 0 0 3px rgba(233,185,73,0.7), 0 0 8px rgba(233,185,73,0.3);
      border: 2px solid var(--line);
      box-shadow: inset 0 0 14px rgba(233,185,73,0.15);
      position: relative;
      overflow: hidden;
    }
    .sp-phos::before {
      content:''; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 2px, rgba(0,0,0,.12) 2px 3px);
      mix-blend-mode: multiply;
    }
    .sp-phos .hi { color: #FFD77A; text-shadow: 0 0 6px rgba(255,215,122,.9); }
    .sp-phos .dim { color: #8A6D1C; text-shadow: none; }

    /* event row pulse */
    @keyframes sp-pulse { 0%, 100% { box-shadow: 2px 2px 0 var(--line), 0 0 0 0 rgba(255,214,0,0); } 50% { box-shadow: 2px 2px 0 var(--line), 0 0 0 4px rgba(255,214,0,.4); } }
    .sp-pulse { animation: sp-pulse 1.6s ease-in-out infinite; }

    /* slice highlight band */
    .sp-slice {
      position: relative;
      background: repeating-linear-gradient(135deg, rgba(255,214,0,.14) 0 6px, rgba(255,214,0,.22) 6px 12px);
      border-top: 2px solid var(--amber-deep);
      border-bottom: 2px solid var(--amber-deep);
    }
  `;
  document.head.appendChild(s);
}

// ── floating window chrome ─────────────────────────────────────
function PopWindow({ title, subtitle, width, height, fullscreen, onFullscreen, onClose, children, accent = 'cream' }) {
  const [zoom, setZoom] = React.useState(1);
  const zoomVal = Math.round(zoom * 100);
  const bumpZoom = (d) => setZoom((z) => Math.max(0.5, Math.min(1.5, +((z + d).toFixed(2)))));
  const titlebarBg = accent === 'amber' ? 'var(--amber)' : accent === 'violet' ? '#E9DFF7' : accent === 'phos' ? '#2A2412' : 'var(--cream-md)';
  const titleCol = accent === 'phos' ? '#E9B949' : 'var(--ink)';
  const subCol = accent === 'phos' ? '#8A6D1C' : 'var(--ink-soft)';

  return (
    <div className={`sp-frame ${fullscreen ? 'fullscreen' : ''}`}
      style={{ width: fullscreen ? '100%' : width, height: fullscreen ? '100%' : height, '--sp-zoom': zoom }}>
      <div className="sp-chrome" style={{ background: titlebarBg, borderBottomColor: 'var(--line)' }}>
        {/* OS-style dots (amber/green/red) */}
        <div style={{ display: 'flex', gap: 5 }}>
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FF5F56', border: '1.5px solid var(--line)' }} />
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FFBD2E', border: '1.5px solid var(--line)' }} />
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#27C93F', border: '1.5px solid var(--line)' }} />
        </div>
        <div className="sp-chrome-title" style={{ color: titleCol }}>
          {title}
          {subtitle && <span className="sp-chrome-sub" style={{ color: subCol }}>▸ {subtitle}</span>}
        </div>
        <div className="sp-chrome-spacer" />
        {/* zoom segmented */}
        <div className="sp-chrome-zoom" title="Zoom">
          <button onClick={() => bumpZoom(-0.1)} aria-label="zoom out">−</button>
          <span className="sp-zoom-val">{zoomVal}%</span>
          <button onClick={() => bumpZoom(+0.1)} aria-label="zoom in">+</button>
        </div>
        {/* fullscreen */}
        <button className="sp-chrome-btn" onClick={onFullscreen} title={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}>
          {fullscreen ? (
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M4 1v3H1M6 1v3h3M1 6h3v3M6 9V6h3"/></svg>
          ) : (
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M1 4V1h3M6 1h3v3M9 6v3H6M4 9H1V6"/></svg>
          )}
        </button>
        {/* close */}
        <button className="sp-chrome-btn red" onClick={onClose} title="Close">×</button>
      </div>
      <div className="sp-body">
        <div className="sp-zoom-wrap">
          <div className="sp-zoom-inner">
            {children}
          </div>
        </div>
      </div>
      <div className="sp-resize" />
    </div>
  );
}

// ── SESSION TAPE ROW ───────────────────────────────────────────
// event kinds borrow from the article: provision, execute, execute_result,
// emitEvent (assistant/user message), tool_call, tool_result, wake, error.
const KIND_STYLE = {
  user:       { bg: '#E9DFF7', ink: '#5B21B6', glyph: '◉', label: 'USER' },
  assistant:  { bg: '#DBEAFE', ink: '#1E40AF', glyph: '✦', label: 'CLAUDE' },
  tool_call:  { bg: '#FFFBEB', ink: '#92400E', glyph: '▸', label: 'EXECUTE' },
  tool_result:{ bg: '#D8F3E6', ink: '#065F46', glyph: '✓', label: 'RESULT' },
  provision:  { bg: '#FEE2E2', ink: '#9B1717', glyph: '⊕', label: 'PROVISION' },
  wake:       { bg: '#FFE4B5', ink: '#B45309', glyph: '↻', label: 'WAKE' },
  error:      { bg: '#FECACA', ink: '#9B1717', glyph: '!', label: 'ERROR' },
  digest:     { bg: '#FFF3AD', ink: '#92400E', glyph: '◆', label: 'DIGEST' },
};

function EventRow({ idx, kind, t, actor, head, body, payload, sliced, pulse }) {
  const st = KIND_STYLE[kind] || KIND_STYLE.assistant;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '46px 52px 1fr', alignItems: 'stretch',
      borderBottom: '1px dashed var(--line-soft)',
      background: sliced ? 'rgba(255,214,0,0.1)' : 'transparent',
    }}>
      {/* index */}
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start',
        padding: '8px 0', borderRight: '1.5px dashed var(--line-soft)',
        fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--muted)',
        background: 'var(--cream-md)',
      }}>
        <div style={{ fontWeight: 700, color: 'var(--ink)' }}>#{String(idx).padStart(4, '0')}</div>
        <div style={{ fontSize: 9, marginTop: 2 }}>{t}</div>
      </div>
      {/* kind glyph */}
      <div style={{
        display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: 6,
      }}>
        <div style={{
          width: 34, height: 34,
          background: st.bg, color: st.ink,
          border: '1.5px solid var(--line)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Press Start 2P, monospace', fontSize: 11,
          boxShadow: '2px 2px 0 var(--line)',
        }}>{st.glyph}</div>
      </div>
      {/* payload */}
      <div className={pulse ? 'sp-pulse' : ''} style={{
        padding: '7px 12px 8px',
        background: 'var(--cream-hi)',
        borderLeft: '2px solid var(--line)',
        margin: '4px 6px 4px 0',
        boxShadow: '2px 2px 0 var(--line)',
        minWidth: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 3, flexWrap: 'wrap' }}>
          <span className="pc-silk" style={{ fontSize: 9, color: st.ink, letterSpacing: .8 }}>{st.label}</span>
          {actor && <span className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>· {actor}</span>}
          {head && <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--ink)', fontWeight: 600 }}>{head}</span>}
        </div>
        {body && <div style={{ fontSize: 11, color: 'var(--ink)', lineHeight: 1.45 }}>{body}</div>}
        {payload && (
          <div style={{
            marginTop: 5,
            padding: '5px 8px',
            background: 'var(--cream-md)',
            border: '1.5px solid var(--line-soft)',
            fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--ink-soft)',
            whiteSpace: 'pre', overflow: 'auto',
            lineHeight: 1.45,
          }}>{payload}</div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// POPOUT 1 — SANDBOX · a single container hand
// ═══════════════════════════════════════════════════════════════
function SandboxPopout({ died = false, ...chrome }) {
  const fsTree = [
    { depth: 0, name: 'krewhub/', kind: 'dir', badge: 'MOUNT' },
    { depth: 1, name: 'apps/',     kind: 'dir' },
    { depth: 2, name: 'krewcli/',  kind: 'dir' },
    { depth: 3, name: 'src/heartbeat.ts', kind: 'file', diff: '+14 −2' },
    { depth: 3, name: 'src/index.ts',     kind: 'file' },
    { depth: 3, name: 'package.json',     kind: 'file' },
    { depth: 2, name: 'krewhub/',  kind: 'dir' },
    { depth: 3, name: 'routes/claim.ts',  kind: 'file', diff: '+8 −0' },
    { depth: 1, name: 'packages/', kind: 'dir' },
    { depth: 1, name: '.git/',     kind: 'dir', badge: 'wired' },
    { depth: 1, name: 'node_modules/', kind: 'dir', badge: '2814' },
  ];

  const calls = died ? [
    { t: '00:14:02.8', cmd: 'read_file',  arg: 'apps/krewcli/src/heartbeat.ts', ok: true, out: '402 bytes' },
    { t: '00:14:03.1', cmd: 'write_file', arg: 'apps/krewcli/src/heartbeat.ts', ok: true, out: '+retry envelope' },
    { t: '00:14:03.9', cmd: 'bash',       arg: 'pnpm test heartbeat',           ok: true, out: '1 pass · 3.2s' },
    { t: '00:14:08.2', cmd: 'bash',       arg: 'pnpm test claim-route',         ok: null, out: 'provision failure · ENOSPC' },
  ] : [
    { t: '00:14:02.8', cmd: 'read_file',  arg: 'apps/krewcli/src/heartbeat.ts', ok: true, out: '402 bytes' },
    { t: '00:14:03.1', cmd: 'write_file', arg: 'apps/krewcli/src/heartbeat.ts', ok: true, out: '+retry envelope' },
    { t: '00:14:03.9', cmd: 'bash',       arg: 'pnpm test heartbeat',           ok: true, out: '1 pass · 3.2s' },
    { t: '00:14:04.4', cmd: 'read_file',  arg: 'apps/krewhub/src/routes/claim.ts', ok: true, out: '1.1 kb' },
    { t: '00:14:05.0', cmd: 'write_file', arg: 'apps/krewhub/src/routes/claim.ts', ok: true, out: '+auth guard' },
    { t: '00:14:05.8', cmd: 'bash',       arg: 'pnpm typecheck',                ok: true, out: 'clean' },
    { t: '00:14:06.4', cmd: 'git',        arg: 'git diff --stat',               ok: true, out: '2 files · +22 −2' },
  ];

  return (
    <PopWindow
      title="SANDBOX"
      subtitle={died ? 'sb_482 · CONTAINER DIED · replacing' : 'sb_482 · a hand for SCOUT'}
      accent="amber"
      {...chrome}
    >
      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr 280px', height: '100%', minHeight: 0 }}>
        {/* ── LEFT · provision spec & ear-tag ───────────── */}
        <aside style={{ borderRight: '2px solid var(--line)', background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <div style={{ padding: '14px 14px 12px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ CATTLE, NOT A PET</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
              <span className="sp-eartag">sb_482</span>
              <span className="pc-mono" style={{ fontSize: 10, color: 'var(--muted)' }}>
                gen·14 · {died ? 'replacing' : 'alive 6m'}
              </span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 8, lineHeight: 1.4 }}>
              A provisioned hand. If it dies, the brain replaces it — no nursing.
            </div>
          </div>

          {/* provision() recipe */}
          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 8 }}>▸ PROVISION()</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, lineHeight: 1.6, color: 'var(--ink)' }}>
              <div><span style={{ color: 'var(--muted)' }}>image</span> <b>oven:node20</b></div>
              <div><span style={{ color: 'var(--muted)' }}>cpu</span> 2 · <span style={{ color: 'var(--muted)' }}>mem</span> 4g</div>
              <div><span style={{ color: 'var(--muted)' }}>cwd</span> /krewhub</div>
              <div><span style={{ color: 'var(--muted)' }}>git</span> wired @ sandbox-init</div>
              <div><span style={{ color: 'var(--muted)' }}>mcp</span> <span style={{ color: 'var(--violet-ink)' }}>krewhub/tasks</span></div>
            </div>
          </div>

          {/* security boundary */}
          <div style={{ padding: '12px 14px', background: '#2A2412', color: '#E9B949', borderTop: '2px solid var(--line)', borderBottom: '2px solid var(--line)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: '#FFD77A', marginBottom: 6 }}>▸ VAULT · OUTSIDE SANDBOX</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, lineHeight: 1.55 }}>
              <div>🔒 git·pat  <span style={{ opacity: .6 }}>→ wired @ clone</span></div>
              <div>🔒 mcp·oauth <span style={{ opacity: .6 }}>→ proxy</span></div>
              <div style={{ color: '#8A6D1C', marginTop: 4 }}># agent never sees tokens</div>
            </div>
          </div>

          {/* actions */}
          <div style={{ padding: '12px 14px', marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 6 }}>
            <button className="pc-btn sm" style={{ width: '100%' }}>⎘ SNAPSHOT</button>
            <button className="pc-btn sm" style={{ width: '100%', background: died ? 'var(--amber)' : 'var(--cream-hi)' }}>
              {died ? '↻ REPROVISION NOW' : '↻ REPROVISION'}
            </button>
            <button className="pc-btn sm danger" style={{ width: '100%' }}>✗ TERMINATE</button>
          </div>
        </aside>

        {/* ── CENTER · FS tree + execute() tape ─────────── */}
        <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, borderRight: '2px solid var(--line)' }}>
          {/* fs */}
          <div style={{ flex: '0 0 38%', display: 'flex', flexDirection: 'column', borderBottom: '2px solid var(--line)' }}>
            <div style={{ padding: '7px 12px', background: 'var(--cream-md)', borderBottom: '1px dashed var(--line-soft)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ FILESYSTEM · /krewhub</div>
              <div style={{ flex: 1 }} />
              <span className="pc-chip emerald" style={{ fontSize: 8 }}>+22</span>
              <span className="pc-chip rose" style={{ fontSize: 8 }}>−2</span>
              <span className="pc-chip slate" style={{ fontSize: 8 }}>2 DIRTY</span>
            </div>
            <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '6px 0', fontFamily: 'JetBrains Mono, monospace', fontSize: 11 }}>
              {fsTree.map((n, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '2px 12px 2px 0',
                  paddingLeft: 12 + n.depth * 16,
                  background: n.diff ? 'rgba(255,214,0,0.14)' : 'transparent',
                  color: n.kind === 'dir' ? 'var(--ink)' : 'var(--ink-soft)',
                }}>
                  <span style={{ color: n.kind === 'dir' ? 'var(--amber-deep)' : 'var(--muted)', width: 12 }}>
                    {n.kind === 'dir' ? '▾' : '·'}
                  </span>
                  <span style={{ fontWeight: n.kind === 'dir' ? 600 : 400 }}>{n.name}</span>
                  {n.badge && <span className="pc-chip slate" style={{ fontSize: 8 }}>{n.badge}</span>}
                  {n.diff && <span className="pc-chip amber" style={{ fontSize: 8, marginLeft: 'auto', marginRight: 4 }}>{n.diff}</span>}
                </div>
              ))}
            </div>
          </div>

          {/* execute tape */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
            <div style={{ padding: '7px 12px', background: 'var(--cream-md)', borderBottom: '1px dashed var(--line-soft)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ EXECUTE(NAME, INPUT) → STRING</div>
              <div style={{ flex: 1 }} />
              <span className="pc-chip slate" style={{ fontSize: 8 }}>7 CALLS · 4.2s</span>
            </div>
            <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '8px 12px', background: 'var(--cream-hi)', fontFamily: 'JetBrains Mono, monospace', fontSize: 11 }}>
              {calls.map((c, i) => {
                const failed = c.ok === null;
                return (
                  <div key={i} style={{
                    display: 'grid', gridTemplateColumns: '68px 80px 1fr auto',
                    gap: 8, alignItems: 'center',
                    padding: '5px 8px', marginBottom: 4,
                    background: failed ? '#FEE2E2' : 'var(--cream)',
                    border: failed ? '2px solid var(--rose)' : '1.5px solid var(--line-soft)',
                    boxShadow: failed ? '2px 2px 0 var(--rose)' : '2px 2px 0 var(--line)',
                  }}>
                    <span style={{ fontSize: 9, color: 'var(--muted)' }}>{c.t}</span>
                    <span style={{
                      padding: '2px 6px',
                      background: failed ? 'var(--rose)' : 'var(--cream-md)',
                      color: failed ? '#fff' : 'var(--ink)',
                      border: '1.5px solid var(--line)',
                      fontFamily: 'Silkscreen, monospace', fontSize: 9, textTransform: 'uppercase',
                      textAlign: 'center',
                    }}>{c.cmd}</span>
                    <span style={{ color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.arg}</span>
                    <span style={{ fontSize: 10, color: failed ? 'var(--rose)' : 'var(--emerald)', fontWeight: failed ? 600 : 400 }}>
                      {failed ? '✗ ' : '✓ '}{c.out}
                    </span>
                  </div>
                );
              })}
              {died && (
                <div style={{ marginTop: 8, padding: '8px 10px', background: '#2A2412', color: '#FFD77A', border: '2px solid var(--line)',
                  fontFamily: 'VT323, monospace', fontSize: 13, lineHeight: 1.4 }}>
                  &gt; tool_error caught by brain<br/>
                  &gt; provision(sb_483, {'{'}image: oven:node20{'}'}) → <span style={{ color: '#27C93F' }}>queued</span><br/>
                  &gt; session log intact · no events lost<span className="sp-blink">▮</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── RIGHT · brain's view ────────────────────── */}
        <aside style={{ background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <div style={{ padding: '10px 14px', background: 'var(--cream-md)', borderBottom: '2px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ ATTACHED BRAIN</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
              <div style={{ width: 28, height: 28, background: '#DBEAFE', border: '1.5px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Press Start 2P', fontSize: 11, color: '#1E40AF' }}>S</div>
              <div>
                <div className="pc-silk" style={{ fontSize: 10 }}>SCOUT</div>
                <div style={{ fontFamily: 'Silkscreen, monospace', fontSize: 9, color: 'var(--muted)' }}>harness·v7 · LVL 08</div>
              </div>
            </div>
            <div style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'JetBrains Mono, monospace', marginTop: 8 }}>
              brain→hand · tool-call iface
            </div>
          </div>

          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 8 }}>▸ WIRE</div>
            <div className="sp-phos" style={{ padding: '8px 10px', fontSize: 13, minHeight: 76, position: 'relative' }}>
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div>&gt; execute(<span className="hi">bash</span>,</div>
                <div>&gt;   <span className="dim">"pnpm typecheck"</span>)</div>
                <div>&gt; ← 200 <span className="hi">"clean"</span></div>
                <div>&gt; _<span className="sp-blink">▮</span></div>
              </div>
            </div>
          </div>

          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ SIBLING HANDS</div>
            {[
              { tag: 'sb_480', use: 'MCP · KREWHUB', led: 'on' },
              { tag: 'sb_481', use: 'PHONE · iOS SIM', led: 'on' },
              { tag: 'sb_483', use: 'CONTAINER (fresh)', led: died ? 'busy' : 'off' },
            ].map((h, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0', borderBottom: i < 2 ? '1px dashed var(--line-soft)' : 'none' }}>
                <span className="sp-eartag" style={{ background: h.led === 'off' ? 'var(--cream-md)' : undefined, padding: '2px 6px 2px 3px' }}>{h.tag}</span>
                <span style={{ fontFamily: 'Silkscreen, monospace', fontSize: 9, color: 'var(--muted)', flex: 1 }}>{h.use}</span>
                <span className={`pc-led ${h.led}`} />
              </div>
            ))}
          </div>

          <div style={{ padding: '12px 14px', background: 'var(--cream-md)', marginTop: 'auto' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ LESSON</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
              {died ? (
                <>Container died mid-exec. Brain caught it as a tool-call error and <b>provisioned sb_483</b>. Session log is intact — nothing to nurse back to health.</>
              ) : (
                <>The brain calls the sandbox via one interface: <b>execute(name,&nbsp;input)&nbsp;→&nbsp;string</b>. Everything on this screen can die and be replaced.</>
              )}
            </div>
          </div>
        </aside>
      </div>
    </PopWindow>
  );
}

// ═══════════════════════════════════════════════════════════════
// POPOUT 2 — SESSION · append-only event log as punched tape
// ═══════════════════════════════════════════════════════════════
function SessionPopout({ sliced = false, ...chrome }) {
  // Events in order. Slice = [4, 7] when sliced.
  const sliceStart = 4, sliceEnd = 7;
  const events = [
    { kind: 'user',      t: '14:02:11', actor: 'ALEX',      head: null,
      body: '"finish the claim route, use the fact envelope v2 schema."' },
    { kind: 'wake',      t: '14:02:11', actor: 'HARNESS',   head: 'wake(ses_14a)',
      body: 'brain booted · getSession → 0 events · attaching hand sb_482' },
    { kind: 'provision', t: '14:02:12', actor: 'HARNESS',   head: 'provision({image:oven:node20,cpu:2})',
      body: 'hand sb_482 ready · git wired · mcp proxy listening' },
    { kind: 'assistant', t: '14:02:14', actor: 'SCOUT',     head: null,
      body: 'reading the claim route and heartbeat file to see what v2 changes.' },
    { kind: 'tool_call', t: '14:02:14', actor: 'SCOUT',     head: 'execute(read_file, heartbeat.ts)',
      payload: '{ path: "apps/krewcli/src/heartbeat.ts" }' },
    { kind: 'tool_result', t: '14:02:15', actor: 'sb_482', head: '→ 402 bytes',
      payload: 'export async function tick() {\n  const res = await fetch(hub + "/presence");\n  …' },
    { kind: 'assistant', t: '14:02:18', actor: 'SCOUT',     head: null,
      body: 'v2 added retry_ms. wrap the fetch in a retry envelope. then re-run tests.' },
    { kind: 'tool_call', t: '14:02:19', actor: 'SCOUT',     head: 'execute(write_file, heartbeat.ts)',
      payload: '{ path: "apps/…/heartbeat.ts", body: "… retry(() => fetch…, {tries:3}) …" }' },
    { kind: 'tool_result', t: '14:02:20', actor: 'sb_482', head: '→ ok · +14 −2',
      payload: null },
    { kind: 'tool_call', t: '14:02:21', actor: 'SCOUT',     head: 'execute(bash, pnpm test heartbeat)',
      payload: null },
    { kind: 'tool_result', t: '14:02:24', actor: 'sb_482', head: '→ 1 pass · 3.2s',
      payload: '✓ tick() retries on 502 (217 ms)' },
    { kind: 'digest',    t: '14:02:28', actor: 'SCOUT',     head: 'emitEvent(digest, bun_482)',
      body: 'ready to ship · 2 files · +22 −2 · awaiting ALEX' },
  ];

  return (
    <PopWindow
      title="SESSION"
      subtitle={`ses_14a · ${sliced ? 'slice [4..7]' : `${events.length} events · append-only`}`}
      accent="cream"
      {...chrome}
    >
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr 300px', height: '100%', minHeight: 0 }}>
        {/* ── LEFT · what a session IS ─────────── */}
        <aside style={{ borderRight: '2px solid var(--line)', background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <div style={{ padding: '14px 14px', borderBottom: '2px dashed var(--line-soft)', background: 'var(--cream-md)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ SESSION · ses_14a</div>
            <div className="pc-display" style={{ fontSize: 12, marginTop: 8, color: 'var(--ink)', lineHeight: 1.35 }}>
              "CLAIM ROUTE<br/>+ FACTS v2"
            </div>
            <div style={{ display: 'flex', gap: 4, marginTop: 10, flexWrap: 'wrap' }}>
              <span className="pc-chip amber">APPEND-ONLY</span>
              <span className="pc-chip emerald">DURABLE</span>
              <span className="pc-chip violet">OUTSIDE CTX</span>
            </div>
          </div>

          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ INTERFACES</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, lineHeight: 1.7, color: 'var(--ink)' }}>
              <div><b>emitEvent</b>(id, e) <span style={{ color: 'var(--muted)' }}>// write</span></div>
              <div><b>getEvents</b>(id, [a,b]) <span style={{ color: 'var(--muted)' }}>// slice</span></div>
              <div><b>wake</b>(id) <span style={{ color: 'var(--muted)' }}>// resume</span></div>
            </div>
          </div>

          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ TALLY</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, lineHeight: 1.7, color: 'var(--ink)' }}>
              <div><span style={{ color: '#5B21B6' }}>◉</span> user · 1</div>
              <div><span style={{ color: '#1E40AF' }}>✦</span> claude · 2</div>
              <div><span style={{ color: '#92400E' }}>▸</span> execute · 4</div>
              <div><span style={{ color: '#065F46' }}>✓</span> result · 4</div>
              <div><span style={{ color: '#B45309' }}>↻</span> wake · 1</div>
              <div><span style={{ color: '#92400E' }}>◆</span> digest · 1</div>
            </div>
          </div>

          {sliced && (
            <div style={{ padding: '12px 14px', background: 'var(--amber-cream)', borderTop: '2px solid var(--amber-deep)', borderBottom: '2px solid var(--amber-deep)' }}>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--amber-deep)', marginBottom: 6 }}>▸ BRAIN IS SLICING</div>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--ink)', lineHeight: 1.5 }}>
                getEvents(ses_14a,<br/>
                &nbsp;&nbsp;[{sliceStart}..{sliceEnd}])
              </div>
              <div style={{ fontSize: 10, color: 'var(--ink-soft)', marginTop: 8, lineHeight: 1.45 }}>
                Re-reading the file that SCOUT wrote, before deciding the next edit. Session is a context object that outlives the ctx window.
              </div>
            </div>
          )}

          <div style={{ padding: '12px 14px', marginTop: 'auto' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ LESSON</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
              The session is <b>not</b> Claude's context window. It's durable, queryable, replayable — compaction happens in the harness, not here.
            </div>
          </div>
        </aside>

        {/* ── CENTER · event tape ─────────── */}
        <div style={{ display: 'flex', minWidth: 0, minHeight: 0, borderRight: '2px solid var(--line)' }}>
          <div className="sp-tape-edge" />
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
            {/* toolbar */}
            <div style={{ padding: '7px 12px', background: 'var(--cream-md)', borderBottom: '1px dashed var(--line-soft)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ EVENT TAPE</div>
              <div style={{ flex: 1 }} />
              <button className={`pc-btn tiny ${sliced ? '' : 'primary'}`}>ALL ({events.length})</button>
              <button className={`pc-btn tiny ${sliced ? 'primary' : ''}`}>SLICE</button>
              <button className="pc-btn tiny">REPLAY ▶</button>
            </div>
            {/* rows */}
            <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', background: 'var(--cream)' }}>
              {events.map((e, i) => {
                const inSlice = sliced && i >= sliceStart && i <= sliceEnd;
                const isSliceStart = sliced && i === sliceStart;
                const isSliceEnd = sliced && i === sliceEnd;
                return (
                  <React.Fragment key={i}>
                    {isSliceStart && (
                      <div style={{ padding: '4px 12px', background: 'var(--amber)', borderTop: '2px solid var(--line)', borderBottom: '2px solid var(--line)',
                        fontFamily: 'Silkscreen, monospace', fontSize: 9, color: 'var(--ink)', letterSpacing: .8 }}>
                        ▼ getEvents(ses_14a, [{sliceStart}..{sliceEnd}]) ── SLICE OPEN
                      </div>
                    )}
                    <EventRow {...e} idx={i} sliced={inSlice} pulse={i === events.length - 1 && !sliced} />
                    {isSliceEnd && (
                      <div style={{ padding: '4px 12px', background: 'var(--amber)', borderTop: '2px solid var(--line)', borderBottom: '2px solid var(--line)',
                        fontFamily: 'Silkscreen, monospace', fontSize: 9, color: 'var(--ink)', letterSpacing: .8 }}>
                        ▲ SLICE CLOSE ── 4 events returned
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
              {!sliced && (
                <div style={{ padding: '12px', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--muted)', textAlign: 'center' }}>
                  ─── tail · emitEvent listening<span className="sp-blink">▮</span> ───
                </div>
              )}
            </div>
          </div>
          <div className="sp-tape-edge right" />
        </div>

        {/* ── RIGHT · harness view of context ─────────── */}
        <aside style={{ background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <div style={{ padding: '10px 14px', background: 'var(--cream-md)', borderBottom: '2px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ CONTEXT WINDOW (HARNESS)</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 4 }}>
              Composed from session events, not stored here.
            </div>
          </div>

          {/* ctx as a bar */}
          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'center', fontFamily: 'Silkscreen, monospace', fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>
              <span>USED</span><span style={{ marginLeft: 'auto' }}>142 / 200 KTOK</span>
            </div>
            <div style={{ display: 'flex', height: 22, border: '2px solid var(--line)', background: 'var(--cream)' }}>
              <div style={{ width: '18%', background: '#E9DFF7', borderRight: '1.5px solid var(--line)' }} title="user" />
              <div style={{ width: '22%', background: '#DBEAFE', borderRight: '1.5px solid var(--line)' }} title="claude" />
              <div style={{ width: '14%', background: '#FFFBEB', borderRight: '1.5px solid var(--line)' }} title="tool_calls" />
              <div style={{ width: '18%', background: '#D8F3E6', borderRight: '1.5px solid var(--line)' }} title="tool_results" />
              <div style={{ width: '3%', background: '#FFE4B5', borderRight: '1.5px solid var(--line)' }} title="wake" />
              <div style={{ width: '7%', background: '#FFF3AD', borderRight: '1.5px solid var(--line)' }} title="digest" />
              <div style={{ flex: 1, background:
                'repeating-linear-gradient(45deg, var(--cream) 0 4px, var(--cream-md) 4px 8px)' }} title="free" />
            </div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--muted)', marginTop: 5 }}>
              harness·transform · cache-hit 87%
            </div>
          </div>

          {/* transforms */}
          <div style={{ padding: '12px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 8 }}>▸ HARNESS TRANSFORMS</div>
            {[
              { k: 'fetch slice', v: '[0..11]', on: true },
              { k: 'drop old tool-results', v: 'keep last 4', on: true },
              { k: 'compact by topic', v: 'off · rewindable', on: false },
              { k: 'strip thinking', v: 'passthrough', on: false },
            ].map((t, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '14px 1fr auto', alignItems: 'center', gap: 8, padding: '5px 0', borderBottom: i < 3 ? '1px dashed var(--line-soft)' : 'none' }}>
                <span style={{
                  width: 12, height: 12, border: '1.5px solid var(--line)',
                  background: t.on ? 'var(--amber)' : 'var(--cream)',
                  fontSize: 9, lineHeight: '10px', textAlign: 'center', color: 'var(--ink)',
                }}>{t.on ? '✓' : ''}</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--ink)' }}>{t.k}</span>
                <span style={{ fontFamily: 'Silkscreen, monospace', fontSize: 9, color: 'var(--muted)' }}>{t.v}</span>
              </div>
            ))}
          </div>

          {/* cursor */}
          <div style={{ padding: '12px 14px', background: 'var(--cream-md)', marginTop: 'auto', borderTop: '2px solid var(--line)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ TAPE CURSOR</div>
            <div className="sp-phos" style={{ padding: '8px 10px', fontSize: 13, minHeight: 56 }}>
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div>&gt; head = <span className="hi">#{String(events.length - 1).padStart(4, '0')}</span></div>
                <div>&gt; {sliced ? <>cursor ← <span className="hi">#{String(sliceStart).padStart(4, '0')}</span> (rewind)</> : <>cursor = head</>}</div>
                <div>&gt; _<span className="sp-blink">▮</span></div>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </PopWindow>
  );
}

// ═══════════════════════════════════════════════════════════════
// POPOUT 3 — BRAIN · the stateless harness
// ═══════════════════════════════════════════════════════════════
function BrainPopout(chrome) {
  return (
    <PopWindow title="BRAIN" subtitle="harness · stateless · cattle" accent="violet" {...chrome}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', height: '100%', minHeight: 0 }}>
        {/* main diagram */}
        <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, borderRight: '2px solid var(--line)', background: 'var(--cream)' }}>
          <div style={{ padding: '10px 14px', background: 'var(--cream-md)', borderBottom: '2px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ HARNESS LOOP · SCOUT · ses_14a</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--ink-soft)', marginTop: 4 }}>
              wake → getEvents → transform → inference → execute → emitEvent → loop
            </div>
          </div>

          {/* sketchy architecture sketch */}
          <div style={{ flex: 1, padding: 24, display: 'flex', flexDirection: 'column', gap: 16, overflow: 'auto' }}>
            {/* ROW 1: session (left) → brain (center) → hands (right) */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 20px 1fr 20px 1fr', alignItems: 'center', gap: 0 }}>
              {/* SESSION */}
              <div style={{
                background: 'var(--cream-hi)', border: '2px solid var(--line)', boxShadow: '4px 4px 0 var(--line)',
                padding: '12px 14px', position: 'relative',
              }}>
                <div style={{ position: 'absolute', top: -10, left: 12, background: 'var(--amber)', border: '1.5px solid var(--line)', padding: '2px 8px', fontFamily: 'Silkscreen, monospace', fontSize: 9 }}>SESSION</div>
                <div style={{ fontFamily: 'Press Start 2P, monospace', fontSize: 11, color: 'var(--ink)', marginTop: 6 }}>TAPE.SYSTEMS</div>
                <div style={{ marginTop: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--ink-soft)', lineHeight: 1.55 }}>
                  getEvents(id, [a,b])<br/>
                  emitEvent(id, e)<br/>
                  <span style={{ color: 'var(--muted)' }}># durable, outside ctx</span>
                </div>
              </div>
              <div className="sp-arrow" style={{ textAlign: 'center', fontSize: 16 }}>→</div>
              {/* BRAIN */}
              <div style={{
                background: '#E9DFF7', border: '2px solid var(--line)', boxShadow: '4px 4px 0 var(--line)',
                padding: '12px 14px', position: 'relative',
              }}>
                <div style={{ position: 'absolute', top: -10, left: 12, background: '#9B8ACB', color: '#fff', border: '1.5px solid var(--line)', padding: '2px 8px', fontFamily: 'Silkscreen, monospace', fontSize: 9 }}>BRAIN · HARNESS</div>
                <div style={{ fontFamily: 'Press Start 2P, monospace', fontSize: 11, color: 'var(--ink)', marginTop: 6 }}>SCOUT·v7</div>
                <div style={{ marginTop: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--ink-soft)', lineHeight: 1.55 }}>
                  wake(ses_14a)<br/>
                  inference·opus-4.5<br/>
                  <span style={{ color: 'var(--muted)' }}># stateless, rebootable</span>
                </div>
              </div>
              <div className="sp-arrow" style={{ textAlign: 'center', fontSize: 16 }}>→</div>
              {/* HANDS */}
              <div style={{
                background: 'var(--amber-cream)', border: '2px solid var(--line)', boxShadow: '4px 4px 0 var(--line)',
                padding: '12px 14px', position: 'relative',
              }}>
                <div style={{ position: 'absolute', top: -10, left: 12, background: 'var(--amber)', border: '1.5px solid var(--line)', padding: '2px 8px', fontFamily: 'Silkscreen, monospace', fontSize: 9 }}>HANDS</div>
                <div style={{ fontFamily: 'Press Start 2P, monospace', fontSize: 11, color: 'var(--ink)', marginTop: 6 }}>N × SB</div>
                <div style={{ marginTop: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--ink-soft)', lineHeight: 1.55 }}>
                  execute(name, input)<br/>
                  → string<br/>
                  <span style={{ color: 'var(--muted)' }}># cattle, not pets</span>
                </div>
              </div>
            </div>

            {/* ROW 2: what the brain is actually doing right now */}
            <div style={{
              border: '2px solid var(--line)', background: 'var(--cream-hi)', boxShadow: '4px 4px 0 var(--line)',
              padding: '14px 16px',
            }}>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 10 }}>▸ CURRENT ITERATION · 4.2s</div>
              {[
                { step: '1', t: 'wake(ses_14a)',                 d: 'fresh harness · session log acquired',    col: '#B45309' },
                { step: '2', t: 'getEvents(ses_14a, [0..11])',   d: '12 events fetched from session',            col: '#1E40AF' },
                { step: '3', t: 'harness.transform(events)',     d: 'cache trim · drop stale tool-results',     col: '#92400E' },
                { step: '4', t: 'claude.inference(ctx)',         d: '→ assistant + next tool_call',              col: '#5B21B6' },
                { step: '5', t: 'execute(bash, "pnpm test…")',   d: 'dispatched to sb_482',                      col: '#065F46' },
                { step: '6', t: 'emitEvent(tool_result)',        d: 'written to session · durable',              col: '#92400E' },
              ].map((s, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '26px 1fr', gap: 10, alignItems: 'center', padding: '5px 0', borderBottom: i < 5 ? '1px dashed var(--line-soft)' : 'none' }}>
                  <div style={{ width: 22, height: 22, background: s.col, color: '#fff', fontFamily: 'Press Start 2P, monospace', fontSize: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1.5px solid var(--line)' }}>{s.step}</div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--ink)', fontWeight: 600 }}>{s.t}</span>
                    <span style={{ fontSize: 11, color: 'var(--muted)' }}>{s.d}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* ROW 3: TTFT comparison */}
            <div style={{
              display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12,
            }}>
              {[
                { label: 'COUPLED (old)', sub: 'brain inside container', p50: '3.8s', p95: '14.2s', bar: 82, c: '#FEE2E2', ink: 'var(--rose)' },
                { label: 'DECOUPLED',     sub: 'brain outside, hands-as-tools', p50: '1.5s', p95: '1.1s', bar: 26, c: '#D8F3E6', ink: 'var(--emerald)' },
              ].map((x, i) => (
                <div key={i} style={{ background: x.c, border: '2px solid var(--line)', boxShadow: '3px 3px 0 var(--line)', padding: '10px 12px' }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                    <div className="pc-silk" style={{ fontSize: 9, color: x.ink }}>▸ {x.label}</div>
                    <div style={{ fontSize: 9, fontFamily: 'Silkscreen, monospace', color: 'var(--muted)', textTransform: 'uppercase' }}>{x.sub}</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginTop: 6, fontFamily: 'JetBrains Mono, monospace' }}>
                    <div><span style={{ fontSize: 9, color: 'var(--muted)' }}>p50</span> <b style={{ fontSize: 14, color: x.ink }}>{x.p50}</b></div>
                    <div><span style={{ fontSize: 9, color: 'var(--muted)' }}>p95</span> <b style={{ fontSize: 14, color: x.ink }}>{x.p95}</b></div>
                  </div>
                  <div style={{ marginTop: 6, height: 12, border: '1.5px solid var(--line)', background: 'var(--cream-hi)', overflow: 'hidden' }}>
                    <div style={{ width: `${x.bar}%`, height: '100%', background: x.ink, boxShadow: 'inset 0 -3px 0 rgba(0,0,0,.2)' }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* right rail */}
        <aside style={{ background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <div style={{ padding: '10px 14px', background: 'var(--cream-md)', borderBottom: '2px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ HARNESS STATE</div>
          </div>
          {[
            { k: 'session_id',  v: 'ses_14a',           c: 'var(--ink)' },
            { k: 'model',       v: 'claude-opus-4.5',    c: 'var(--ink)' },
            { k: 'cursor',      v: 'tail · #0011',       c: '#92400E' },
            { k: 'attached_hands', v: 'sb_482 · mcp_02', c: 'var(--ink)' },
            { k: 'tools',       v: 'read_file · write_file · bash · git · mcp', c: 'var(--muted)' },
            { k: 'version',     v: 'harness·v7 · 2026-04', c: 'var(--muted)' },
          ].map((r, i) => (
            <div key={i} style={{ padding: '8px 14px', borderBottom: '1px dashed var(--line-soft)' }}>
              <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>{r.k}</div>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: r.c, marginTop: 2, wordBreak: 'break-word' }}>{r.v}</div>
            </div>
          ))}
          <div style={{ padding: '12px 14px' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ KILL · RESURRECT</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', lineHeight: 1.45 }}>
              Kill the harness and it reboots cleanly. <b>wake(ses_14a)</b> + <b>getSession</b> restore everything — the log survives, the brain is disposable.
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <button className="pc-btn sm danger" style={{ flex: 1 }}>✗ KILL</button>
              <button className="pc-btn sm" style={{ flex: 1 }}>↻ WAKE</button>
            </div>
          </div>

          <div style={{ padding: '12px 14px', background: 'var(--cream-md)', marginTop: 'auto', borderTop: '2px solid var(--line)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ FAULT DRILL</div>
            <div className="sp-phos" style={{ padding: '8px 10px', fontSize: 13, minHeight: 72 }}>
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div>&gt; kill -9 harness_pid</div>
                <div className="dim">&gt; brain_lost 0.3s</div>
                <div>&gt; <span className="hi">wake(ses_14a)</span></div>
                <div>&gt; getEvents → 11 events</div>
                <div>&gt; resume from #0011<span className="sp-blink">▮</span></div>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </PopWindow>
  );
}

// ═══════════════════════════════════════════════════════════════
// POPOUT 4 — MANY HANDS · one brain, many execute() targets
// ═══════════════════════════════════════════════════════════════
function ManyHandsPopout(chrome) {
  const hands = [
    { tag: 'sb_482', kind: 'container', label: 'OVEN·NODE20',      status: 'busy', pulse: true,
      tools: ['read_file','write_file','bash','git'], use: 'krewhub repo · 2 files dirty', color: '#FFD600' },
    { tag: 'sb_480', kind: 'mcp',       label: 'MCP · krewhub/tasks', status: 'on',
      tools: ['task.list','task.claim','task.complete'], use: 'task board · 12 open', color: '#A9E4C2' },
    { tag: 'sb_481', kind: 'device',    label: 'PHONE · iOS SIM',  status: 'on',
      tools: ['tap','swipe','screenshot','keyboard'],  use: 'e2e test · checkout flow', color: '#DBEAFE' },
    { tag: 'sb_479', kind: 'emulator',  label: 'PKMN · EMU',       status: 'idle',
      tools: ['press','hold','screenshot'], use: 'benchmark suite · route 3', color: '#FECACA' },
    { tag: 'sb_477', kind: 'browser',   label: 'CHROME · HEADFUL', status: 'off',
      tools: ['goto','click','type','screenshot'], use: '— offline', color: '#E7E5E4' },
    { tag: 'sb_475', kind: 'container', label: 'OVEN·PYTHON',      status: 'on',
      tools: ['read_file','write_file','bash','pip'], use: 'ml-pipe · 1 file', color: '#FFE4B5' },
  ];

  return (
    <PopWindow title="MANY HANDS" subtitle="one brain · many execute() targets" accent="cream" {...chrome}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', height: '100%', minHeight: 0 }}>
        <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, borderRight: '2px solid var(--line)' }}>
          {/* brain header */}
          <div style={{ padding: '14px 20px 16px', background: '#E9DFF7', borderBottom: '2px solid var(--line)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: '#7A6AAB' }}>▸ BRAIN · SCOUT · ses_14a</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
              <div style={{ width: 48, height: 48, background: '#9B8ACB', border: '2px solid var(--line)', boxShadow: '3px 3px 0 var(--line)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Press Start 2P, monospace', fontSize: 16, color: '#fff' }}>S</div>
              <div style={{ flex: 1 }}>
                <div className="pc-display" style={{ fontSize: 13 }}>CLAUDE-OPUS-4.5</div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--ink-soft)', marginTop: 3 }}>
                  reaching into <b>{hands.filter(h => h.status !== 'off').length}/6</b> hands · tool-call iface
                </div>
              </div>
              <div style={{ textAlign: 'right', fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'var(--muted)' }}>
                <div>execute(name, input)</div>
                <div>→ string</div>
              </div>
            </div>
          </div>

          {/* grid */}
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: 20, background: 'var(--cream)' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
              {hands.map((h) => {
                const kindLabel = h.kind.toUpperCase();
                const dead = h.status === 'off';
                return (
                  <div key={h.tag} style={{
                    border: '2px solid var(--line)',
                    background: dead ? 'repeating-linear-gradient(45deg, var(--cream-md) 0 6px, var(--cream) 6px 12px)' : 'var(--cream-hi)',
                    boxShadow: '4px 4px 0 var(--line)',
                    position: 'relative',
                    opacity: dead ? .6 : 1,
                  }}>
                    <div className={h.pulse ? 'sp-pulse' : ''} style={{
                      padding: '8px 10px',
                      background: h.color,
                      borderBottom: '2px solid var(--line)',
                      display: 'flex', alignItems: 'center', gap: 6,
                    }}>
                      <span className="sp-eartag" style={{ background: 'var(--cream-hi)' }}>{h.tag}</span>
                      <div style={{ flex: 1 }} />
                      <span className={`pc-led ${h.status}`} />
                    </div>
                    <div style={{ padding: '10px 12px 12px' }}>
                      <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ {kindLabel}</div>
                      <div style={{ fontFamily: 'Press Start 2P, monospace', fontSize: 10, color: 'var(--ink)', marginTop: 5 }}>{h.label}</div>
                      <div style={{ fontSize: 10, color: 'var(--ink-soft)', marginTop: 6, lineHeight: 1.4 }}>{h.use}</div>
                      <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                        {h.tools.map((t, i) => (
                          <span key={i} style={{
                            padding: '2px 5px',
                            background: 'var(--cream-md)',
                            border: '1.5px solid var(--line)',
                            fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: 'var(--ink)',
                          }}>{t}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
              {/* add hand */}
              <button style={{
                border: '2px dashed var(--line)', background: 'transparent', cursor: 'pointer',
                padding: 20, fontFamily: 'Silkscreen, monospace', fontSize: 10, color: 'var(--muted)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}>
                <span style={{ fontFamily: 'Press Start 2P, monospace', fontSize: 18, color: 'var(--ink-soft)' }}>＋</span>
                ATTACH HAND
              </button>
            </div>
          </div>
        </div>

        {/* right: dispatch log */}
        <aside style={{ background: 'var(--cream-hi)', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <div style={{ padding: '10px 14px', background: 'var(--cream-md)', borderBottom: '2px dashed var(--line-soft)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)' }}>▸ DISPATCH LIVE</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', marginTop: 3 }}>Last 2s of execute() calls.</div>
          </div>
          <div className="pc-scroll" style={{ flex: 1, overflow: 'auto', padding: '10px 14px' }}>
            {[
              { h: 'sb_482', t: 'bash', a: 'pnpm typecheck', ms: '124ms', ok: true },
              { h: 'sb_480', t: 'task.list', a: '{state:open}', ms: '22ms', ok: true },
              { h: 'sb_482', t: 'read_file', a: 'claim.ts', ms: '8ms', ok: true },
              { h: 'sb_481', t: 'tap', a: '{x:214,y:492}', ms: '64ms', ok: true },
              { h: 'sb_482', t: 'write_file', a: 'claim.ts', ms: '11ms', ok: true },
              { h: 'sb_475', t: 'bash', a: 'python train.py', ms: '—', ok: null },
              { h: 'sb_479', t: 'press', a: 'A', ms: '2ms', ok: true },
            ].map((r, i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '62px 1fr auto',
                gap: 6, alignItems: 'center',
                padding: '5px 6px', marginBottom: 4,
                background: r.ok === null ? '#FFFBEB' : 'var(--cream)',
                border: '1.5px solid var(--line-soft)',
                fontFamily: 'JetBrains Mono, monospace', fontSize: 10,
              }}>
                <span className="sp-eartag" style={{ fontSize: 8, padding: '1px 4px 1px 3px' }}>{r.h}</span>
                <span style={{ display: 'flex', gap: 4, minWidth: 0 }}>
                  <b style={{ color: 'var(--ink)' }}>{r.t}</b>
                  <span style={{ color: 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.a}</span>
                </span>
                <span style={{ color: r.ok === null ? '#B45309' : 'var(--emerald)', fontSize: 9 }}>{r.ok === null ? '…' : '✓'} {r.ms}</span>
              </div>
            ))}
          </div>

          <div style={{ padding: '12px 14px', background: 'var(--cream-md)', borderTop: '2px solid var(--line)' }}>
            <div className="pc-silk" style={{ fontSize: 9, color: 'var(--muted)', marginBottom: 6 }}>▸ LESSON</div>
            <div style={{ fontSize: 11, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
              The harness doesn't know whether a hand is a container, a phone, or a pokémon emulator. It's all <b>execute(name,&nbsp;input)&nbsp;→&nbsp;string</b>. Brains can even pass hands to one another.
            </div>
          </div>
        </aside>
      </div>
    </PopWindow>
  );
}

// ═══════════════════════════════════════════════════════════════
// Dispatcher — picks the right popout for a slug
// ═══════════════════════════════════════════════════════════════
function SessionPopoutOverlay({ which, onClose }) {
  const [fullscreen, setFullscreen] = React.useState(false);
  const onFs = () => setFullscreen((f) => !f);
  const chrome = { fullscreen, onFullscreen: onFs, onClose };
  let el = null;
  if (which === 'sandbox')        el = <SandboxPopout width={1240} height={720} {...chrome} />;
  else if (which === 'sandbox-died') el = <SandboxPopout died width={1240} height={720} {...chrome} />;
  else if (which === 'session')   el = <SessionPopout width={1340} height={760} {...chrome} />;
  else if (which === 'session-slice') el = <SessionPopout sliced width={1340} height={760} {...chrome} />;
  else if (which === 'brain')     el = <BrainPopout width={1280} height={760} {...chrome} />;
  else if (which === 'hands')     el = <ManyHandsPopout width={1280} height={740} {...chrome} />;
  if (!el) return null;
  return <div className="sp-overlay">{el}</div>;
}

Object.assign(window, {
  SandboxPopout, SessionPopout, BrainPopout, ManyHandsPopout,
  SessionPopoutOverlay,
});
