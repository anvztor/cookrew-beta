// ════════════════════════════════════════════════════════════
// Cookrew · Misc Sidebar (Party rail) + EventFeed (Pip-Boy)
// Used in both desktop + mobile assemblies, kept modular.
// ════════════════════════════════════════════════════════════

const CR_ROSTER = [
  { id:'alex',    kind:'human', name:'ALEX',       sub:'OPERATOR',  portrait:'human',      hp:92,  max:100, used:0,     ctxMax:0,     status:'on'   },
  { id:'scout',   kind:'agent', name:'SCOUT',      sub:'GPT-5-MINI · 3 tools', portrait:'scout',      hp:78,  max:100, used:38000, ctxMax:50000, status:'busy' },
  { id:'gate',    kind:'agent', name:'GATEKEEPER', sub:'OPUS · 4 tools',       portrait:'gatekeeper', hp:100, max:100, used:12000, ctxMax:50000, status:'on'   },
  { id:'brewer',  kind:'agent', name:'BREWER',     sub:'SONNET · 6 tools',     portrait:'brewer',     hp:64,  max:100, used:47000, ctxMax:50000, status:'busy' },
  { id:'patcher', kind:'agent', name:'PATCHER',    sub:'HAIKU · 2 tools',      portrait:'patcher',    hp:22,  max:100, used:0,     ctxMax:50000, status:'off'  },
];

function CrPartySidebar({ collapsed=false, active='scout', onSelect, variant='desktop' }) {
  const { CrChip, CrLED, CrBar, CrTokBar, CrSprite, CR_PORTRAITS, CrButton } = window;
  const online = CR_ROSTER.filter(r => r.status !== 'off').length;
  const w = collapsed ? 64 : 240;
  return (
    <aside className="cr" style={{
      width: w, height:'100%', flexShrink: 0,
      background:'var(--cream-md)', borderRight:'2px solid var(--line)',
      display:'flex', flexDirection:'column', transition:'width 180ms ease',
    }}>
      <div style={{ padding: collapsed ? '12px 8px' : '14px 14px', borderBottom:'2px solid var(--line)', background:'var(--cream-hi)' }}>
        {collapsed ? (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6 }}>
            <div className="cr-display" style={{ fontSize: 10 }}>CR</div>
            <CrLED state="on" />
          </div>
        ) : (
          <>
            <div className="cr-kicker" style={{ fontSize: 8 }}>PARTY · {online}/{CR_ROSTER.length} ONLINE</div>
          </>
        )}
      </div>
      <div className="cr-scroll" style={{ flex: 1, overflowY:'auto', padding: collapsed ? '8px 6px' : '10px 10px' }}>
        {CR_ROSTER.map(m => (
          <button key={m.id} onClick={() => onSelect && onSelect(m.id)} style={{
            width:'100%', padding: collapsed ? '6px 4px' : '8px',
            border:'none', cursor:'pointer',
            background: active === m.id ? 'var(--amber-soft)' : 'transparent',
            display:'flex', alignItems: collapsed ? 'center' : 'flex-start',
            justifyContent: collapsed ? 'center' : 'flex-start',
            flexDirection: collapsed ? 'column' : 'row', gap: collapsed ? 4 : 10,
            marginBottom: 2, borderLeft: collapsed ? 'none' : `3px solid ${active === m.id ? 'var(--ink)' : 'transparent'}`,
            textAlign:'left', opacity: m.status === 'off' ? 0.55 : 1,
          }}>
            <div style={{ position:'relative' }}>
              <CrSprite art={CR_PORTRAITS[m.portrait]} size={collapsed ? 36 : 40} bg="var(--cream-hi)" />
              <div style={{ position:'absolute', bottom:-2, right:-2 }}>
                <CrLED state={m.status === 'busy' ? 'busy' : m.status === 'off' ? 'off' : 'on'} />
              </div>
            </div>
            {!collapsed && (
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', gap: 4 }}>
                  <div className="cr-display" style={{ fontSize: 10 }}>{m.name}</div>
                  <CrChip tone={m.kind === 'human' ? 'amber' : 'slate'} style={{ fontSize: 7, padding:'1px 4px' }}>{m.kind === 'human' ? 'P1' : 'NPC'}</CrChip>
                </div>
                <div className="cr-mono" style={{ fontSize: 9, color:'var(--muted)', marginTop: 2, marginBottom: 6, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{m.sub}</div>
                <div style={{ display:'flex', flexDirection:'column', gap: 3 }}>
                  <CrBar label="HP" value={m.hp} max={m.max} kind="hp" />
                  {m.kind === 'agent' && <CrTokBar label="CTX" used={m.used} max={m.ctxMax} kind="mp" segments={10} />}
                </div>
              </div>
            )}
          </button>
        ))}
      </div>
      {!collapsed && (
        <div style={{ borderTop:'2px solid var(--line)', padding: 10, background:'var(--cream-hi)', display:'flex', flexDirection:'column', gap: 6 }}>
          <CrButton variant="primary" size="sm" block>＋ HIRE AGENT</CrButton>
          <CrButton variant="ghost" size="sm" block>⚙ CONFIG</CrButton>
        </div>
      )}
    </aside>
  );
}

const CR_EVENTS = [
  { t:'14:22:09', src:'SYS',        kind:'bundle', msg:'>> BUNDLE bun_4a2c CREATED · 5 quests seeded' },
  { t:'14:22:14', src:'SCOUT',      kind:'claim',  msg:'@scout CLAIMED quest #01 "heartbeat endpoint"' },
  { t:'14:22:31', src:'SCOUT',      kind:'think',  msg:'reading krewcli/heartbeat.py …' },
  { t:'14:22:48', src:'SCOUT',      kind:'diff',   msg:'patch +86/−12 in 2 files' },
  { t:'14:23:02', src:'SCOUT',      kind:'done',   msg:'CLEARED #01 in 53s · digest bun_4a2c.01' },
  { t:'14:23:11', src:'SCOUT',      kind:'claim',  msg:'@scout CLAIMED quest #02 "retry on flaky DNS"' },
  { t:'14:23:34', src:'SCOUT',      kind:'block',  msg:'BLOCKED · DNS resolver mock missing — needs human' },
  { t:'14:23:38', src:'GATEKEEPER', kind:'review', msg:'review queued for #01' },
  { t:'14:23:40', src:'BREWER',     kind:'claim',  msg:'@brewer CLAIMED quest #03 "sandbox reset"' },
  { t:'14:23:55', src:'BREWER',     kind:'think',  msg:'spawning sandbox sbx_a91 …' },
];

function CrEventFeed({ variant='desktop', onClose }) {
  const [filter, setFilter] = React.useState('ALL');
  const events = filter === 'ALL' ? CR_EVENTS : CR_EVENTS.filter(e => e.src === filter);
  const sources = ['ALL', ...new Set(CR_EVENTS.map(e => e.src))];
  const isMobile = variant === 'mobile';

  const btnStyle = {
    background:'transparent', border:'1.5px solid var(--phos-dim)',
    color:'var(--phos)', padding:'3px 7px', fontSize: 9,
    fontFamily:'Silkscreen, monospace', fontWeight: 700, cursor:'pointer',
    textShadow:'0 0 3px rgba(233,185,73,.7)', letterSpacing: 0.6,
  };

  return (
    <div className={`cr cr-phos ${isMobile ? '' : 'cr-crt'}`} style={{
      width:'100%', height:'100%', display:'flex', flexDirection:'column',
      fontFamily:'VT323, monospace',
    }}>
      <div style={{ padding:'8px 10px', display:'flex', alignItems:'center', gap: 8, borderBottom:'1.5px solid var(--phos-dim)', background:'rgba(233,185,73,0.04)' }}>
        <span className="cr-phos-hi" style={{ fontFamily:'Silkscreen, monospace', fontSize: 10, fontWeight: 700, letterSpacing: 1 }}>EVENT FEED</span>
        <span style={{ flex: 1, fontFamily:'JetBrains Mono, monospace', fontSize: 10, color:'var(--phos-dim)' }}>{events.length} TRACED</span>
        {onClose && <button onClick={onClose} style={btnStyle}>×</button>}
      </div>
      <div className="cr-noscrollbar" style={{ display:'flex', gap: 4, padding: 8, overflowX:'auto', borderBottom:'1.5px solid var(--phos-dim)' }}>
        {sources.map(s => (
          <button key={s} onClick={() => setFilter(s)} style={{
            ...btnStyle, padding:'3px 8px',
            background: filter === s ? 'var(--phos)' : 'transparent',
            color: filter === s ? 'var(--phos-bg)' : 'var(--phos)',
            textShadow: filter === s ? 'none' : 'inherit',
            flexShrink: 0,
          }}>{s}</button>
        ))}
      </div>
      <div className="cr-scroll" style={{ flex: 1, overflowY:'auto', padding:'6px 10px', fontSize: 14, lineHeight: 1.4 }}>
        {events.map((e, i) => (
          <div key={i} style={{ display:'flex', gap: 6, padding:'2px 0', alignItems:'flex-start' }}>
            <span className="cr-phos-dim" style={{ fontFamily:'JetBrains Mono, monospace', fontSize: 11, flexShrink: 0 }}>{e.t}</span>
            <span className="cr-phos-hi" style={{ fontFamily:'Silkscreen, monospace', fontSize: 9, flexShrink: 0, paddingTop: 1 }}>[{e.src}]</span>
            <span style={{ flex: 1, color: e.kind === 'block' ? 'var(--rose)' : e.kind === 'done' ? 'var(--phos-glow)' : 'var(--phos)' }}>
              {e.msg}
            </span>
          </div>
        ))}
        <div className="cr-phos-hi" style={{ marginTop: 4 }}>{'>'} <span style={{ animation:'cr-blink 0.7s step-end infinite' }}>▮</span></div>
      </div>
    </div>
  );
}

Object.assign(window, { CrPartySidebar, CrEventFeed, CR_ROSTER, CR_EVENTS });
